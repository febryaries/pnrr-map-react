<?php
// --- judet.php ---
$COUNTY_MAP = [
  'AB'=>'Alba','AG'=>'Argeș','AR'=>'Arad','BC'=>'Bacău','BH'=>'Bihor','BN'=>'Bistrița-Năsăud',
  'BR'=>'Brăila','BT'=>'Botoșani','BV'=>'Brașov','BZ'=>'Buzău','CJ'=>'Cluj','CL'=>'Călărași',
  'CS'=>'Caraș-Severin','CT'=>'Constanța','CV'=>'Covasna','DB'=>'Dâmbovița','DJ'=>'Dolj','GJ'=>'Gorj',
  'GL'=>'Galați','GR'=>'Giurgiu','HD'=>'Hunedoara','HR'=>'Harghita','IF'=>'Ilfov','IL'=>'Ialomița',
  'IS'=>'Iași','MH'=>'Mehedinți','MM'=>'Maramureș','MS'=>'Mureș','NT'=>'Neamț','OT'=>'Olt',
  'PH'=>'Prahova','SB'=>'Sibiu','SJ'=>'Sălaj','SM'=>'Satu Mare','SV'=>'Suceava','TL'=>'Tulcea',
  'TM'=>'Timiș','TR'=>'Teleorman','VL'=>'Vâlcea','VN'=>'Vrancea','VS'=>'Vaslui','BI'=>'București'
];

// Resolve county code (supports /judet.php/CT or ?c=CT)
$code = '';
if (isset($_GET['c'])) {
  $code = strtoupper(trim($_GET['c']));
} else {
  $path = explode('?', $_SERVER['REQUEST_URI'])[0];
  $parts = array_values(array_filter(explode('/', $path)));
  $last  = end($parts);
  if ($last && strlen($last) <= 3) $code = strtoupper($last);
}
if (in_array($code, ['BI','BU'])) $code = 'BI';
if (!isset($COUNTY_MAP[$code])) { http_response_code(404); echo "Județ invalid."; exit; }

$name = $COUNTY_MAP[$code];
$roCode = "RO-$code";

/* ==== DATASET PICKER (like map.php / locality.php) ==== */
$dir = __DIR__;
$DATA_FILE = 'funds.json';

// Collect dated datasets and sort DESC by date in filename: DDMMYYYY-funds.json
$dated = glob($dir . '/*-funds.json') ?: [];
usort($dated, function($a, $b){
  $fa = basename($a); $fb = basename($b);
  preg_match('/(\d{8})-funds\.json$/', $fa, $ma);
  preg_match('/(\d{8})-funds\.json$/', $fb, $mb);
  $ta = isset($ma[1]) ? DateTime::createFromFormat('dmY', $ma[1]) : false;
  $tb = isset($mb[1]) ? DateTime::createFromFormat('dmY', $mb[1]) : false;
  $tsa = $ta ? (int)$ta->format('U') : 0;
  $tsb = $tb ? (int)$tb->format('U') : 0;
  return $tsb <=> $tsa; // newest first
});

// Build options (dated first, then legacy funds.json if present)
$DATASETS = [];
foreach ($dated as $path){
  $base = basename($path);
  preg_match('/(\d{8})-funds\.json$/', $base, $m);
  $label = isset($m[1]) ? DateTime::createFromFormat('dmY', $m[1])->format('d.m.Y') : $base;
  $DATASETS[] = ['file'=>$base, 'label'=>$label];
}
if (is_file($dir . '/funds.json')) {
  $DATASETS[] = ['file'=>'funds.json', 'label'=>'funds.json (legacy)'];
}

// Pick current dataset from ?ds=..., else latest dated, else funds.json
$dsParam = isset($_GET['ds']) ? basename($_GET['ds']) : '';
if ($dsParam && is_file($dir . '/' . $dsParam)) {
  $DATA_FILE = $dsParam;
} elseif (!empty($DATASETS)) {
  $DATA_FILE = $DATASETS[0]['file'];
} elseif (is_file($dir . '/funds.json')) {
  $DATA_FILE = 'funds.json';
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="utf-8" />
  <title><?=htmlspecialchars($name)?> (<?=$code?>) – Absorbție fonduri 2021–2027</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Highcharts core + maps -->
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/accessibility.js"></script>
  <script src="https://code.highcharts.com/maps/modules/map.js"></script>

  <style>
    :root{ --gap:14px; --card:#fff; --muted:#64748b; --ring:#e2e8f0; }
    *{ box-sizing:border-box; }
    body{ font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif; margin:0; background:#f7fafc; color:#0f172a;}
    header{ padding:18px 20px 4px; max-width:1200px; margin:0 auto; }
    a.back{ display:inline-flex; gap:8px; align-items:center; text-decoration:none; color:#0ea5e9; font-weight:600; }
    h1{ font-size:24px; margin:8px 0 2px; }
    .sub{ color:var(--muted); margin-bottom:8px; }
    .controls{ display:flex; flex-wrap:wrap; align-items:center; gap:var(--gap); padding:10px 20px 0; max-width:1200px; margin:0 auto; }
    .segment{ display:inline-flex; border:1px solid var(--ring); border-radius:999px; overflow:hidden; background:#fff; }
    .segment button{ padding:8px 14px; border:0; background:#fff; cursor:pointer; font-weight:600;}
    .segment button[aria-pressed="true"]{ background:#0ea5e9; color:#fff; }
    .controls select{ padding:8px; border:1px solid var(--ring); border-radius:10px; background:#fff; min-width:220px; }

    .wrap{ max-width:1200px; margin:12px auto 28px; padding:0 20px; }
    .grid{ display:grid; grid-template-columns: 1.4fr 1fr; gap:var(--gap); margin-top:var(--gap); }
    @media (max-width: 960px){ .grid{ grid-template-columns: 1fr; } }

    .card{ background:var(--card); border-radius:16px; box-shadow:0 8px 24px rgba(2,6,23,.06); padding:14px; }
    .kpis{ display:grid; grid-template-columns: repeat(3,1fr); gap:var(--gap); margin-top:var(--gap); }
    @media (max-width: 960px){ .kpis{ grid-template-columns: 1fr; } }
    .kpi{ background:#fff; border:1px solid var(--ring); border-radius:14px; padding:14px; }
    .kpi .label{ color:var(--muted); font-size:13px; }
    .kpi .value{ font-weight:800; font-size:22px; margin-top:6px; }
    .kpi .subline{ color:var(--muted); font-size:13px; margin-top:6px; }

    table{ width:100%; border-collapse:collapse; }
    th, td{ padding:10px 8px; border-bottom:1px solid var(--ring); text-align:left; }
    th{ font-size:13px; color:var(--muted); font-weight:700; }
    td.num{ text-align:right; font-variant-numeric: tabular-nums; }

    #rightPane{ height: 340px; }
    #chartPrograms{ height: 400px; }

    .muted{ color:var(--muted); }

    .extras-controls{ display:flex; gap:12px; flex-wrap:wrap; align-items:center; margin:10px 0; }
    .extras-controls input[type="text"], .extras-controls select{
      padding:8px; border:1px solid var(--ring); border-radius:10px; background:#fff;
    }
    .btn{ display:inline-block; padding:8px 12px; border-radius:10px; background:#0ea5e9; color:#fff; text-decoration:none; font-weight:700; border:0; cursor:pointer; }
    .btn.secondary{ background:#334155; }
    .pill{ display:inline-block; padding:3px 8px; border-radius:999px; background:#e2e8f0; font-size:12px; color:#0f172a; }
    .nowrap{ white-space:nowrap; }
    .scroll-x{ overflow-x:auto; }

    /* Column picker */
    .colpicker-wrap{ position:relative; }
    .colpicker{ position:absolute; z-index:20; right:0; top:44px; min-width:320px; max-height:320px; overflow:auto;
      background:#fff; border:1px solid var(--ring); border-radius:12px; box-shadow:0 8px 24px rgba(2,6,23,.12); padding:10px; display:none;}
    .colpicker.show{ display:block; }
    .colpicker h4{ margin:2px 0 8px; font-size:14px;}
    .colgrid{ display:grid; grid-template-columns:1fr 1fr; gap:6px 12px; }
    .colgrid label{ display:flex; align-items:center; gap:6px; font-size:13px; }
    .picker-actions{ display:flex; gap:8px; margin-top:10px; flex-wrap:wrap; }
    .btn.ghost{ background:#e2e8f0; color:#0f172a; }

    /* Map block (reuses your hero styles) */
    #countyMap{ width:100%; height:260px; display:block; }
  </style>
</head>
<body>
  <header>
    <a class="back" href="map.php?ds=<?=urlencode($DATA_FILE)?>" title="Înapoi la harta națională">← Înapoi la hartă națională</a>
    <h1><?=htmlspecialchars($name)?> (<?=$code?>)</h1>
    <div class="sub">Absorbție fonduri UE 2021–2027 • distribuție pe programe • Set date: <strong><?= htmlspecialchars($DATA_FILE) ?></strong></div>
  </header>

  <div class="controls" role="group" aria-label="Indicator">
    <div class="segment" id="metric-seg" role="tablist" aria-label="Alege indicator">
      <button type="button" data-metric="value" aria-pressed="true" aria-selected="true">Valoare</button>
      <button type="button" data-metric="projects" aria-pressed="false" aria-selected="false">Proiecte</button>
    </div>

    <!-- Dataset dropdown -->
    <label class="muted" for="datasetSel">Set date:</label>
    <select id="datasetSel">
      <?php foreach ($DATASETS as $ds): ?>
        <option value="<?= htmlspecialchars($ds['file']) ?>"
          <?= $ds['file'] === $DATA_FILE ? 'selected' : '' ?>>
          <?= htmlspecialchars($ds['label']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <a class="btn ghost" href="map.php?ds=<?= urlencode($DATA_FILE) ?>">Deschide harta cu acest set</a>
  </div>

  <div class="wrap">
    <div class="kpis">
      <div class="kpi">
        <div class="label">Total valoare (toate programele, fără multi-județe)</div>
        <div id="kpiTotalValue" class="value">—</div>
        <div id="kpiMultiValue" class="subline">—</div>
      </div>
      <div class="kpi">
        <div class="label">Total proiecte (toate programele, fără multi-județe)</div>
        <div id="kpiTotalProjects" class="value">—</div>
        <div id="kpiMultiProjects" class="subline">—</div>
      </div>
      <div class="kpi">
        <div class="label">Top program (după indicatorul selectat)</div>
        <div id="kpiTopProgram" class="value">—</div>
      </div>
    </div>

    <div class="grid">
      <div class="card">
        <div id="chartPrograms"></div>
      </div>
      <div class="card">
        <div id="rightPane"></div>
      </div>
    </div>

   <?php include __DIR__ . '/parts/map.php'; ?>
    <?php include __DIR__ . '/parts/programs.php'; ?>
 
    <?php include __DIR__ . '/parts/extras.php'; ?>
  </div>

<script>
// ===== Server vars (to JS) =====
const COUNTY_CODE = '<?=addslashes($roCode)?>';   // e.g. "RO-CT"
const COUNTY_2    = '<?=addslashes($code)?>';     // e.g. "CT"
const COUNTY_NAME = '<?=addslashes($name)?>';
const DATA_URL    = '<?=addslashes($DATA_FILE)?>';
const DS_FILE     = '<?=addslashes($DATA_FILE)?>';

// Dataset switch => reload with same county, new ?ds=...
const dsSel = document.getElementById('datasetSel');
if (dsSel) {
  dsSel.addEventListener('change', (e) => {
    const ds = e.target.value;
    const params = new URLSearchParams(window.location.search);
    params.set('c', '<?=addslashes($code)?>');
    params.set('ds', ds);
    window.location.search = params.toString();
  });
}

// ===== Shared constants + state =====
const PROGRAMS = [
  {key:'PDD', label:' Dezvoltare Durabilă'},
  {key:'PEO', label:' Educație și Ocupare'},
  {key:'PIDS', label:' Incluziune și Demnitate Socială'},
  {key:'POCIDIF', label:' Creștere Inteligentă '},
  {key:'PS', label:' Sănătate'},
  {key:'PT', label:' Transport'},
  {key:'PTJ', label:' Tranziție Justă'},
  {key:'PR', label:'Dezvoltare Regională'}
];

const PROGRAM_LABEL = Object.fromEntries(PROGRAMS.map(p=>[p.key,p.label]));
const PROGRAM_COLORS = { PDD:'#0ea5e9', PEO:'#6366f1', PIDS:'#ef4444', POCIDIF:'#a855f7', PS:'#f59e0b', PT:'#06b6d4', PTJ:'#f97316', PR:'#334155' };

const FALLBACK = [{
  code: COUNTY_CODE, name: COUNTY_NAME,
  total:{value:134500000, projects:410},
  programs:{PDD:{value:29000000,projects:70}, PEO:{value:9500000,projects:35}, PIDS:{value:6200000,projects:18},
    POCIDIF:{value:12000000,projects:40}, PS:{value:8000000,projects:22}, PT:{value:18000000,projects:12},
    PTJ:{value:0,projects:0}, PR:{value:32000000,projects:213}},
  extras:{rows:[], col_labels:{}}
}];

const fmtMoney = n => new Intl.NumberFormat('ro-RO',{style:'currency',currency:'RON',maximumFractionDigits:0}).format(n||0);
const fmtNum   = n => new Intl.NumberFormat('ro-RO').format(n||0);
const niceHead = s => (s||'').replace(/^_+|_+$/g,'').replace(/_/g,' ').replace(/\s+/g,' ').replace(/\b\w/g,m=>m.toUpperCase());

// Global state (shared across parts)
let metric = 'value';
let countyRow = null;
let allData = [];
let extrasRows = [];
let COL_LABELS = {};
let chartPrograms;
let rightChart;

// Metric toggle -> broadcast
document.querySelectorAll('#metric-seg button').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    metric = btn.dataset.metric;
    document.querySelectorAll('#metric-seg button').forEach(b=>{
      const on = (b === btn);
      b.setAttribute('aria-pressed', on ? 'true':'false');
      b.setAttribute('aria-selected', on ? 'true':'false');
    });
    document.dispatchEvent(new CustomEvent('judet-metric-changed', { detail:{ metric } }));
  });
});

// ===== Multi-județe helpers (value split equally; projects counted fully) =====
function normc(t){
  const s = String(t||'').toUpperCase().trim();
  if (s === 'B' || s === 'BU' || s === 'BI') return 'BI';
  return s.replace(/[^A-Z]/g,'').slice(0,2);
}
function parseTargets(raw){
  return String(raw||'').split(',').map(x => normc(x)).filter(Boolean);
}
function isMultiRow(r){
  return String(r?.IMPLEMENTARE || '').toLowerCase().trim() === 'multi_judete';
}
/** Compute multi totals for a county-2 code (e.g. "CT") */
function computeMultiTotalsForCounty(c2){
  let rows = [];
  const carrier = allData.find(x => x.code === 'RO-MULTI');
  if (carrier?.extras?.rows) rows = carrier.extras.rows.slice();
  else allData.forEach(x => Array.isArray(x.extras?.rows) && rows.push(...x.extras.rows));
  rows = rows.filter(isMultiRow);

  let val = 0, proj = 0;
  for (const r of rows){
    const targets = parseTargets(r['JUDEE_PROIECT_IMPLEMENTARE'] || r['JUDETE_PROIECT_IMPLEMENTARE']);
    if (!targets.length || !targets.includes(c2)) continue;
    const v = Number(r.__share_value || 0);
    const p = Number(r.__share_projects || 0);
    val  += (v / targets.length); // value share
    proj += p;                     // projects counted fully
  }
  return { value: val, projects: proj };
}

// Data loader -> broadcast when ready
async function loadData(){
  let data = [];
  try{
    const r = await fetch(DATA_URL, {cache:'no-store'});
    if(!r.ok) throw new Error('not ok');
    data = await r.json();
    if(!Array.isArray(data) || !data.length) throw new Error('empty');
  }catch(e){
    console.warn('Folosesc FALLBACK pentru judet.php', e);
    data = FALLBACK;
  }

  allData = data;
  countyRow = data.find(r => r.code === COUNTY_CODE) || data[0];
  if(!countyRow){
    alert('Nu am găsit date pentru județul selectat.');
    return;
  }

  extrasRows = Array.isArray(countyRow.extras?.rows) ? countyRow.extras.rows.slice() : [];
  COL_LABELS = countyRow.extras?.col_labels || {};

  // Notify all parts
  document.dispatchEvent(new CustomEvent('judet-data-ready', {
    detail: { allData, countyRow, extrasRows, COL_LABELS, metric }
  }));
}

// Basic KPIs + NEW sublines for Multi-județe
function updateKpis(){
  const totalV = countyRow?.total?.value || 0;
  const totalP = countyRow?.total?.projects || 0;
  document.getElementById('kpiTotalValue').textContent    = fmtMoney(totalV);
  document.getElementById('kpiTotalProjects').textContent = fmtNum(totalP);

  // NEW: Multi totals (share value & full projects)
  const m = computeMultiTotalsForCounty(COUNTY_2);
  const mv = fmtMoney(m.value || 0);
  const mp = fmtNum(m.projects || 0);
  document.getElementById('kpiMultiValue').textContent    = `Multi județe: ${mv}`;
  document.getElementById('kpiMultiProjects').textContent = `Multi județe: ${mp} proiecte`;

  // Top program by selected metric (unchanged)
  const entries = PROGRAMS.map(p=>{
    const pr = countyRow.programs?.[p.key] || {value:0, projects:0};
    return { label: p.label, value: pr.value||0, projects: pr.projects||0 };
  }).sort((a,b)=> (metric==='value' ? b.value - a.value : b.projects - a.projects));
  const top = entries[0];
  document.getElementById('kpiTopProgram').textContent = top
    ? (metric==='value' ? `${top.label} – ${fmtMoney(top.value)}` : `${top.label} – ${fmtNum(top.projects)} proiecte`)
    : '—';
}

// Refresh KPIs on data + metric
document.addEventListener('judet-data-ready', updateKpis);
document.addEventListener('judet-metric-changed', updateKpis);

// BOOT
(async () => {
  await loadData(); // parts will react via events
})();
</script>
</body>
</html>
