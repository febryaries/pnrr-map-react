<?php
// project.php — detail view for a single project found by COD_SMIS
header('Content-Type: text/html; charset=UTF-8');
ini_set('default_charset', 'UTF-8');

$smis = isset($_GET['smis']) ? trim($_GET['smis']) : '';
if ($smis === '') {
  http_response_code(400);
  echo 'Lipsește parametrul ?smis=…';
  exit;
}

/* ==== DATASET PICKER (like map.php / judet.php / locality.php / multi.php) ==== */
$dir = __DIR__;
$DATA_FILE = 'funds.json';

// Collect dated datasets and sort DESC by date in filename: DDMMYYYY-funds.json
$dated = glob($dir . '/*-funds.json') ?: [];
usort($dated, function($a, $b){
  $fa = basename($a); $fb = basename($b);
  preg_match('/(\d{8})-funds\.json$/', $fa, $ma);
  preg_match('/(\d{8})-funds\.json$/', $fb, $mb);
  $ta = isset($ma[1]) ? DateTime::createFromFormat('dmY', $ma[1]) : false;
  $tb = isset($mb[1]) ? DateTime::createFromFormat('dmY', $mb[1]) : false;
  $tsa = $ta ? (int)$ta->format('U') : 0;
  $tsb = $tb ? (int)$tb->format('U') : 0;
  return $tsb <=> $tsa; // newest first
});

// Build options (dated first, then legacy funds.json if present)
$DATASETS = [];
foreach ($dated as $path){
  $base = basename($path);
  preg_match('/(\d{8})-funds\.json$/', $base, $m);
  $label = isset($m[1]) ? DateTime::createFromFormat('dmY', $m[1])->format('d.m.Y') : $base;
  $DATASETS[] = ['file'=>$base, 'label'=>$label];
}
if (is_file($dir . '/funds.json')) {
  $DATASETS[] = ['file'=>'funds.json', 'label'=>'funds.json (legacy)'];
}

// Pick current dataset from ?ds=..., else latest dated, else funds.json
$dsParam = isset($_GET['ds']) ? basename($_GET['ds']) : '';
if ($dsParam && is_file($dir . '/' . $dsParam)) {
  $DATA_FILE = $dsParam;
} elseif (!empty($DATASETS)) {
  $DATA_FILE = $DATASETS[0]['file'];
} elseif (is_file($dir . '/funds.json')) {
  $DATA_FILE = 'funds.json';
}

$COUNTY_MAP = [
  'AB'=>'Alba','AG'=>'Argeș','AR'=>'Arad','BC'=>'Bacău','BH'=>'Bihor','BN'=>'Bistrița-Năsăud',
  'BR'=>'Brăila','BT'=>'Botoșani','BV'=>'Brașov','BZ'=>'Buzău','CJ'=>'Cluj','CL'=>'Călărași',
  'CS'=>'Caraș-Severin','CT'=>'Constanța','CV'=>'Covasna','DB'=>'Dâmbovița','DJ'=>'Dolj','GJ'=>'Gorj',
  'GL'=>'Galați','GR'=>'Giurgiu','HD'=>'Hunedoara','HR'=>'Harghita','IF'=>'Ilfov','IL'=>'Ialomița',
  'IS'=>'Iași','MH'=>'Mehedinți','MM'=>'Maramureș','MS'=>'Mureș','NT'=>'Neamț','OT'=>'Olt',
  'PH'=>'Prahova','SB'=>'Sibiu','SJ'=>'Sălaj','SM'=>'Satu Mare','SV'=>'Suceava','TL'=>'Tulcea',
  'TM'=>'Timiș','TR'=>'Teleorman','VL'=>'Vâlcea','VN'=>'Vrancea','VS'=>'Vaslui','BI'=>'București'
];
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="utf-8"/>
  <title>Proiect – COD SMIS <?= htmlspecialchars($smis) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <style>
    :root{ --gap:14px; --ring:#e2e8f0; --muted:#64748b; }
    *{ box-sizing:border-box; }
    body{ font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif; margin:0; background:#f7fafc; color:#0f172a; }
    header{ padding:18px 20px 10px; max-width:1200px; margin:0 auto; }
    a.back{ display:inline-flex; gap:8px; align-items:center; text-decoration:none; color:#0ea5e9; font-weight:600; }
    h1{ font-size:22px; margin:10px 0 4px; }
    .sub{ color:#64748b; margin-top:6px; }

    .controls{ display:flex; gap:12px; align-items:center; flex-wrap:wrap; padding:0 20px 10px; max-width:1200px; margin:0 auto; }
    .controls select{ padding:8px; border:1px solid var(--ring); border-radius:10px; background:#fff; min-width:220px; }
    .btn{ display:inline-block; padding:8px 12px; border-radius:10px; background:#e2e8f0; color:#0f172a; text-decoration:none; font-weight:700; border:0; cursor:pointer; }

    .wrap{ max-width:1200px; margin:0 auto 24px; padding:0 20px; }
    .card{ background:#fff; border-radius:16px; box-shadow:0 8px 24px rgba(2,6,23,.06); padding:16px; margin-bottom:12px; }

    .summary{ display:flex; flex-wrap:wrap; gap:16px; align-items:center; }
    .summary .pill{ display:inline-block; padding:4px 10px; border-radius:999px; background:#e2e8f0; font-size:12px; color:#0f172a; }
    .kv{ display:grid; grid-template-columns: 240px 1fr; gap:10px 14px; }
    .kv .k{ color:#64748b; font-weight:700; }
    .muted{ color:#64748b; }

    table{ width:100%; border-collapse:collapse; }
    th,td{ padding:10px 8px; border-bottom:1px solid var(--ring); text-align:left; vertical-align:top; }
    th{ color:#64748b; font-size:13px; }
    td.num{ text-align:right; font-variant-numeric: tabular-nums; }

    .btn.ghost{ background:#e2e8f0; color:#0f172a; }
    .mono{ font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }

    /* Pie card */
    .pie-card h3{ margin:0 0 8px; font-size:16px; }
    #budgetPie{ height: 360px; }
  </style>
</head>
<body>
<header>
  <a class="back" href="map_export.php?ds=<?=urlencode($DATA_FILE)?>">← Înapoi la export</a>
  <h1>Detalii proiect – COD SMIS <?= htmlspecialchars($smis) ?></h1>
  <div class="sub">Se caută proiectul în <span class="mono"><?= htmlspecialchars($DATA_FILE) ?></span> după codul SMIS.</div>
</header>

<!-- Dataset controls -->
<div class="controls">
  <label class="muted" for="datasetSel">Set date:</label>
  <select id="datasetSel">
    <?php foreach ($DATASETS as $ds): ?>
      <option value="<?= htmlspecialchars($ds['file']) ?>"
        <?= $ds['file'] === $DATA_FILE ? 'selected' : '' ?>>
        <?= htmlspecialchars($ds['label']) ?>
      </option>
    <?php endforeach; ?>
  </select>
  <!--<a class="btn" href="map.php?ds=<?= urlencode($DATA_FILE) ?>">Deschide harta cu acest set</a>-->
</div>

<div class="wrap">
  <!-- Summary -->
  <div class="card">
    <div class="summary" id="summary">
      <div class="pill">COD SMIS: <span id="smisTxt"><?= htmlspecialchars($smis) ?></span></div>
      <div class="pill" id="programPill" style="display:none"></div>
      <div class="pill" id="valuePill" style="display:none"></div>
      <div class="pill" id="projectsPill" style="display:none"></div>
      <div class="pill" id="implPill" style="display:none"></div>
    </div>
    <div id="titleBox" style="margin-top:10px; font-size:18px; font-weight:700;"></div>
    <div id="countiesBox" class="muted" style="margin-top:6px;"></div>
  </div>

  <!-- Key fields -->
  <div class="card">
    <h3 style="margin:0 0 10px 0; font-size:16px;">Câmpuri principale</h3>
    <div class="kv" id="keyFields"></div>
  </div>
  
    <!-- Pie chart for BUGET TOTAL ELIGIBIL -->
  <div class="card pie-card" id="pieCard" style="display:none;">
    <h3>Structura BUGET TOTAL ELIGIBIL (RON)</h3>
    <div id="budgetPie"></div>
    <div class="muted" id="pieNote"></div>
  </div>

  <!-- Full row (all columns) -->
  <div class="card">
    <h3 style="margin:0 0 10px 0; font-size:16px;">Toate câmpurile (din rând)</h3>
    <table>
      <thead><tr><th>Coloană</th><th>Valoare</th></tr></thead>
      <tbody id="allFields"></tbody>
    </table>
  </div>


</div>

<script>
/* ----- Carry current dataset to links ----- */
function addDs(url){
  const ds = <?= json_encode($DATA_FILE) ?>;
  return ds ? url + (url.includes('?') ? '&' : '?') + 'ds=' + encodeURIComponent(ds) : url;
}

/* ----- Dataset dropdown -> reload keeping current params (+ new ds) ----- */
const dsSel = document.getElementById('datasetSel');
if (dsSel){
  dsSel.addEventListener('change', (e) => {
    const ds = e.target.value;
    const params = new URLSearchParams(window.location.search);
    params.set('ds', ds); // preserves smis
    window.location.search = params.toString();
  });
}

const TARGET_SMIS = <?= json_encode($smis) ?>;
const COUNTY_MAP  = <?= json_encode($COUNTY_MAP, JSON_UNESCAPED_UNICODE) ?>;
const DATA_URL    = '<?=addslashes($DATA_FILE)?>';

const PROGRAMS = [
  {key:'PDD', label:'Programul Dezvoltare Durabilă'},
  {key:'PEO', label:'Programul Educație și Ocupare'},
  {key:'PIDS', label:'Programul Incluziune și Demnitate Socială'},
  {key:'POCIDIF', label:'Programul Creștere Inteligentă, Digitalizare și Instrumente Financiare'},
  {key:'PS', label:'Programul Sănătate'},
  {key:'PT', label:'Programul Transport'},
  {key:'PTJ', label:'Programul Tranziție Justă'},
  {key:'PR', label:'Programe Regionale'},
  {key:'OTHER', label:'Alte programe/necategorizate'}
];
const PROGRAM_LABEL = Object.fromEntries(PROGRAMS.map(p=>[p.key,p.label]));
const META_COLS = ['__program_key','__share_value','__share_projects','__counties_raw','__row_number','__program_label'];

const fmtMoney = n => new Intl.NumberFormat('ro-RO',{style:'currency',currency:'RON',maximumFractionDigits:0}).format(n||0);
const fmtNum    = n => new Intl.NumberFormat('ro-RO').format(n||0);
const labelize  = s => (s||'').replace(/^_+|_+$/g,'').replace(/_/g,' ').replace(/\s+/g,' ').replace(/\b\w/g,m=>m.toUpperCase());
const normKey   = s => String(s).toUpperCase().replace(/[^A-Z0-9]/g,'');

// Remove diacritics + normalize key name
function normalizeKeyName(s){
  return String(s||'')
    .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .replace(/ș|ş/g,'s').replace(/ț|ţ/g,'t')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g,'_')
    .replace(/^_+|_+$/g,'');
}

// Robust numeric parser (accepts "1.234.567,89" or "1,234,567.89")
function parseRON(val){
  if (val == null) return NaN;
  let s = String(val).trim();
  if (!s) return NaN;
  s = s.replace(/\s/g,'');
  if (s.includes('.') && s.includes(',')) s = s.replace(/\./g,'').replace(',','.');
  else if (s.includes(',')) s = s.replace(',','.');
  s = s.replace(/[^0-9.-]/g,'');
  const n = Number(s);
  return isFinite(n) ? n : NaN;
}

function normSmis(x){
  const s = String(x||'').trim();
  const digits = s.replace(/\D+/g,'');
  return digits || s.toUpperCase();
}

function getTargets(row){
  const raw = row['JUDEE_PROIECT_IMPLEMENTARE'] || row['JUDETE_PROIECT_IMPLEMENTARE'] || '';
  return String(raw).split(',').map(s => s.trim().toUpperCase()).filter(Boolean).map(c2=>{
    if (c2==='B'||c2==='BU'||c2==='BI') return 'BI';
    return c2.replace(/[^A-Z]/g,'').slice(0,2);
  });
}
function countiesHuman(codes){
  if (!codes.length) return '—';
  return codes.map(c2 => `${c2}${COUNTY_MAP[c2] ? ' ('+COUNTY_MAP[c2]+')' : ''}`).join(', ');
}

let rawData = [];
let colLabels = {};

async function load(){
  const r = await fetch(DATA_URL, {cache:'no-store'});
  if (!r.ok) throw new Error('Nu pot încărca funds.json');
  rawData = await r.json();
  if (!Array.isArray(rawData)) rawData = [];
  const withLabels = rawData.find(x => x.extras && x.extras.col_labels);
  colLabels = withLabels?.extras?.col_labels || {};
}

function findBySmis(){
  const wanted = normSmis(TARGET_SMIS);
  const hits = [];
  for (const county of rawData){
    const rows = Array.isArray(county.extras?.rows) ? county.extras.rows : [];
    for (const row of rows){
      const keys = Object.keys(row);
      let val = row.COD_SMIS;
      if (val == null){
        const alt = keys.find(k => normKey(k).includes('CODSMIS') || normKey(k)==='SMIS' || k.toUpperCase()==='COD SMIS');
        if (alt) val = row[alt];
      }
      if (val == null) continue;
      if (normSmis(val) === wanted){
        if (!row.__program_label && row.__program_key) row.__program_label = PROGRAM_LABEL[row.__program_key] || row.__program_key;
        hits.push({county: county.code, countyName: county.name, row});
      }
    }
  }
  return hits;
}

function setPill(elId, text){
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = text;
  el.style.display = 'inline-block';
}

function addKV(k, v){
  const box = document.getElementById('keyFields');
  const kEl = document.createElement('div'); kEl.className='k'; kEl.textContent = k;
  const vEl = document.createElement('div'); vEl.textContent = (v==null || String(v).trim()==='') ? '—' : String(v);
  box.appendChild(kEl); box.appendChild(vEl);
}

/* ----- Budget field resolution (defensive) ----- */
function pickBudgetFields(row){
  const keys = Object.keys(row || {});
  const map = {};
  keys.forEach(k => map[normalizeKeyName(k)] = k);

  const want = {
    totalElig: [
      'BUGET_TOTAL_ELIGIBIL','BUGET_TOTAL_ELIGIBIL_RON','VALOARE_TOTAL_ELIGIBILA','VALOARE_ELIGIBILA_TOTALA'
    ],
    totalUE: [
      'BUGET_TOTAL_UE','BUGET_UE_TOTAL','BUGET_UE','VALOARE_UE','BUGET_TOTAL_FONDURI_UE'
    ],
    totalStat: [
      'BUGET_DE_STAT_TOTAL','BUGET_STAT_TOTAL','BUGET_STAT','VALOARE_BUGET_STAT'
    ],
    totalContrib: [
      'BUGET_CONTRIBUTIE_PROPRIE_TOTALA','BUGET_CONTRIBUTIE_PROPRIE',
      'CONTRIBUTIE_PROPRIE_TOTALA','CONTRIBUTIE_PROPRIE',
      'COFINANTARE_BENEFICIAR','COFINANTARE','COFINANTARE_TOTALA',
      'COFINANTARE_PRIVATA','CONTRIBUTIE_BENEFICIAR'
    ]
  };

  function firstExisting(arr){
    for (const nk of arr){
      if (map[nk] != null) return map[nk];
      const hit = Object.keys(map).find(x => x.includes(nk));
      if (hit) return map[hit];
    }
    return null;
  }

  const totalEligKey = firstExisting(want.totalElig);
  const totalUEKey   = firstExisting(want.totalUE);
  const totalStatKey = firstExisting(want.totalStat);
  const totalConKey  = firstExisting(want.totalContrib);

  const totalElig    = parseRON(totalEligKey ? row[totalEligKey] : null);
  const bugetUE      = parseRON(totalUEKey ? row[totalUEKey] : null);
  const bugetStat    = parseRON(totalStatKey ? row[totalStatKey] : null);
  const bugetContrib = parseRON(totalConKey ? row[totalConKey] : null);

  return {
    totalEligKey, totalUEKey, totalStatKey, totalConKey,
    totalElig, bugetUE, bugetStat, bugetContrib
  };
}

/* ----- PIE: BUGET TOTAL ELIGIBIL composition ----- */
function renderBudgetPie(row){
  const b = pickBudgetFields(row);
  const pieCard = document.getElementById('pieCard');
  const noteEl  = document.getElementById('pieNote');

  const slices = [];
  if (isFinite(b.bugetUE) && b.bugetUE > 0)           slices.push({ name:'BUGET TOTAL UE', y:b.bugetUE });
  if (isFinite(b.bugetStat) && b.bugetStat > 0)       slices.push({ name:'BUGET DE STAT TOTAL', y:b.bugetStat });
  if (isFinite(b.bugetContrib) && b.bugetContrib > 0) slices.push({ name:'BUGET CONTRIBUȚIE PROPRIE TOTALĂ', y:b.bugetContrib });

  if (!slices.length){ pieCard.style.display = 'none'; return; }

  const totalEligValid = isFinite(b.totalElig) && b.totalElig > 0;
  const partsSum = slices.reduce((s,x)=>s+(x.y||0),0);
  const tol  = totalEligValid ? Math.max(1, 0.005 * b.totalElig) : 0;

  // If components don't reach the Eligible Total, add a "completion" slice under the same label
  let addedDiff = false;
  if (totalEligValid && partsSum < (b.totalElig - tol)) {
    const diff = b.totalElig - partsSum;
    slices.push({ name:'BUGET CONTRIBUȚIE PROPRIE TOTALĂ', y: diff });
    addedDiff = true;
  }

  let msg = '';
  if (totalEligValid){
    const newSum = slices.reduce((s,x)=>s+(x.y||0),0);
    const ok = Math.abs(newSum - b.totalElig) <= tol;
    if (ok && addedDiff) {
      msg = `Completat cu „(BUGET CONTRIBUȚIE PROPRIE TOTALĂ)” - BUGET TOTAL ELIGIBIL (${fmtMoney(b.totalElig)}).`;
    } else if (ok) {
      msg = `Suma componentelor se potrivește cu BUGET TOTAL ELIGIBIL (${fmtMoney(b.totalElig)}).`;
    } else {
      msg = `Atenție: suma componentelor (${fmtMoney(newSum)}) diferă de BUGET TOTAL ELIGIBIL (${fmtMoney(b.totalElig)}).`;
    }
  } else {
    msg = 'BUGET TOTAL ELIGIBIL indisponibil sau zero; se afișează doar componentele găsite.';
  }

  pieCard.style.display = 'block';
  noteEl.textContent = msg;

  Highcharts.chart('budgetPie', {
    chart: { type: 'pie' },
    title: { text: 'Structura BUGET TOTAL ELIGIBIL' },
    subtitle: totalEligValid ? { text: 'BUGET TOTAL ELIGIBIL: ' + fmtMoney(b.totalElig) } : undefined,
    tooltip: {
      useHTML: true,
      pointFormatter: function(){ return `<span>●</span> ${this.name}: <b>${fmtMoney(this.y)}</b>`; }
    },
    plotOptions: {
      pie: {
        innerSize: '55%',
        dataLabels: {
          enabled: true,
          formatter(){ return this.percentage ? Highcharts.numberFormat(this.percentage,1)+'%' : null; }
        }
      }
    },
    series: [{ name: 'Valoare', data: slices }],
    credits: { enabled: false },
    exporting: { enabled: true }
  });
}

function renderOne(hit){
  const row = hit.row || {};
  const title = row.TITLU_PROIECT || row['TITLU PROIECT'] || row['Titlu_Proiect'] || '';
  document.getElementById('titleBox').textContent = title || 'TITLU PROIECT indisponibil';

  if (row.__program_key) setPill('programPill', (PROGRAM_LABEL[row.__program_key] || row.__program_key));
  if (row.__share_value!=null) setPill('valuePill', 'Valoare (share): ' + fmtMoney(row.__share_value));
  if (row.__share_projects!=null) setPill('projectsPill', 'Proiecte (share): ' + fmtNum(row.__share_projects));
  if (row.IMPLEMENTARE) setPill('implPill', 'Implementare: ' + String(row.IMPLEMENTARE));

  const targets = getTargets(row);
  document.getElementById('countiesBox').textContent = 'Județe implicate: ' + countiesHuman(targets);

  // Budget keys/values
  const b = pickBudgetFields(row);

  const keysBox = document.getElementById('keyFields'); keysBox.innerHTML='';
  addKV('COD SMIS', row.COD_SMIS || '');
  addKV('Program (cheie)', row.__program_key || '—');
  addKV('Program (etichetă)', row.__program_label || PROGRAM_LABEL[row.__program_key] || '—');
  addKV('BUGET TOTAL ELIGIBIL (RON)', isFinite(b.totalElig) && b.totalElig>0 ? fmtMoney(b.totalElig) : '—');
  addKV('BUGET TOTAL UE (RON)',       isFinite(b.bugetUE) && b.bugetUE>0 ? fmtMoney(b.bugetUE) : '—');
  addKV('BUGET DE STAT TOTAL (RON)',  isFinite(b.bugetStat) && b.bugetStat>0 ? fmtMoney(b.bugetStat) : '—');
  //addKV('BUGET CONTRIBUȚIE PROPRIE TOTALĂ (RON)', isFinite(b.bugetContrib) && b.bugetContrib>0 ? fmtMoney(b.bugetContrib) : '—');

  addKV(colLabels['PROGRAMUL'] || 'PROGRAMUL', row.PROGRAMUL || row['PROGRAMUL'] || '—');
  addKV(colLabels['PRIORITATE'] || 'PRIORITATE', row.PRIORITATE || row['PRIORITATE'] || '—');
  addKV(colLabels['STATUS'] || 'STATUS', row.STATUS || '—');
  addKV(colLabels['IMPLEMENTARE'] || 'IMPLEMENTARE', row.IMPLEMENTARE || '—');
  addKV('Județe implicate', countiesHuman(targets));
  addKV(colLabels['SCOP_PROIECT'] || 'SCOP PROIECT', row.SCOP_PROIECT || '—');

  // All fields table
  const tbody = document.getElementById('allFields'); tbody.innerHTML='';
  const keys = Object.keys(row);
  const showOrder = [];
  const preferred = [
    'TITLU_PROIECT','PROGRAMUL','PRIORITATE','STATUS','IMPLEMENTARE',
    'JUDEE_PROIECT_IMPLEMENTARE','JUDETE_PROIECT_IMPLEMENTARE',
    'SCOP_PROIECT',
    'BUGET_TOTAL_ELIGIBIL','BUGET_TOTAL_UE','BUGET_DE_STAT_TOTAL','BUGET_CONTRIBUTIE_PROPRIE_TOTALA'
  ];
  const byNorm = Object.fromEntries(keys.map(k => [normKey(k), k]));
  preferred.forEach(p=>{ const k = byNorm[normKey(p)]; if (k && !showOrder.includes(k)) showOrder.push(k); });
  keys.forEach(k=>{ if (!META_COLS.includes(k) && !showOrder.includes(k)) showOrder.push(k); });

  for (const k of showOrder){
    const tr = document.createElement('tr');
    const th = document.createElement('th'); th.textContent = colLabels[k] || labelize(k);
    const td = document.createElement('td');
    let v = row[k];
    if (k==='__share_value') v = fmtMoney(v||0);
    if (k==='__share_projects') v = fmtNum(v||0);
    if (k==='JUDEE_PROIECT_IMPLEMENTARE' || k==='JUDETE_PROIECT_IMPLEMENTARE') v = countiesHuman(getTargets(row));
    td.textContent = (v==null || String(v).trim()==='') ? '—' : String(v);
    tr.appendChild(th); tr.appendChild(td);
    tbody.appendChild(tr);
  }

  // PIE (budget composition)
  renderBudgetPie(row);
}

function renderMultipleChoice(hits){
  const container = document.createElement('div');
  container.className = 'card';
  const h3 = document.createElement('h3'); h3.style.margin='0 0 10px 0'; h3.style.fontSize='16px';
  h3.textContent = 'S-au găsit mai multe rezultate. Alege unul:';
  container.appendChild(h3);

  const ul = document.createElement('ul');
  ul.style.listStyle='none'; ul.style.padding='0'; ul.style.margin='0';
  hits.forEach((h, i)=>{
    const li = document.createElement('li');
    li.style.padding='8px 0'; li.style.borderBottom='1px solid var(--ring)';
    const a = document.createElement('a'); a.href='#'; a.className='btn ghost';
    const prog = h.row.__program_label || PROGRAM_LABEL[h.row.__program_key] || h.row.__program_key || '';
    a.textContent = `${h.countyName || h.county} • ${prog || 'Program necunoscut'}`;
    a.addEventListener('click', (e)=>{ e.preventDefault(); renderOne(h); container.remove(); });
    li.appendChild(a); ul.appendChild(li);
  });
  container.appendChild(ul);
  document.querySelector('.wrap').insertBefore(container, document.querySelector('.wrap').children[1]);
}

(async function boot(){
  try{
    await load();
    const hits = findBySmis();
    if (!hits.length){
      document.getElementById('titleBox').textContent = 'Nu am găsit niciun proiect cu acest COD SMIS.';
      document.getElementById('countiesBox').textContent = '';
      document.getElementById('pieCard').style.display = 'none';
      return;
    }
    if (hits.length > 1) renderMultipleChoice(hits);
    renderOne(hits[0]);
  }catch(e){
    console.warn(e);
    alert('A apărut o eroare la încărcarea datelor.');
  }
})();
</script>
</body>
</html>
```
