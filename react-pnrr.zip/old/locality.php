<?php
// locality.php — lists all projects that mention a given locality in SCOP_PROIECT

$COUNTY_MAP = [
  'AB'=>'Alba','AG'=>'Argeș','AR'=>'Arad','BC'=>'Bacău','BH'=>'Bihor','BN'=>'Bistrița-Năsăud',
  'BR'=>'Brăila','BT'=>'Botoșani','BV'=>'Brașov','BZ'=>'Buzău','CJ'=>'Cluj','CL'=>'Călărași',
  'CS'=>'Caraș-Severin','CT'=>'Constanța','CV'=>'Covasna','DB'=>'Dâmbovița','DJ'=>'Dolj','GJ'=>'Gorj',
  'GL'=>'Galați','GR'=>'Giurgiu','HD'=>'Hunedoara','HR'=>'Harghita','IF'=>'Ilfov','IL'=>'Ialomița',
  'IS'=>'Iași','MH'=>'Mehedinți','MM'=>'Maramureș','MS'=>'Mureș','NT'=>'Neamț','OT'=>'Olt',
  'PH'=>'Prahova','SB'=>'Sibiu','SJ'=>'Sălaj','SM'=>'Satu Mare','SV'=>'Suceava','TL'=>'Tulcea',
  'TM'=>'Timiș','TR'=>'Teleorman','VL'=>'Vâlcea','VN'=>'Vrancea','VS'=>'Vaslui','BI'=>'București'
];

$code = isset($_GET['c']) ? strtoupper(trim($_GET['c'])) : '';
if (in_array($code, ['BI','BU'])) $code = 'BI';
$city = isset($_GET['city']) ? trim($_GET['city']) : '';

if (!$code || !isset($COUNTY_MAP[$code]) || !$city) {
  http_response_code(400);
  echo "Parametri lipsă sau invalizi.";
  exit;
}
$name = $COUNTY_MAP[$code];

/* ==== DATASET PICKER (like map.php / map_export.php) ==== */
$dir = __DIR__;
$DATA_FILE = 'funds.json';

// Collect dated datasets and sort DESC by date in filename: DDMMYYYY-funds.json
$dated = glob($dir . '/*-funds.json') ?: [];
usort($dated, function($a, $b){
  $fa = basename($a); $fb = basename($b);
  preg_match('/(\d{8})-funds\.json$/', $fa, $ma);
  preg_match('/(\d{8})-funds\.json$/', $fb, $mb);
  $ta = isset($ma[1]) ? DateTime::createFromFormat('dmY', $ma[1]) : false;
  $tb = isset($mb[1]) ? DateTime::createFromFormat('dmY', $mb[1]) : false;
  $tsa = $ta ? (int)$ta->format('U') : 0;
  $tsb = $tb ? (int)$tb->format('U') : 0;
  return $tsb <=> $tsa; // newest first
});

// Build options (dated first, then legacy funds.json if present)
$DATASETS = [];
foreach ($dated as $path){
  $base = basename($path);
  preg_match('/(\d{8})-funds\.json$/', $base, $m);
  $label = isset($m[1]) ? DateTime::createFromFormat('dmY', $m[1])->format('d.m.Y') : $base;
  $DATASETS[] = ['file'=>$base, 'label'=>$label];
}
if (is_file($dir . '/funds.json')) {
  $DATASETS[] = ['file'=>'funds.json', 'label'=>'funds.json (legacy)'];
}

// Pick current dataset from ?ds=..., else latest dated, else funds.json
$dsParam = isset($_GET['ds']) ? basename($_GET['ds']) : '';
if ($dsParam && is_file($dir . '/' . $dsParam)) {
  $DATA_FILE = $dsParam;
} elseif (!empty($DATASETS)) {
  $DATA_FILE = $DATASETS[0]['file'];
} elseif (is_file($dir . '/funds.json')) {
  $DATA_FILE = 'funds.json';
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="utf-8" />
  <title><?=htmlspecialchars($city)?> – proiecte în <?=htmlspecialchars($name)?> (<?=$code?>)</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <!-- Highcharts -->
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/maps/modules/map.js"></script>

  <style>
    :root{ --gap:14px; --ring:#e2e8f0; --muted:#64748b; }
    *{ box-sizing:border-box; }
    body{ font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif; margin:0; background:#f7fafc; color:#0f172a;}
    header{ padding:18px 20px 12px; max-width:1200px; margin:0 auto; }
    a.back{ display:inline-flex; gap:8px; align-items:center; text-decoration:none; color:#0ea5e9; font-weight:600; }
    h1{ font-size:22px; margin:10px 0 4px; }
    .sub{ color:var(--muted); margin-bottom:8px; }
    .wrap{ max-width:1200px; margin:0 auto 24px; padding:0 20px; }
    .card{ background:#fff; border-radius:16px; box-shadow:0 8px 24px rgba(2,6,23,.06); padding:16px; }

    .controls{ display:flex; gap:12px; flex-wrap:wrap; align-items:center; margin:0 0 12px; }
    .controls select{ padding:8px; border:1px solid var(--ring); border-radius:10px; background:#fff; min-width:220px; }
    .btn{ display:inline-block; padding:8px 12px; border-radius:10px; background:#0ea5e9; color:#fff; text-decoration:none; font-weight:700; border:0; cursor:pointer; }
    .btn.ghost{ background:#e2e8f0; color:#0f172a; }
    .btn.secondary{ background:#334155; }

    /* Map card */
    #countryMap{ width:100%; height:460px; display:block; }
    #countryMapSummary{ color:var(--muted); margin-top:8px; }

    /* 50/50 grid under the map */
    .below-grid{
      display:grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--gap);
      margin-top: var(--gap);
    }
    @media (max-width: 960px){ .below-grid{ grid-template-columns: 1fr; } }

    /* Pie card */
    .pie-card h3{ margin:0 0 8px; font-size:16px; }
    #localProgramsPie{ height: 360px; }

    /* Ranking card */
    .rank-card h3{ margin:0 0 10px; font-size:16px; }
    .rank-note{ color:#475569; font-size:13px; margin-top:6px; }
    .rank-list{ list-style:none; padding:0; margin:0; }
    .rank-item{ display:flex; align-items:center; gap:10px; padding:8px 6px; border-bottom:1px solid #e2e8f0; cursor:pointer; }
    .rank-item:last-child{ border-bottom:0; }
    .rank-pos{ width:26px; text-align:right; font-weight:700; color:#334155; }
    .rank-name{ flex:1 1 auto; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .rank-value{ width:140px; text-align:right; font-variant-numeric: tabular-nums; }
    .rank-bar-wrap{ flex: 0 0 180px; height:8px; background:#e5e7eb; border-radius:999px; overflow:hidden; }
    .rank-bar{ height:100%; background:#60a5fa; }
    .rank-item:hover .rank-bar{ filter:brightness(0.9); }

    .extras-controls{ display:flex; gap:12px; flex-wrap:wrap; align-items:center; margin:10px 0; }
    .extras-controls input[type="text"], .extras-controls select{
      padding:8px; border:1px solid var(--ring); border-radius:10px; background:#fff;
    }
    .pill{ display:inline-block; padding:3px 8px; border-radius:999px; background:#e2e8f0; font-size:12px; color:#0f172a; }
    .muted{ color:var(--muted); }

    .colpicker-wrap{ position:relative; }
    .colpicker{ position:absolute; z-index:20; right:0; top:44px; min-width:320px; max-height:320px; overflow:auto;
      background:#fff; border:1px solid var(--ring); border-radius:12px; box-shadow:0 8px 24px rgba(2,6,23,.12); padding:10px; display:none;}
    .colpicker.show{ display:block; }
    .colpicker h4{ margin:2px 0 8px; font-size:14px;}
    .colgrid{ display:grid; grid-template-columns:1fr 1fr; gap:6px 12px; }
    .colgrid label{ display:flex; align-items:center; gap:6px; font-size:13px; }
    .picker-actions{ display:flex; gap:8px; margin-top:10px; flex-wrap:wrap; }

    table{ width:100%; border-collapse:collapse; margin-top:10px; }
    th, td{ padding:10px 8px; border-bottom:1px solid var(--ring); text-align:left; vertical-align:top; }
    th{ font-size:13px; color:var(--muted); font-weight:700; }
    td.num{ text-align:right; font-variant-numeric: tabular-nums; }

    .nowrap{ white-space:nowrap; }
    .scroll-x{ overflow-x:auto; }
	
	/* KPI stats */
.stats-grid{
  display:grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--gap);
  margin: 0 0 var(--gap) 0;
}
@media (max-width: 960px){ .stats-grid{ grid-template-columns:1fr; } }

.stat-card{
  background:#fff; border-radius:16px; box-shadow:0 8px 24px rgba(2,6,23,.06);
  padding:16px; display:flex; flex-direction:column; gap:6px;
}
.stat-label{ font-size:13px; color:var(--muted); }
.stat-main{ font-size:22px; font-weight:800; line-height:1.2; }
.stat-sub{ font-size:13px; color:#475569; }
.stat-accent{ color:#0ea5e9; font-weight:700; }

  </style>
</head>
<body>
<header>
  <a class="back" href="judet.php?c=<?=urlencode($code)?>&ds=<?= urlencode($DATA_FILE) ?>">← Înapoi la județ</a>
  <h1><?=htmlspecialchars($city)?> — <?=htmlspecialchars($name)?> (<?=$code?>)</h1>
  <div class="sub">Proiecte care menționează localitatea în câmpul <span class="nowrap">„SCOP_PROIECT”</span> • Set date: <strong><?= htmlspecialchars($DATA_FILE) ?></strong></div>
</header>

<div class="wrap">

  <!-- Dataset controls -->
  <div class="controls">
    <label for="datasetSel" class="muted">Set date (dataset JSON):</label>
    <select id="datasetSel">
      <?php foreach ($DATASETS as $ds): ?>
        <option value="<?= htmlspecialchars($ds['file']) ?>"
          <?= $ds['file'] === $DATA_FILE ? 'selected' : '' ?>>
          <?= htmlspecialchars($ds['label']) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <!--<a class="btn ghost" href="map.php?ds=<?= urlencode($DATA_FILE) ?>">Deschide harta cu acest set</a>-->
  </div>
  
  <!-- KPI TOP BOXES -->
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-label">Total valoare</div>
    <div class="stat-main" id="kpiTotalVal">—</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Total proiecte</div>
    <div class="stat-main" id="kpiTotalProj">—</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Top program</div>
    <div class="stat-main" id="kpiTopProgram">—</div>
    <div class="stat-sub" id="kpiTopProgramVal">—</div>
  </div>
</div>



  <!-- COUNTY-ONLY MAP -->
  <div class="card">
    <h3 style="margin:0 0 8px 0;">Harta localităților cu proiecte (doar județul <?=htmlspecialchars($name)?>)</h3>
    <div id="countryMap"></div>
    <div id="countryMapSummary" class="muted">—</div>
  </div>

  <!-- 50/50: pie + localities ranking (by value) -->
  <div class="below-grid">
    <div class="card pie-card">
      <div id="localProgramsPie"></div>
    </div>

    <div class="card rank-card">
      <h3>Clasament localități în <?=htmlspecialchars($name)?> – după valoare</h3>
      <ol id="locRankList" class="rank-list"></ol>
      <div class="rank-note">Clic pe o localitate pentru a deschide pagina ei. (Ctrl/⌘-clic pentru un nou tab.)</div>
    </div>
  </div>

  <!-- Results table with extras-like filters -->
  <div class="card" style="margin-top:14px;">
    <div class="extras-controls">
      <label class="pill">Filtre</label>
      <select id="programFilter"></select>
      <input id="searchBox" type="text" placeholder="Caută text în rezultate…" />

      <label style="display:inline-flex; align-items:center; gap:6px;">
        <input type="checkbox" id="showAllCols" />
        Arată toate coloanele
      </label>

      <div class="colpicker-wrap">
        <button class="btn secondary" id="pickColsBtn" type="button">Alege coloane…</button>
        <div class="colpicker" id="colPicker" aria-label="Selectează coloanele">
          <h4>Selectează coloanele de afișat</h4>
          <div class="colgrid" id="colGrid"><!-- checkboxes --></div>
          <div class="picker-actions">
            <button type="button" class="btn ghost" id="colSelectAllBtn">Selectează toate</button>
            <button type="button" class="btn ghost" id="colClearBtn">Golește selecția</button>
            <button type="button" class="btn ghost" id="colDefaultBtn">Revino la implicite</button>
            <button type="button" class="btn" id="colApplyBtn">Aplică & închide</button>
          </div>
        </div>
      </div>

      <button class="btn secondary" id="exportBtn" type="button">Exportă rezultate (CSV)</button>
      <span class="muted" id="countInfo" style="margin-left:auto">—</span>
    </div>

    <div class="scroll-x">
      <table id="tbl">
        <thead><tr id="tblHead"></tr></thead>
        <tbody id="tblBody"></tbody>
      </table>
    </div>

    <div style="display:flex; gap:8px; justify-content:flex-end; align-items:center; margin-top:10px;">
      <button class="btn secondary" id="prevBtn" type="button">‹ Anterioare</button>
      <span class="muted" id="pageInfo">Pagina 1</span>
      <button class="btn secondary" id="nextBtn" type="button">Următoare ›</button>
    </div>
  </div>
</div>

<script>
// ---- server-provided vars ----
const COUNTY_2   = '<?= addslashes($code) ?>';
const COUNTY_NAME= '<?= addslashes($name) ?>';
const CITY_NAME  = '<?= addslashes($city) ?>';

const DATA_URL   = '<?= addslashes($DATA_FILE) ?>';
const DS_FILE    = '<?= addslashes($DATA_FILE) ?>';
const CITIES_URL = 'data/ro_localities.min.json';

// Dataset switch => reload with same state, new ?ds=...
const dsSel = document.getElementById('datasetSel');
if (dsSel) {
  dsSel.addEventListener('change', (e) => {
    const ds = e.target.value;
    const params = new URLSearchParams(window.location.search);
    params.set('ds', ds);
    params.set('c', COUNTY_2);
    params.set('city', CITY_NAME);
    window.location.search = params.toString();
  });
}

// Programs (pretty labels + pie colors)
const PROGRAMS = [
  {key:'PDD', label:'Programul Dezvoltare Durabilă'},
  {key:'PEO', label:'Programul Educație și Ocupare'},
  {key:'PIDS', label:'Programul Incluziune și Demnitate Socială'},
  {key:'POCIDIF', label:'Programul Creștere Inteligentă, Digitalizare și Instrumente Financiare'},
  {key:'PS', label:'Programul Sănătate'},
  {key:'PT', label:'Programul Transport'},
  {key:'PTJ', label:'Programul Tranziție Justă'},
  {key:'PR', label:'Programe Regionale'}
];
const PROGRAM_LABEL  = Object.fromEntries(PROGRAMS.map(p=>[p.key,p.label]));
const PROGRAM_COLORS = {
  PDD:'#0ea5e9', PEO:'#6366f1', PIDS:'#ef4444', POCIDIF:'#a855f7',
  PS:'#f59e0b', PT:'#06b6d4', PTJ:'#f97316', PR:'#334155', OTHER:'#94a3b8'
};

// ---- Utils ----
function escapeHtml(s){ return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

const norm = s => (s || '')
  .toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
  .replace(/ș|ş/g,'s').replace(/ț|ţ/g,'t')
  .toLowerCase().trim();

function escapeRegExp(s){ return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }
const niceNum  = n => new Intl.NumberFormat('ro-RO').format(n||0);
const fmtMoney = n => new Intl.NumberFormat('ro-RO',{style:'currency',currency:'RON',maximumFractionDigits:0}).format(n||0);
const labelize = s => (s||'').replace(/^_+|_+$/g,'').replace(/_/g,' ').replace(/\s+/g,' ').replace(/\b\w/g,m=>m.toUpperCase());

// ---- Data state ----
let countyRow   = null;
let extrasRows  = [];  // all rows for this county
let resultsRows = [];  // rows that mention CITY_NAME in SCOP_PROIECT

// Column state (match extras order request)
const META_COLS = ['__program_key','__share_value','__share_projects','__counties_raw','__row_number','__program_label'];
const DEFAULT_EXTRA_COLS_RAW = ['STATUS','PROGRAMUL','PRIORITATE','OBIECTIVE_SPECIFICE','FOND'];
const normKey = s => String(s).toUpperCase().replace(/[^A-Z0-9]/g,'');

let COL_LABELS = {};
let allCols = [];            // union keys (no meta)
let chosenCols = [];         // user selected
let primaryCols = [];        // auto top N (fallback)
let showAllCols = false;

let filtered = [];           // after program+search
let page = 1;
const PAGE_SIZE = 10;

// ---- Loaders ----
async function loadJSON(url){
  const r = await fetch(url, {cache:'no-store'});
  if (!r.ok) throw new Error('fetch failed: ' + url);
  return await r.json();
}

function buildAliasSet(base, extraAliases){
  const al = new Set([
    base, ...(extraAliases || []),
    `Municipiul ${base}`, `Orașul ${base}`, `Orasul ${base}`,
    `Comuna ${base}`, `Satul ${base}`,
    base.replace(/-/g,' '), base.replace(/ /g,'-')
  ].map(norm));
  return al;
}
function buildCountyCityIndex(allCities){
  return (allCities||[])
    .filter(c => (c.county||'').toUpperCase() === COUNTY_2)
    .map(c => ({ name:c.name, lat:+c.lat, lon:+c.lon, aliases:Array.from(buildAliasSet(c.name, c.aliases||[])) }));
}

// =================== COUNTY-ONLY MAP with locality pins (count-based) ===================
async function renderCountyMapWithCities(cities){
  const MAP_URL = 'https://code.highcharts.com/mapdata/countries/ro/ro-all.topo.json';

  const res = await fetch(MAP_URL, {cache:'no-store'});
  if (!res.ok) return;
  const topo = await res.json();
  const all  = Highcharts.geojson(topo);

  const isBucharest = (COUNTY_2 === 'BI');
  const isoTarget = `RO-${COUNTY_2}`;
  const hcKeySet  = new Set([`ro-${COUNTY_2.toLowerCase()}`]); if (isBucharest) hcKeySet.add('ro-b');
  const postalSet = new Set(isBucharest ? ['B','BU','BI'] : [COUNTY_2]);
  const nameSet   = new Set([ norm(COUNTY_NAME), norm(`Judetul ${COUNTY_NAME}`), norm(`Județul ${COUNTY_NAME}`),
                              ...(isBucharest ? [norm('Bucuresti'), norm('Municipiul Bucuresti'), norm('Municipiul București')] : []) ]);

  const countyFeatures = all.filter(f=>{
    const p=f.properties||{};
    const name = norm(p.name||p.NAME||'');
    const hc   = (p['hc-key']||p.hcKey||'').toLowerCase();
    const post = (p['postal-code']||p.postal||p['postal_code']||'').toUpperCase();
    const iso  = (p['iso_3166_2']||p['iso-3166-2']||p.iso3166_2||'').toUpperCase();
    const id   = (p.id||'').toUpperCase();
    const hasc = (p.hasc||'').toUpperCase();
    if (iso===isoTarget) return true;
    if (id===isoTarget || id===isoTarget.replace('-', '.')) return true;
    if (post && postalSet.has(post)) return true;
    if (hc && hcKeySet.has(hc)) return true;
    if (hasc && (hasc===`RO.${COUNTY_2}` || (isBucharest && (hasc==='RO.B'||hasc==='RO.BU')))) return true;
    if (name && nameSet.has(name)) return true;
    return false;
  });
  if (!countyFeatures.length) return;

  const cityIndex = buildCountyCityIndex(cities);
  const hits = countLocalitiesFromScopeForCounty(cityIndex, extrasRows); // count only (map)

  const points = hits.map(h=>{
    const isCurrent = (h.city.name === CITY_NAME);
    const radius = Math.min(12, 4 + Math.log(1 + h.count) * 3);
    return {
      name: h.city.name, lat: h.city.lat, lon: h.city.lon, count: h.count, isCurrent,
      marker:{ radius, fillColor: isCurrent ? '#0ea5e9' : '#ef4444', lineColor:'#fff', lineWidth:1.2 }
    };
  });

  const chart = Highcharts.mapChart('countryMap', {
    chart: { map: { type:'FeatureCollection', features: countyFeatures }, backgroundColor:'transparent', spacing:[0,0,0,0] },
    title: { text: null }, credits:{enabled:false},
    mapNavigation:{ enabled:true, enableDoubleClickZoomTo:true, buttonOptions:{ verticalAlign:'bottom' } },
    legend:{ enabled:false },
    tooltip:{
      useHTML:true,
      formatter:function(){ const p=this.point; if(!p) return false;
        return `<b>${p.name}</b><br/>Proiecte: <b>${p.count}</b>`;
      }
    },
    series:[
      {
        type:'map',
        name: COUNTY_NAME,
        data: countyFeatures,
        color:'#e5e7eb',
        borderColor:'#94a3b8',
        borderWidth:0.9,
        enableMouseTracking:false
      },
      {
        type:'mappoint',
        name:'Localități cu proiecte',
        data: points,
        cursor:'pointer',
        dataLabels:{
          enabled:true, allowOverlap:false,
          formatter:function(){
            const mv=this.series.chart.mapView; const zoom = mv && typeof mv.zoom==='number' ? mv.zoom : 0;
            const pt=this.point;
            if (pt.isCurrent) return pt.name;
            if (pt.count>=3) return pt.name;
            if (zoom>6 && pt.count>=1) return pt.name;
            return null;
          },
          style:{ fontSize:'10px', textOutline:'none' }
        },
        point:{ events:{ click:function(e){
          const url = `locality.php?c=${COUNTY_2}&city=${encodeURIComponent(this.name)}&ds=${encodeURIComponent(DS_FILE)}`;
          if (e?.originalEvent?.ctrlKey || e?.originalEvent?.metaKey) window.open(url, '_blank');
          else window.location.assign(url);
        }}}
      }
    ]
  });

  if (chart?.mapView && countyFeatures[0]?.bounds) {
    chart.mapView.fitToBounds(countyFeatures[0].bounds, { padding:20 });
  }

  const summary = document.getElementById('countryMapSummary');
  if (summary) summary.textContent = `${points.length} localități cu proiecte în ${COUNTY_NAME} • localitatea curentă este albastră.`;

  // Also render the value-based ranking under the map:
  const valueAggs = aggregateLocalitiesValue(cityIndex, extrasRows); // sums __share_value
  renderLocalityRanking(valueAggs);
}

// Count localities (projects) for map pins (once per row per locality)
function countLocalitiesFromScopeForCounty(cityIndex, rows){
  const counts=new Map();
  for (const row of (rows||[])){
    const text = norm(row?.SCOP_PROIECT || row?.Scop_Proiect || row?.Scop || '');
    if (!text) continue;
    const matchedThisRow = new Set();
    for (const city of cityIndex){
      if (matchedThisRow.has(city.name)) continue;
      for (const alias of city.aliases){
        if (!alias) continue;
        const re = new RegExp(`(^|[^a-z0-9])${escapeRegExp(alias)}([^a-z0-9]|$)`, 'i');
        if (re.test(text)){ matchedThisRow.add(city.name); break; }
      }
    }
    matchedThisRow.forEach(name=>{
      const city = cityIndex.find(c => c.name === name);
      const prev = counts.get(name);
      counts.set(name, { city, count:(prev?.count||0)+1 });
    });
  }
  return Array.from(counts.values()).sort((a,b)=> b.count - a.count);
}

// Aggregate VALUE per locality (sum __share_value once per row that mentions it)
function aggregateLocalitiesValue(cityIndex, rows){
  const map = new Map();
  for (const row of (rows||[])){
    const text = norm(row?.SCOP_PROIECT || row?.Scop_Proiect || row?.Scop || '');
    if (!text) continue;
    const val = Number(row?.__share_value || 0);
    const matchedThisRow = new Set();
    for (const city of cityIndex){
      if (matchedThisRow.has(city.name)) continue;
      for (const alias of city.aliases){
        if (!alias) continue;
        const re = new RegExp(`(^|[^a-z0-9])${escapeRegExp(alias)}([^a-z0-9]|$)`, 'i');
        if (re.test(text)){ matchedThisRow.add(city.name); break; }
      }
    }
    matchedThisRow.forEach(name=>{
      const city = cityIndex.find(c => c.name === name);
      const prev = map.get(name);
      map.set(name, { city, value:(prev?.value||0)+val });
    });
  }
  return Array.from(map.values()).sort((a,b)=> (b.value||0) - (a.value||0));
}

// =============== PIE: Distribuție pe programe (pentru localitatea curentă) ===============
let pieChart = null;
function computeProgramTotalsForCity(){
  const acc = {};
  const ensure = k => (acc[k] ||= { key:k, label: PROGRAM_LABEL[k] || k, value:0 });

  for (const r of (resultsRows||[])){
    const k = r.__program_key || 'OTHER';
    const v = Number(r.__share_value || 0);
    ensure(k).value += v;
  }
  return Object.values(acc).filter(x=>x.value>0).sort((a,b)=>b.value-a.value);
}
function renderProgramsPieForCity(){
  const totals = computeProgramTotalsForCity();
  const seriesData = totals.map(t => ({
    name: t.label,
    y: t.value,
    color: PROGRAM_COLORS[t.key] || undefined
  }));
  const pieTitle = `Distribuție pe programe – ${CITY_NAME}`;

  if (!pieChart){
    pieChart = Highcharts.chart('localProgramsPie', {
      chart: { type:'pie' },
      title: { text: pieTitle },
      tooltip: {
        useHTML: true,
        pointFormatter: function(){
          return `<span style="color:${this.color}">●</span> ${this.name}: <b>${fmtMoney(this.y)}</b>`;
        }
      },
      plotOptions: {
        pie: {
          innerSize: '55%',
          dataLabels: {
            enabled: true,
            formatter: function(){
              return this.percentage ? Highcharts.numberFormat(this.percentage, 1) + '%' : null;
            }
          }
        }
      },
      series: [{ name:'Programe', data: seriesData } ],
      credits: { enabled:false },
      exporting: { enabled:true }
    });
  } else {
    pieChart.update({
      title:{ text: pieTitle },
      series:[{ data: seriesData }]
    }, true, true);
  }
}

// =============== Localities ranking (by value) UI ===============
function renderLocalityRanking(aggs){
  const listEl = document.getElementById('locRankList');
  if (!listEl) return;
  listEl.innerHTML = '';

  const maxVal = aggs.length ? (aggs[0].value || 0) : 1;
  aggs.forEach((item, idx) => {
    const pct = maxVal ? Math.max(2, (item.value / maxVal) * 100) : 0;
    const li = document.createElement('li');
    li.className = 'rank-item';
    li.innerHTML = `
      <div class="rank-pos">${idx+1}</div>
      <div class="rank-name">${item.city.name}</div>
      <div class="rank-bar-wrap"><div class="rank-bar" style="width:${pct}%"></div></div>
      <div class="rank-value">${fmtMoney(item.value || 0)}</div>
    `;
    li.addEventListener('click', (e)=>{
      const url = `locality.php?c=${COUNTY_2}&city=${encodeURIComponent(item.city.name)}&ds=${encodeURIComponent(DS_FILE)}`;
      if (e.ctrlKey || e.metaKey) window.open(url,'_blank'); else window.location.assign(url);
    });
    listEl.appendChild(li);
  });
}


// === Locality KPIs (multi-județe aware) ===
// Finds the actual column name by normalized label (e.g., 'IMPLEMENTARE')
function getActualKey(rows, wantedName){
  if (!rows || !rows.length) return null;
  const byNorm = {};
  rows.forEach(r => Object.keys(r||{}).forEach(k => { byNorm[normKey(k)] = k; }));
  return byNorm[normKey(wantedName)] || null;
}

function isMultiRowLocal(row, implKey){
  if (!implKey) return false;
  const s = String(row?.[implKey] || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  const t = s.replace(/\s+/g,'_').replace(/-/g,'_');
  return t === 'multi_judete' || t === 'multijudete';
}

function sumBy(rows, sel){
  let s = 0; for (const r of (rows||[])){ const v = Number(sel(r) || 0); if (Number.isFinite(v)) s += v; }
  return s;
}

function computeLocalityStats(rows){
  const implKey = getActualKey(rows, 'IMPLEMENTARE');
  const singles = implKey ? rows.filter(r => !isMultiRowLocal(r, implKey)) : rows.slice();

  const totalVal = sumBy(singles, r => r.__share_value);
  const count    = singles.length;

  // Top program among singles by value
  const acc = new Map();
  for (const r of singles){
    const k = r.__program_key || 'OTHER';
    const v = Number(r.__share_value || 0);
    acc.set(k, (acc.get(k) || 0) + v);
  }
  let topKey = null, topVal = 0;
  for (const [k,v] of acc.entries()){
    if (v > topVal){ topKey=k; topVal=v; }
  }

  return { totalVal, count, topKey, topVal };
}

function renderLocalityStats(rows){
  const elVal  = document.getElementById('kpiTotalVal');
  const elProj = document.getElementById('kpiTotalProj');
  const elTop  = document.getElementById('kpiTopProgram');
  const elTopV = document.getElementById('kpiTopProgramVal');
  if (!elVal || !elProj || !elTop || !elTopV) return;

  const s = computeLocalityStats(rows || []);
  elVal.textContent  = fmtMoney(s.totalVal || 0);
  elProj.textContent = niceNum(s.count || 0);

  if (s.topKey){
    elTop.textContent  = PROGRAM_LABEL[s.topKey] || s.topKey;
    elTopV.textContent = `Valoare: ${fmtMoney(s.topVal || 0)}`;
  } else {
    elTop.textContent  = '—';
    elTopV.textContent = 'Fără date';
  }
}




// =================== TABLE (extras-like) ===================
function computeColumns(rows){
  const set = new Set();
  for (const r of rows) Object.keys(r).forEach(k => set.add(k));
  allCols = Array.from(set).filter(k => !META_COLS.includes(k));

  // rank by non-empty count
  const counts = allCols.map(k => {
    let n = 0;
    for (const r of rows){
      const v = r[k];
      if (v !== null && v !== undefined && String(v).trim() !== '') n++;
    }
    return {k, n};
  }).sort((a,b)=> b.n - a.n);

  primaryCols = counts.slice(0,8).map(x => x.k);

  // Resolve defaults to requested order
  const byNorm = {}; for (const k of allCols) byNorm[normKey(k)] = k;
  const resolved = [];
  for (const want of DEFAULT_EXTRA_COLS_RAW){
    const hit = byNorm[normKey(want)];
    if (hit) resolved.push(hit);
  }
  chosenCols = resolved.length ? resolved : primaryCols.slice();
}

function labelOf(k){ return (COL_LABELS && COL_LABELS[k]) ? COL_LABELS[k] : labelize(k); }

function buildColumnPicker(){
  const grid = document.getElementById('colGrid');
  grid.innerHTML = '';
  const cols = allCols.slice();
  cols.sort((a,b)=>{
    const ai = chosenCols.indexOf(a), bi = chosenCols.indexOf(b);
    if (ai === -1 && bi === -1) return a.localeCompare(b);
    if (ai === -1) return 1;
    if (bi === -1) return -1;
    return ai - bi;
  });
  for (const k of cols){
    const id = 'col_' + k;
    const lbl = labelOf(k);
    const checked = chosenCols.includes(k);
    grid.insertAdjacentHTML('beforeend',
      `<label for="${id}"><input type="checkbox" id="${id}" value="${k}" ${checked?'checked':''}> ${lbl}</label>`);
  }
}

function syncPickerChecks(){
  const boxes = document.querySelectorAll('#colGrid input[type="checkbox"]');
  boxes.forEach(b => b.checked = chosenCols.includes(b.value));
}
function setAllPickerChecks(flag){
  const boxes = document.querySelectorAll('#colGrid input[type="checkbox"]');
  boxes.forEach(b => b.checked = !!flag);
  if (flag){ chosenCols = Array.from(boxes).map(b => b.value); }
  else { chosenCols = []; }
}

function initFilters(){
  const sel = document.getElementById('programFilter');
  const keys = Array.from(new Set(resultsRows.map(r => r.__program_key).filter(Boolean)));
  const opts = [{key:'__ALL__', label:'Toate programele'}]
    .concat(keys.map(k => ({key:k, label: PROGRAM_LABEL[k] || k})));
  sel.innerHTML = opts.map(o=>`<option value="${o.key}">${o.label}</option>`).join('');
  sel.value = '__ALL__';

  document.getElementById('showAllCols').checked = showAllCols = false;

  sel.addEventListener('change', ()=>{ page = 1; applyFiltersAndRender(); });
  document.getElementById('searchBox').addEventListener('input', ()=>{ page = 1; applyFiltersAndRender(); });

  const picker = document.getElementById('colPicker');
  document.getElementById('pickColsBtn').addEventListener('click', ()=>{
    picker.classList.toggle('show'); syncPickerChecks();
  });
  document.addEventListener('click', (e)=>{
    const wrap = document.querySelector('.colpicker-wrap');
    if (!wrap.contains(e.target)) picker.classList.remove('show');
  });
  document.getElementById('colSelectAllBtn').addEventListener('click', ()=> setAllPickerChecks(true));
  document.getElementById('colClearBtn').addEventListener('click', ()=> setAllPickerChecks(false));
  document.getElementById('colDefaultBtn').addEventListener('click', ()=>{
    computeColumns(resultsRows); buildColumnPicker(); syncPickerChecks();
  });
  document.getElementById('colApplyBtn').addEventListener('click', ()=>{
    const boxes = document.querySelectorAll('#colGrid input[type="checkbox"]');
    const chosen = [];
    boxes.forEach(b => { if (b.checked) chosen.push(b.value); });
    chosenCols = chosen; showAllCols = false;
    document.getElementById('showAllCols').checked = false;
    picker.classList.remove('show');
    page = 1; renderTable();
  });

  document.getElementById('showAllCols').addEventListener('change', (e)=>{
    showAllCols = !!e.target.checked; page = 1; renderTable();
  });

  document.getElementById('prevBtn').addEventListener('click', ()=>{
    if (page > 1){ page--; renderTable(); }
  });
  document.getElementById('nextBtn').addEventListener('click', ()=>{
    const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
    if (page < pages){ page++; renderTable(); }
  });

  document.getElementById('exportBtn').addEventListener('click', exportCSV);
}

function visibleCols(){
  if (showAllCols) return allCols;
  if (chosenCols && chosenCols.length) return chosenCols;
  return primaryCols;
}

function applyFiltersAndRender(){
  const programSel = document.getElementById('programFilter').value;
  const q = (document.getElementById('searchBox').value || '').toLowerCase();

  filtered = resultsRows.filter(r=>{
    if (programSel !== '__ALL__' && r.__program_key !== programSel) return false;
    if (q){
      for (const [k,v] of Object.entries(r)){
        if (v == null) continue;
        const s = String(v).toLowerCase();
        if (s.includes(q)) return true;
      }
      return false;
    }
    return true;
  });

  page = 1;
  renderTable();
}

// ---- TABLE with requested order: Program, Valoare, [extras], COD SMIS
function renderTable(){
  const head = document.getElementById('tblHead');
  const body = document.getElementById('tblBody');
  const pageInfo = document.getElementById('pageInfo');
  const countInfo= document.getElementById('countInfo');

  // hide any in-table COD_SMIS variant; we add a dedicated last column
  const cols = visibleCols().filter(k => normKey(k) !== 'CODSMIS');

  head.innerHTML = [
    '<th>Program</th>',
    '<th class="num">Valoare</th>',
    ...cols.map(k => `<th>${labelOf(k)}</th>`),
    '<th>COD SMIS</th>'
  ].join('');

  const total = filtered.length;
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  if (page > pages) page = pages;
  const start = (page-1) * PAGE_SIZE;
  const end   = Math.min(total, start + PAGE_SIZE);
  const slice = filtered.slice(start, end);

  body.innerHTML = '';
  for (const r of slice){
    const tds = [];
    tds.push(`<td>${(PROGRAM_LABEL[r.__program_key] || r.__program_key || '—')}</td>`);
    tds.push(`<td class="num">${fmtMoney(r.__share_value || 0)}</td>`);

    // extras columns
    for (const k of cols){
      let v = r[k];
      if (v === null || v === undefined || String(v).trim() === '') v = '—';
      tds.push(`<td>${String(v)}</td>`);
    }

    // COD SMIS (link to project.php, preserve dataset)
    const altSmisKey = allCols.find(k => normKey(k) === 'CODSMIS');
    const smisValRaw = (r.COD_SMIS != null && String(r.COD_SMIS).trim() !== '') ? r.COD_SMIS
                     : (altSmisKey ? r[altSmisKey] : '');
    const smis = (smisValRaw == null || String(smisValRaw).trim() === '') ? '' : String(smisValRaw).trim();

    if (smis){
      const url = `project.php?smis=${encodeURIComponent(smis)}&ds=${encodeURIComponent(DS_FILE)}`;
      tds.push(`<td><a href="${url}">${escapeHtml(smis)}</a></td>`);
    } else {
      tds.push('<td>—</td>');
    }

    const tr = document.createElement('tr');
    tr.innerHTML = tds.join('');
    body.appendChild(tr);
  }

  pageInfo.textContent = `Pagina ${page} / ${pages}`;
  countInfo.textContent = `${total} rânduri`;
}

function exportCSV(){
  const cols = visibleCols().filter(k => normKey(k) !== 'CODSMIS');
  const header = ['Program','Valoare'].concat(cols.map(k => labelOf(k))).concat(['COD SMIS']);
  const lines = [header.join(',')];

  for (const r of filtered){
    const row = [
      (PROGRAM_LABEL[r.__program_key] || r.__program_key || '').replace(/"/g,'""'),
      String(r.__share_value || 0)
    ];
    for (const k of cols){
      const v = (r[k] == null) ? '' : String(r[k]);
      row.push(/[",\n]/.test(v) ? `"${v.replace(/"/g,'""')}"` : v);
    }
    row.push(String(r.COD_SMIS || '').replace(/"/g,'""'));
    lines.push(row.join(','));
  }

  const safeDs = DS_FILE.replace(/[^A-Za-z0-9_.-]/g,'_');
  const name   = `proiecte_${COUNTY_2}_${CITY_NAME.replace(/\s+/g,'_')}_${safeDs}.csv`;

  const blob = new Blob([lines.join('\n')], {type:'text/csv;charset=utf-8;'});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

// =================== BOOT ===================
async function boot(){
  try{
    const [funds, cities] = await Promise.all([ loadJSON(DATA_URL), loadJSON(CITIES_URL) ]);

    countyRow = (funds || []).find(r => (r.code || '') === ('RO-' + COUNTY_2));
    if (!countyRow){ alert('Nu am găsit date pentru județ.'); return; }

    extrasRows = Array.isArray(countyRow.extras?.rows) ? countyRow.extras.rows.slice() : [];
    COL_LABELS = countyRow.extras?.col_labels || {};

    // Build alias set for the CURRENT city (to filter table rows)
    const cityEntry = (cities || []).find(c => (c.county || '').toUpperCase() === COUNTY_2 && (c.name || '') === CITY_NAME);
    const aliases = buildAliasSet(CITY_NAME, cityEntry?.aliases || []);

    // Filter rows that mention the CURRENT city (once per row)
    resultsRows = [];
    for (const row of extrasRows){
      const txt = norm(row?.SCOP_PROIECT || row?.Scop_Proiect || row?.Scop || '');
      if (!txt) continue;
      let matched = false;
      for (const a of aliases){
        const re = new RegExp(`(^|[^a-z0-9])${escapeRegExp(a)}([^a-z0-9]|$)`, 'i');
        if (re.test(txt)){ matched = true; break; }
      }
      if (matched){
        if (!row.__program_label && row.__program_key) row.__program_label = PROGRAM_LABEL[row.__program_key] || row.__program_key;
        resultsRows.push(row);
      }
    }

    // Pie for current city
   // ... after resultsRows is computed
renderLocalityStats(resultsRows);

// Pie for current city
renderProgramsPieForCity();

    // Table setup
    computeColumns(resultsRows);
    buildColumnPicker();
    initFilters();
    applyFiltersAndRender();

    // COUNTY-ONLY MAP + value-based localities ranking
    await renderCountyMapWithCities(cities);

  } catch(e){
    console.warn(e);
    alert('A apărut o eroare la încărcarea datelor.');
  }
}

boot();
</script>
</body>
</html>
