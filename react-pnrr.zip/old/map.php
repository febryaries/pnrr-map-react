<!DOCTYPE html>
<?php
// --- Dataset discovery (server-side) ---
$dir = __DIR__;
$entries = [];

// Pattern: 22092025-funds.json (DDMMYYYY-funds.json)
foreach (glob($dir.'/*-funds.json') as $path) {
  $base = basename($path);
  if (preg_match('/^(\d{8})-funds\.json$/', $base, $m)) {
    $d = $m[1]; // DDMMYYYY
    $dt = DateTime::createFromFormat('dmY', $d);
    if ($dt) {
      $entries[] = [
        'file'  => $base,
        'label' => $dt->format('d.m.Y'),
        'ts'    => (int)$dt->format('U'),
        'date'  => $dt->format('Y-m-d'),
      ];
    }
  }
}

// Also allow a plain funds.json (optional)
if (is_file($dir.'/funds.json')) {
  $mt = @filemtime($dir.'/funds.json') ?: time();
  $entries[] = [
    'file'  => 'funds.json',
    'label' => 'Cel mai recent set de date ('.date('d.m.Y', $mt).')',
    'ts'    => $mt,
    'date'  => date('Y-m-d', $mt),
  ];
}

// Sort latest first
usort($entries, fn($a,$b) => $b['ts'] <=> $a['ts']);

// Determine default selection
$qsDs = isset($_GET['ds']) ? basename($_GET['ds']) : '';
$defaultIndex = 0;
if ($qsDs) {
  foreach ($entries as $i => $e) {
    if ($e['file'] === $qsDs) { $defaultIndex = $i; break; }
  }
}
// If nothing found, leave entries empty; client will fallback to demo data.
?>
<html lang="ro">
<head>
  <meta charset="utf-8" />
  <title>Absorbție Fonduri – Harta Județelor (varianta optimizată)</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <!-- Highcharts core + Highmaps + modules -->
  <script src="https://code.highcharts.com/maps/highmaps.js"></script>
  <script src="https://code.highcharts.com/maps/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/maps/modules/accessibility.js"></script>
  <script src="https://code.highcharts.com/mapdata/countries/ro/ro-all.js"></script>
  <style>
    :root{ --gap:12px; }
    body{ font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif; margin:0; background:#f7fafc; color:#0f172a;}
    header{ padding:18px 20px 6px; }
    h1{ font-size:20px; margin:0 0 8px; }
    .controls{ display:flex; flex-wrap:wrap; align-items:center; gap:var(--gap); padding:10px 20px 16px; }
    .segment{ display:inline-flex; border:1px solid #cbd5e1; border-radius:999px; overflow:hidden; background:#fff; }
    .segment button{ padding:8px 14px; border:0; background:#fff; cursor:pointer; font-weight:600;}
    .segment button[aria-pressed="true"]{ background:#0ea5e9; color:#fff; }
    .programs{ display:flex; flex-wrap:wrap; gap:8px; }
    .programs button{ padding:8px 12px; border:1px solid #cbd5e1; background:#fff; border-radius:10px; cursor:pointer; }
    .programs button[aria-pressed="true"]{ background:#10b981; color:#fff; border-color:#10b981; }

    /* Dataset selector */
    .dataset { display:flex; align-items:center; gap:6px; background:#fff; border:1px solid #cbd5e1; border-radius:12px; padding:6px 10px; }
    .dataset label{ font-size:13px; color:#334155; }
    .dataset select{ padding:6px 10px; border:1px solid #cbd5e1; border-radius:10px; min-width:220px; background:#fff; }

    /* Scale controls */
    .scale { display:flex; flex-wrap:wrap; align-items:center; gap:8px; padding:6px 10px; background:#fff; border:1px solid #cbd5e1; border-radius:12px; }
    .scale label{ font-size:13px; color:#334155; }
    .scale select{ padding:6px 10px; border:1px solid #cbd5e1; border-radius:10px; min-width:220px; background:#fff; }

    .btn{ padding:6px 10px; border-radius:10px; background:#0ea5e9; color:#fff; border:0; font-weight:700; cursor:pointer; }
    .btn.secondary{ background:#334155; }
    .btn.ghost{ background:#e2e8f0; color:#0f172a; }

    /* Map card */
    #chart{ height: 720px; max-width: 1200px; margin: 0 auto 16px;
      background:#fff; border-radius:16px; box-shadow:0 8px 24px rgba(2,6,23,.06); }

    /* Grid under the map */
    .below-grid{
      display:grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--gap);
      max-width:1200px;
      margin:0 auto 16px;
      padding:0 20px;
    }
    @media (max-width: 960px){
      .below-grid{ grid-template-columns: 1fr; }
    }

    .card{
      background:#fff; border-radius:16px; box-shadow:0 8px 24px rgba(2,6,23,.06);
      padding:12px 16px;
    }

    /* Pie card */
    .pie-card h3{ margin:0 0 8px; font-size:16px; }
    #programPie{ height: 380px; }

    /* Ranking card */
    .rank-card h3{ margin:0 0 10px; font-size:16px; }
    .rank-note{ color:#475569; font-size:13px; margin-top:6px; }
    .rank-list{ list-style:none; padding:0; margin:0; }
    .rank-item{ display:flex; align-items:center; gap:10px; padding:8px 6px; border-bottom:1px solid #e2e8f0; cursor:pointer; }
    .rank-item:last-child{ border-bottom:0; }
    .rank-pos{ width:26px; text-align:right; font-weight:700; color:#334155; }
    .rank-name{ flex:1 1 auto; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .rank-value{ width:140px; text-align:right; font-variant-numeric: tabular-nums; }
    .rank-bar-wrap{ flex: 0 0 180px; height:8px; background:#e5e7eb; border-radius:999px; overflow:hidden; }
    .rank-bar{ height:100%; background:#60a5fa; }
    .rank-item:hover .rank-bar{ filter:brightness(0.9); }
    .rank-actions{ margin-top:10px; text-align:center; }

    .legend{ text-align:center; font-size:13px; color:#475569; padding-bottom:14px;}
    .note{ max-width:1200px; margin:0 auto 24px; font-size:13px; color:#475569; padding:0 20px; }
    .muted{ opacity:.7 }

    .highcharts-tooltip{ pointer-events:auto; z-index:10000 !important; }
    .highcharts-tooltip .tt-btn{
      display:inline-block; margin-top:8px; padding:6px 10px;
      background:#0ea5e9; color:#fff; border-radius:8px; font-weight:600;
      text-decoration:none; cursor:pointer;
    }
    .highcharts-tooltip .tt-btn:hover{ opacity:.9; }
  </style>
</head>
<body>
  <header>
    <h1>Absorbție fonduri UE 2021-2027 – Harta județelor (optimizată)</h1>
  </header>

  <div class="controls" role="group" aria-label="Comenzi hartă">
    <!-- Dataset (keeps your server-side discovery) -->
    <div class="dataset">
      <label for="datasetSelect">Set de date:</label>
      <select id="datasetSelect">
        <?php if ($entries): ?>
          <?php foreach ($entries as $i => $e): ?>
            <option value="<?=htmlspecialchars($e['file'])?>" <?=$i===$defaultIndex?'selected':''?>>
              <?=htmlspecialchars($e['label'])?>
            </option>
          <?php endforeach; ?>
        <?php else: ?>
          <option value="" selected>(niciun fișier găsit – se vor folosi date demo)</option>
        <?php endif; ?>
      </select>
    </div>

    <!-- Metric: General -->
    <div class="segment" id="metric-seg" role="tablist" aria-label="Alege indicator (general)">
      <button type="button" data-metric="value" aria-pressed="true" aria-selected="true">General · Valoare</button>
      <button type="button" data-metric="projects" aria-pressed="false" aria-selected="false">General · Proiecte</button>
    </div>

    <!-- Multi-județe -->
    <div class="segment" id="multi-seg" role="tablist" aria-label="Multi județe">
      <button type="button" data-metric="value" aria-pressed="false" aria-selected="false">Multi județe · Valoare</button>
      <button type="button" data-metric="projects" aria-pressed="false" aria-selected="false">Multi județe · Proiecte</button>
    </div>

    <!-- Total (General + Multi) -->
    <div class="segment" id="total-seg" role="tablist" aria-label="Total (General + Multi județ)">
      <button type="button" data-metric="value" aria-pressed="false" aria-selected="false">Total · Valoare</button>
      <button type="button" data-metric="projects" aria-pressed="false" aria-selected="false">Total · Proiecte</button>
    </div>

    <!-- Programs -->
    <div class="programs" id="programs" role="tablist" aria-label="Programe"></div>

    <!-- Scale controls -->
    <div class="scale" id="scaleCtrls" aria-label="Scară culoare">
      <label for="scaleSelect">Scară:</label>
      <select id="scaleSelect" title="Alege limita superioară a scării"></select>
      <label style="display:inline-flex; align-items:center; gap:6px; margin-left:6px;">
        <input type="checkbox" id="quantileToggle" />
        Contrast ridicat (praguri)
      </label>
      <button id="openExportBtn" class="btn secondary" type="button" title="Deschide exportul (tabel)">Căutare/export - Toate proiectele</button>
    </div>
  </div>

  <div id="chart"></div>

  <!-- 50/50 grid under the map -->
  <div class="below-grid">
    <div class="card pie-card">
      <div id="programPie"></div>
    </div>

    <div class="card rank-card" id="rankCard">
      <h3>Clasament județe – <span id="rankTitle">General · Valoare</span></h3>
      <ol id="rankList" class="rank-list"></ol>
      <div class="rank-actions">
        <button id="rankToggleBtn" class="btn ghost" type="button">Afișează tot</button>
      </div>
      <div class="rank-note">Clic pe un județ pentru a deschide pagina lui. (Ctrl/⌘-clic pentru un nou tab.)</div>
    </div>
  </div>

  <div class="legend">Clic pe județe pentru detalii în tooltip. Comută între General, Multi județe, <strong>Total</strong> și Programe.</div>
  <div class="note">Notă: scara de culori se ajustează automat sau după setarea ta. „Contrast ridicat” folosește praguri pe cuantile. Se preferă fișiere <code>-lite.json</code> pentru încărcare rapidă.</div>

<script>
/** === CONFIG === */
const PROGRAMS = [
  {key:'PDD', label:' Dezvoltare Durabilă'},
  {key:'PEO', label:' Educație și Ocupare'},
  {key:'PIDS', label:' Incluziune și Demnitate Socială'},
  {key:'POCIDIF', label:' Creștere Inteligentă '},
  {key:'PS', label:' Sănătate'},
  {key:'PT', label:' Transport'},
  {key:'PTJ', label:' Tranziție Justă'},
  {key:'PR', label:'Dezvoltare Regională'}
];
const PROGRAM_COLORS = {
  PDD:'#0ea5e9', PEO:'#6366f1', PIDS:'#ef4444', POCIDIF:'#a855f7',
  PS:'#f59e0b', PT:'#06b6d4', PTJ:'#f97316', PR:'#334155', OTHER:'#94a3b8'
};

/** === DATASET CHOICE === */
const datasetSelect = document.getElementById('datasetSelect');
(function hydrateDatasetChoice(){
  const phpSelected = datasetSelect.value;
  const saved = localStorage.getItem('dsFile');
  if (!phpSelected && saved) {
    const opt = Array.from(datasetSelect.options).find(o => o.value === saved);
    if (opt) opt.selected = true;
  }
})();
let CURRENT_DS_FILE = datasetSelect.value || localStorage.getItem('dsFile') || '';
function currentDataUrl(){ return CURRENT_DS_FILE || 'funds.json'; }

/** === UTILITIES === */
const hcKey = code => String(code||'').toLowerCase();
const fmtMoney = n => new Intl.NumberFormat('ro-RO', { style:'currency', currency:'RON', maximumFractionDigits:0 }).format(n||0);
const fmtNum   = n => new Intl.NumberFormat('ro-RO').format(n||0);
const PROGRAM_LABEL = Object.fromEntries(PROGRAMS.map(p=>[p.key,p.label]));
const isInvented = code => code === 'RO-MULTI' || code === 'RO-NS';

function fmtMoneyShort(n){
  const abs = Math.abs(n||0);
  if (abs >= 1e9)  return (n/1e9).toFixed(abs>=10e9?0:1) + ' mld';
  if (abs >= 1e6)  return (n/1e6).toFixed(abs>=10e6?0:1) + ' mil';
  return new Intl.NumberFormat('ro-RO').format(n||0);
}
function percentile(values, p){
  if (!values.length) return 0;
  const arr = values.slice().sort((a,b)=>a-b);
  const idx = Math.min(arr.length-1, Math.max(0, Math.floor(p*(arr.length-1))));
  return arr[idx];
}

/** === STATE === */
let viewMode = 'general';     // 'general' | 'program' | 'multi' | 'total'
let metric = 'value';         // 'value' | 'projects'
let activeProgram = null;     // for program mode
let rawData = [];             // dataset as loaded
let scaleChoice = 'auto';
let chart;

// Derived caches (built once per dataset)
const derived = {
  general: { value: [], projects: [] },
  multi:   { value: [], projects: [] },
  total:   { value: [], projects: [] },
  programs: {},             // key -> { value:[], projects:[] }
  programTotals: {          // for pie, pre-aggregated
    general: { value:{}, projects:{} },
    multi:   { value:{}, projects:{} },
    total:   { value:{}, projects:{} }
  }
};

/** === UI wiring (program pills, segments, scale) === */
const programsWrap = document.getElementById('programs');
PROGRAMS.forEach(p=>{
  const b = document.createElement('button');
  b.type = 'button';
  b.textContent = p.label;
  b.dataset.key = p.key;
  b.setAttribute('aria-pressed','false');
  b.title = `Click: ${p.label} · Valoare | Shift+Click: ${p.label} · Proiecte`;
  b.addEventListener('click', (ev)=>{
    viewMode = 'program';
    activeProgram = p.key;
    metric = ev.shiftKey ? 'projects' : 'value';
    syncAllButtons();
    render({animate:true});
  });
  programsWrap.appendChild(b);
});

// Segments
document.querySelectorAll('#metric-seg button').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    viewMode = 'general';
    metric = btn.dataset.metric;
    activeProgram = null;
    syncAllButtons();
    render({animate:true});
  });
});
document.querySelectorAll('#multi-seg button').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    viewMode = 'multi';
    metric = btn.dataset.metric;
    activeProgram = null;
    syncAllButtons();
    render({animate:true});
  });
});
document.querySelectorAll('#total-seg button').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    viewMode = 'total';
    metric = btn.dataset.metric;
    activeProgram = null;
    syncAllButtons();
    render({animate:true});
  });
});

// Scale
document.getElementById('quantileToggle').addEventListener('change', ()=> render({animate:true}));
document.getElementById('scaleSelect').addEventListener('change', (e)=>{ scaleChoice = e.target.value; render({animate:true}); });

// Export (propagates ds)
document.getElementById('openExportBtn').addEventListener('click', ()=>{
  const url = 'map_export.php' + makeStateQuery();
  window.open(url, '_blank');
});

// Dataset change -> reload (no animations on swap)
datasetSelect.addEventListener('change', async ()=>{
  CURRENT_DS_FILE = datasetSelect.value || '';
  localStorage.setItem('dsFile', CURRENT_DS_FILE);
  await loadData(false);
});

/** === BUTTON SYNC === */
function syncAllButtons(){
  // General
  document.querySelectorAll('#metric-seg button').forEach(b=>{
    const on = (viewMode === 'general' && b.dataset.metric === metric);
    b.setAttribute('aria-pressed', on ? 'true':'false');
    b.setAttribute('aria-selected', on ? 'true':'false');
    b.textContent = (b.dataset.metric === 'value') ? 'General · Valoare' : 'General · Proiecte';
  });
  // Multi
  document.querySelectorAll('#multi-seg button').forEach(b=>{
    const on = (viewMode === 'multi' && b.dataset.metric === metric);
    b.setAttribute('aria-pressed', on ? 'true':'false');
    b.setAttribute('aria-selected', on ? 'true':'false');
    b.textContent = (b.dataset.metric === 'value') ? 'Multi județe · Valoare' : 'Multi județe · Proiecte';
  });
  // Total
  document.querySelectorAll('#total-seg button').forEach(b=>{
    const on = (viewMode === 'total' && b.dataset.metric === metric);
    b.setAttribute('aria-pressed', on ? 'true':'false');
    b.setAttribute('aria-selected', on ? 'true':'false');
    b.textContent = (b.dataset.metric === 'value') ? 'Total · Valoare' : 'Total · Proiecte';
  });
  // Programs
  document.querySelectorAll('#programs button').forEach(b=>{
    const on = (viewMode === 'program' && b.dataset.key === activeProgram);
    const label = PROGRAMS.find(p=>p.key===b.dataset.key)?.label || b.dataset.key;
    b.setAttribute('aria-pressed', on ? 'true':'false');
    b.textContent = on ? label + (metric==='projects' ? ' •P' : ' •V') : label;
  });
}

/** === MULTI helpers (fallback compute ONCE) === */
function normalizeCounty2(c2){
  const t = String(c2||'').toUpperCase().trim();
  if (t === 'B' || t === 'BU' || t === 'BI') return 'BI';
  return t.replace(/[^A-Z]/g,'').slice(0,2);
}
function parseTargets(s){
  return String(s||'').split(',').map(x => normalizeCounty2(x)).filter(Boolean);
}
function collectMultiRows(){
  let rows = [];
  const carrier = rawData.find(r => r.code === 'RO-MULTI');
  if (carrier?.extras?.rows) rows = carrier.extras.rows.slice();
  else rawData.forEach(r => rows = rows.concat(r.extras?.rows || []));
  return rows.filter(row => String(row?.IMPLEMENTARE || '').toLowerCase().trim() === 'multi_judete');
}

/** === BUILD DERIVED CACHES ONCE PER DATASET === */
function pt(code, name, money, projects, projectsAsValue=false){
  return { 'hc-key': hcKey(code), code, name, money, projects, value: projectsAsValue ? projects : money };
}

function readMultiAggOnce(){
  const carrier = rawData.find(x => x.code === 'RO-MULTI');
  const map = carrier?.extras?.multi_agg_by_county || null;
  if (map) {
    const out = {};
    for (const [c2,v] of Object.entries(map)) {
      out[c2] = { value:Number(v.value||0), projects:Number(v.projects||0) };
    }
    return out;
  }
  // Fallback: compute from rows (ONCE)
  const agg = {};
  const rows = collectMultiRows();
  for (const r of rows){
    const targets = parseTargets(r['JUDEE_PROIECT_IMPLEMENTARE'] || r['JUDETE_PROIECT_IMPLEMENTARE'] || '');
    if (!targets.length) continue;
    const v = Number(r.__share_value || 0);
    const p = Number(r.__share_projects || 0);
    const vPart = v / targets.length;
    for (const c2 of targets){
      (agg[c2] ||= {value:0, projects:0});
      agg[c2].value += vPart;
      agg[c2].projects += p;
    }
  }
  return agg;
}

function buildProgramTotalsOnce(multiAggByProgram){
  // Reset
  derived.programTotals.general = { value:{}, projects:{} };
  derived.programTotals.multi   = { value:{}, projects:{} };
  derived.programTotals.total   = { value:{}, projects:{} };

  // General from base counties (no extras)
  rawData.forEach(r=>{
    if (isInvented(r.code)) return;
    const pr = r.programs || {};
    for (const [k,v] of Object.entries(pr)){
      derived.programTotals.general.value[k]    = (derived.programTotals.general.value[k]    || 0) + (Number(v.value)||0);
      derived.programTotals.general.projects[k] = (derived.programTotals.general.projects[k] || 0) + (Number(v.projects)||0);
    }
  });

  // Multi: either provided as program totals (rare) or compute once from rows
  if (multiAggByProgram) {
    for (const [k,v] of Object.entries(multiAggByProgram)){
      derived.programTotals.multi.value[k]    = Number(v.value)||0;
      derived.programTotals.multi.projects[k] = Number(v.projects)||0;
    }
  } else {
    const rows = collectMultiRows();
    for (const r of rows){
      const k = r.__program_key || 'OTHER';
      derived.programTotals.multi.value[k]    = (derived.programTotals.multi.value[k]    || 0) + (Number(r.__share_value)||0);
      derived.programTotals.multi.projects[k] = (derived.programTotals.multi.projects[k] || 0) + (Number(r.__share_projects)||0);
    }
  }

  // Total = General + Multi
  const keys = new Set([
    ...Object.keys(derived.programTotals.general.value),
    ...Object.keys(derived.programTotals.multi.value)
  ]);
  keys.forEach(k=>{
    derived.programTotals.total.value[k]    = (derived.programTotals.general.value[k]    || 0) + (derived.programTotals.multi.value[k]    || 0);
    derived.programTotals.total.projects[k] = (derived.programTotals.general.projects[k] || 0) + (derived.programTotals.multi.projects[k] || 0);
  });
}

function buildDerivedCaches(){
  // clear per-dataset structures
  derived.general = { value:[], projects:[] };
  derived.multi   = { value:[], projects:[] };
  derived.total   = { value:[], projects:[] };
  derived.programs = {};

  const base = rawData.filter(r => !isInvented(r.code));
  const multiAgg = readMultiAggOnce();

  // General
  derived.general.value    = base.map(r => pt(r.code, r.name, r.total?.value||0,    r.total?.projects||0));
  derived.general.projects = base.map(r => pt(r.code, r.name, r.total?.value||0,    r.total?.projects||0, true));

  // Multi (using aggregated map)
  derived.multi.value = base.map(r => {
    const c2 = r.code.replace('RO-',''); const add = multiAgg[c2] || {value:0, projects:0};
    return pt(r.code, r.name, add.value, add.projects);
  });
  derived.multi.projects = derived.multi.value.map(x => ({ ...x, value: x.projects }));

  // Total = General + Multi
  derived.total.value = base.map(r => {
    const c2 = r.code.replace('RO-',''); const add = multiAgg[c2] || {value:0, projects:0};
    const money = (r.total?.value||0)    + add.value;
    const proj  = (r.total?.projects||0) + add.projects;
    return pt(r.code, r.name, money, proj);
  });
  derived.total.projects = derived.total.value.map(x => ({ ...x, value: x.projects }));

  // Per-program arrays
  for (const p of PROGRAMS){
    const valueArr = base.map(r => {
      const pr = (r.programs && r.programs[p.key]) ? r.programs[p.key] : {value:0, projects:0};
      return pt(r.code, r.name, pr.value||0, pr.projects||0);
    });
    derived.programs[p.key] = { value: valueArr, projects: valueArr.map(x => ({...x, value: x.projects})) };
  }

  // Program totals for pie (compute once)
  buildProgramTotalsOnce(/* multiAggByProgram = */ null);
}

// Current data slice
function getCurrentSeries(){
  if (viewMode==='general') return derived.general[metric];
  if (viewMode==='multi')   return derived.multi[metric];
  if (viewMode==='total')   return derived.total[metric];
  if (viewMode==='program' && activeProgram) return (derived.programs[activeProgram]||{})[metric] || [];
  return [];
}

/** === ColorAxis helpers === */
function getAutoMax(series){ return series.length ? Math.max(...series.map(p=>p.value||0)) : 1; }
function getMin(series){ return 0; }
function buildScaleOptions(values){
  const sel = document.getElementById('scaleSelect');
  if (!sel) return;
  const max = values.length ? Math.max(...values) : 1;
  const p90 = percentile(values, 0.90);
  const p95 = percentile(values, 0.95);
  const p99 = percentile(values, 0.99);
  const label = (v) => (metric==='value' ? fmtMoneyShort(v) : fmtNum(v));
  const options = [
    {value:'auto', text:`Auto (max ${label(max)})`},
    {value:'p90',  text:`P90 (~${label(p90)})`},
    {value:'p95',  text:`P95 (~${label(p95)})`},
    {value:'p99',  text:`P99 (~${label(p99)})`}
  ];
  const current = sel.value || scaleChoice || 'auto';
  sel.innerHTML = options.map(o => `<option value="${o.value}">${o.text}</option>`).join('');
  sel.value = options.some(o => o.value === current) ? current : 'auto';
  scaleChoice = sel.value;
}
function resolveMax(values, autoMax){
  switch (scaleChoice){
    case 'p90': return Math.max(1, percentile(values, 0.90));
    case 'p95': return Math.max(1, percentile(values, 0.95));
    case 'p99': return Math.max(1, percentile(values, 0.99));
    case 'auto':
    default:     return Math.max(1, autoMax);
  }
}

/** === Ranking + Pie === */
let showAllRanking = false; // default: show top 10
const RANK_SHORT = 10;

function selectionLabel(){
  if (viewMode === 'general') return `General · ${metric==='value' ? 'Valoare' : 'Proiecte'}`;
  if (viewMode === 'program') {
    const lbl = PROGRAMS.find(p=>p.key===activeProgram)?.label || activeProgram;
    return `${lbl} · ${metric==='value' ? 'Valoare' : 'Proiecte'}`;
  }
  if (viewMode === 'total') return `Total · ${metric==='value' ? 'Valoare' : 'Proiecte'}`;
  return `Multi județe · ${metric==='value' ? 'Valoare' : 'Proiecte'}`;
}
function renderRanking(seriesData){
  const titleEl = document.getElementById('rankTitle');
  const listEl  = document.getElementById('rankList');
  const btn     = document.getElementById('rankToggleBtn');
  if (!titleEl || !listEl || !btn) return;

  const rows = (seriesData || []).slice().sort((a,b)=> (b.value||0) - (a.value||0));
  const maxVal = rows.length ? (rows[0].value || 0) : 1;
  titleEl.textContent = selectionLabel();
  listEl.innerHTML = '';

  const toShow = showAllRanking ? rows : rows.slice(0, RANK_SHORT);

  toShow.forEach((r, idx) => {
    const pct = maxVal ? Math.max(2, (r.value / maxVal) * 100) : 0;
    const displayVal = (metric === 'value') ? fmtMoney(r.money || 0) : fmtNum(r.projects || 0);
    const li = document.createElement('li');
    li.className = 'rank-item';
    li.dataset.code = r.code;
    li.innerHTML = `
      <div class="rank-pos">${idx+1}</div>
      <div class="rank-name">${(r.name || r.code || '').replace('RO-','')}</div>
      <div class="rank-bar-wrap"><div class="rank-bar" style="width:${pct}%"></div></div>
      <div class="rank-value">${displayVal}</div>`;
    li.addEventListener('click', (e) => {
      const href = pageForMode(r.code, r.name);
      if (e.ctrlKey || e.metaKey) window.open(href, '_blank');
      else window.location.assign(href);
    });
    listEl.appendChild(li);
  });

  btn.textContent = showAllRanking ? 'Restrânge' : 'Afișează tot';
}
document.getElementById('rankToggleBtn').addEventListener('click', ()=>{
  showAllRanking = !showAllRanking;
  renderRanking(getCurrentSeries());
});

// Pre-aggregated program totals -> pie
let pieChart = null;
function computeProgramTotalsForCurrentView(){
  const map = (viewMode==='general')
    ? derived.programTotals.general
    : (viewMode==='multi')
      ? derived.programTotals.multi
      : (viewMode==='total')
        ? derived.programTotals.total
        : null;

  if (viewMode==='program' && activeProgram){
    // Show pie for all programs but highlight the active slice
    // Build from TOTAL (national) to keep context
    return Object.entries(derived.programTotals.total[metric]).map(([k,v]) => ({ key:k, label:PROGRAM_LABEL[k]||k, value:v }));
  }

  if (!map) return [];
  return Object.entries(map[metric]).map(([k,v]) => ({ key:k, label:PROGRAM_LABEL[k]||k, value:v }))
           .filter(x=>x.value>0).sort((a,b)=>b.value-a.value);
}
function renderProgramPie(){
  const totals = computeProgramTotalsForCurrentView();
  const seriesData = totals.map(t => ({
    name: t.label,
    y: t.value,
    color: PROGRAM_COLORS[t.key] || undefined,
    key: t.key,
    sliced: (viewMode === 'program' && t.key === activeProgram) ? true : false,
    selected: (viewMode === 'program' && t.key === activeProgram) ? true : false
  }));

  const scopeLabel =
    (viewMode === 'multi') ? 'Multi județe' :
    (viewMode === 'total') ? 'Total (național)' :
    'Național';
  const pieTitle = `Distribuție pe programe – ${metric==='value' ? 'Valoare (RON)' : 'Proiecte'} (${scopeLabel})`;

  if (!pieChart){
    pieChart = Highcharts.chart('programPie', {
      chart: { type:'pie' },
      title: { text: pieTitle },
      tooltip: { useHTML: true, pointFormatter: function(){
        const val = metric==='value' ? fmtMoney(this.y) : fmtNum(this.y);
        return `<span style="color:${this.color}">●</span> ${this.name}: <b>${val}</b>`;
      }},
      plotOptions: {
        pie: {
          innerSize: '55%',
          dataLabels: { enabled: true, formatter(){ return this.percentage ? Highcharts.numberFormat(this.percentage, 1) + '%' : null; } },
          cursor: 'pointer',
          point: { events: {
            click: function(){
              viewMode = 'program';
              activeProgram = this.options.key;
              syncAllButtons(); render({animate:true});
            }
          } }
        }
      },
      series: [{ name:'Programe', data: seriesData }],
      credits: { enabled: false }, exporting: { enabled: true }
    });
  } else {
    pieChart.update({ title:{ text: pieTitle }, series:[{ data: seriesData }] }, true, true);
  }
}

/** === Routing (+ds propagation) === */
function addDs(url){
  const ds = CURRENT_DS_FILE || '';
  if (!ds) return url;
  return url + (url.includes('?') ? '&' : '?') + 'ds=' + encodeURIComponent(ds);
}
function countyPageFromCode(roCode){
  const c = String(roCode || '').toUpperCase().replace('RO-','');
  const norm = (c === 'BI' || c === 'BU' || c === 'B') ? 'BI' : c;
  return addDs('judet.php?c=' + encodeURIComponent(norm));
}
function multiPageFromCode(roCode){
  const c = String(roCode || '').toUpperCase().replace('RO-','');
  const norm = (c === 'BI' || c === 'BU' || c === 'B') ? 'BI' : c;
  return addDs('multi.php?c=' + encodeURIComponent(norm));
}
function isMultiKey(s){
  const t = String(s || '').toUpperCase();
  return t === 'RO-MULTI' || t === 'MULTI' || t === 'MULTI_JUDETE' || t.includes('MULTI');
}
function pageForMode(roCode, name){
  if (isMultiKey(roCode) || isMultiKey(name)) return addDs('multi.php');
  return (viewMode === 'multi') ? multiPageFromCode(roCode) : countyPageFromCode(roCode);
}

/** Export state */
function makeStateQuery(){
  const params = new URLSearchParams();
  params.set('mode', (viewMode === 'total') ? 'general' : viewMode);
  params.set('metric', metric);
  if (viewMode === 'program' && activeProgram) params.set('program', activeProgram);
  if (CURRENT_DS_FILE) params.set('ds', CURRENT_DS_FILE);
  return '?' + params.toString();
}

/** === CHART RENDER === */
function render({animate=true} = {}){
  const data = getCurrentSeries();
  const values = data.map(d => d.value || 0).filter(v => isFinite(v));
  buildScaleOptions(values);

  const min = getMin(data);
  const autoMax = getAutoMax(data);
  const max = resolveMax(values, autoMax);

  let title;
  if (viewMode === 'general')      title = `General (toate programele) - ${metric==='value' ? 'Valoare (RON)' : 'Număr proiecte'}`;
  else if (viewMode === 'program') title = `Program ${activeProgram} - ${metric==='value' ? 'Valoare (RON)' : 'Număr proiecte'}`;
  else if (viewMode === 'total')   title = `Total (General + Multi județe) - ${metric==='value' ? 'Valoare (RON)' : 'Număr proiecte'}`;
  else                             title = `Multi județe - ${metric==='value' ? 'Valoare (RON, împărțită egal între județe)' : 'Număr proiecte (plin în fiecare județ)'}`;

  const useQuantiles = document.getElementById('quantileToggle').checked;
  let colorAxisCfg;
  if (useQuantiles) {
    const qs = [0.20,0.40,0.60,0.80].map(q => percentile(values, q));
    const colors = ['#dbeafe', '#93c5fd', '#60a5fa', '#2563eb', '#0f172a'];
    const edges = [min, qs[0], qs[1], qs[2], qs[3], Math.max(max, qs[3] || max)];
    const classes = [];
    for (let i=0;i<5;i++){
      const from = edges[i], to = edges[i+1];
      const name = (metric==='value') ? `${fmtMoneyShort(from)} – ${fmtMoneyShort(to)}` : `${fmtNum(from)} – ${fmtNum(to)}`;
      classes.push({ from, to, color: colors[i], name });
    }
    colorAxisCfg = { min, max, dataClasses: classes, labels: { enabled: false } };
  } else {
    colorAxisCfg = {
      min, max,
      stops: [[0, '#e8f1ff'], [0.25,'#93c5fd'], [0.55,'#3b82f6'], [0.85,'#1d4ed8'], [1, '#0f172a']],
      labels: { formatter(){ return metric === 'value' ? fmtMoneyShort(this.value) : fmtNum(this.value); } }
    };
  }

  if(!chart){
    chart = Highcharts.mapChart('chart', {
      chart: { map: 'countries/ro/ro-all' },
      title: { text: title },
      subtitle: { text: 'Comută între General, Multi județe, Total și Programe. Shift+Click pe un program = Proiecte.' },
      mapNavigation: { enabled: true, buttonOptions: { verticalAlign: 'bottom' } },
      colorAxis: colorAxisCfg,
      tooltip: {
        useHTML: true, outside: true, followPointer: true, stickOnContact: true, hideDelay: 2000,
        formatter: function () {
          const v = this.point;
          const href = pageForMode(v.code, v.name);
          const line1 = `<strong>${v.name || v.code}</strong>`;
          const line2 = (metric==='value')
            ? `Valoare: <strong>${fmtMoney(v.money)}</strong>`
            : `Proiecte: <strong>${fmtNum(v.projects)}</strong>`;
          const other = (metric==='value') ? `Proiecte: ${fmtNum(v.projects)}` : `Valoare: ${fmtMoney(v.money)}`;
          const mode =
            (viewMode === 'general') ? 'General'
            : (viewMode === 'program') ? `Program: <em>${activeProgram}</em>`
            : (viewMode === 'total')   ? 'Total (General + Multi)'
            : 'Multi județe';
          const btn = `<div><a class="tt-btn" href="${href}" aria-label="Deschide pagina pentru ${v.name}">Click pe județ pentru detalii</a></div>`;
          return `${line1}<br/>${line2}<br/><span class="muted">${other}</span><br/><span class="muted">${mode}</span>${btn}`;
        },
        positioner: function (labelWidth, labelHeight, point) {
          const chart = this.chart;
          const x = chart.plotLeft + Math.min(Math.max(point.plotX - labelWidth / 2, 0), chart.plotWidth - labelWidth);
          const y = chart.plotTop  + Math.min(Math.max(point.plotY - labelHeight - 12, 0), chart.plotHeight - labelHeight);
          return { x, y };
        }
      },
      legend: { layout: 'horizontal' },
      series: [{
        data: data,
        joinBy: 'hc-key',
        name: 'Absorbție',
        states: { hover: { color: '#16a34a' } },
        dataLabels: {
          enabled: true,
          formatter: function(){ return (this.point.code || '').replace('RO-',''); },
          style: { textOutline: 'none', fontSize: '10px', fontWeight: '600', color: '#0f172a' }
        },
        cursor: 'pointer',
        point: {
          events: {
            click: function (e) {
              const href   = pageForMode(this.code || this.options.code, this.name);
              const domEvt = (e && e.originalEvent) ? e.originalEvent : e || {};
              if (domEvt.ctrlKey || domEvt.metaKey) window.open(href, '_blank');
              else window.location.assign(href);
            }
          }
        }
      }],
      credits: { enabled: false }, exporting: { enabled: true }
    });

    chart.container.addEventListener('click', function (e) {
      const link = e.target.closest('a.tt-btn[href]');
      if (!link) return;
      e.preventDefault(); e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
      const url = link.getAttribute('href');
      if (e.ctrlKey || e.metaKey) window.open(url, '_blank');
      else window.location.assign(url);
    }, true);

  } else {
    chart.update({ title: { text: title }, colorAxis: colorAxisCfg }, false);
    chart.series[0].setData(data, true, animate); // animation configurable
  }

  renderRanking(data);
  renderProgramPie();
}

/** === DATA LOAD (prefer *-lite.json, allow HTTP cache) === */
const FALLBACK = [
  { code:"RO-AB", name:"Alba",
    total:{value:134500000, projects:410},
    programs:{PDD:{value:29000000,projects:70}, PEO:{value:9500000,projects:35}, PIDS:{value:6200000,projects:18},
      POCIDIF:{value:12000000,projects:40}, PS:{value:8000000,projects:22}, PT:{value:18000000,projects:12},
      PTJ:{value:0,projects:0}, PR:{value:32000000,projects:213}},
    extras:{ rows:[] } },
  { code:"RO-MULTI", name:"Multi județe", total:{value:0, projects:0}, programs:{}, extras:{ rows:[] } },
  { code:"RO-NS", name:"Nespecificat", total:{value:0, projects:0}, programs:{}, extras:{ rows:[] } },
];

async function fetchJson(url){
  const r = await fetch(url); // let HTTP cache work (ETag/gzip)
  if(!r.ok) throw new Error('not ok');
  return r.json();
}

async function loadData(initializeUI = true){
  try{
    const main = currentDataUrl();                      // e.g. 20240922-funds.json
    const lite = main.replace(/\.json$/,'-lite.json');  // prefer smaller file
    try { rawData = await fetchJson(lite); }
    catch { rawData = await fetchJson(main); }
    if(!Array.isArray(rawData) || !rawData.length) throw new Error('empty');
  }catch(e){
    console.warn('Nu am putut încărca datasetul selectat, folosesc FALLBACK.', e);
    rawData = FALLBACK;
  }

  if (initializeUI) {
    viewMode = 'general';
    metric = 'value';
    activeProgram = null;
    scaleChoice = 'auto';
    document.getElementById('quantileToggle').checked = false;
    showAllRanking = false;
  }
  // persist selection for other pages
  localStorage.setItem('dsFile', CURRENT_DS_FILE || '');

  // Build all derived data once per dataset
  buildDerivedCaches();

  syncAllButtons();
  // No animation on dataset swap:
  render({animate:false});
}

// BOOT
(async () => {
  CURRENT_DS_FILE = datasetSelect.value || localStorage.getItem('dsFile') || '';
  await loadData(true);
})();
</script>
</body>
</html>
