<?php
// map_export.php — export table with column picker + sorting + page-size selector
header('Content-Type: text/html; charset=UTF-8');
ini_set('default_charset', 'UTF-8');

$mode   = isset($_GET['mode'])   ? strtolower(trim($_GET['mode']))   : 'general';
$metric = isset($_GET['metric']) ? strtolower(trim($_GET['metric'])) : 'value';
$program= isset($_GET['program'])? strtoupper(trim($_GET['program'])): '';

$dir = __DIR__;
$DATA_FILE = 'funds.json';

// Discover datasets (newest first)
$dated = glob($dir . '/*-funds.json') ?: [];
usort($dated, function($a, $b){
  $fa = basename($a); $fb = basename($b);
  preg_match('/(\d{8})-funds\.json$/', $fa, $ma);
  preg_match('/(\d{8})-funds\.json$/', $fb, $mb);
  $ta = isset($ma[1]) ? DateTime::createFromFormat('dmY', $ma[1]) : false;
  $tb = isset($mb[1]) ? DateTime::createFromFormat('dmY', $mb[1]) : false;
  $tsa = $ta ? (int)$ta->format('U') : 0;
  $tsb = $tb ? (int)$tb->format('U') : 0;
  return $tsb <=> $tsa;
});
$DATASETS = [];
foreach ($dated as $path){
  $base = basename($path);
  preg_match('/(\d{8})-funds\.json$/', $base, $m);
  $label = isset($m[1]) ? DateTime::createFromFormat('dmY', $m[1])->format('d.m.Y') : $base;
  $DATASETS[] = ['file'=>$base, 'label'=>$label];
}
if (is_file($dir . '/funds.json')) $DATASETS[] = ['file'=>'funds.json', 'label'=>'funds.json (legacy)'];

// Select dataset (respect ?ds=)
$dsParam = isset($_GET['ds']) ? basename($_GET['ds']) : '';
if ($dsParam && is_file($dir . '/' . $dsParam)) $DATA_FILE = $dsParam;
elseif (!empty($DATASETS)) $DATA_FILE = $DATASETS[0]['file'];
elseif (is_file($dir . '/funds.json')) $DATA_FILE = 'funds.json';
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="utf-8" />
  <title>Export – tabel proiecte (hartă)</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    :root{ --gap:14px; --ring:#e2e8f0; --muted:#64748b; }
    *{ box-sizing:border-box; }
    body{ font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif; margin:0; background:#f7fafc; color:#0f172a;}
    header{ padding:18px 20px 12px; max-width:100%; margin:0 auto; }
    a.back{ display:inline-flex; gap:8px; align-items:center; text-decoration:none; color:#0ea5e9; font-weight:600; }
    h1{ font-size:22px; margin:10px 0 4px; }
    .sub{ color:var(--muted); margin-bottom:8px; }
    .wrap{ max-width:100%; margin:0 auto 24px; padding:0 20px; }
    .card{ background:#fff; border-radius:16px; box-shadow:0 8px 24px rgba(2,6,23,.06); padding:16px; }

    .extras-controls{ display:grid; gap:10px; grid-template-columns: 1fr; margin:10px 0; }
    .filter-row{ display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
    .extras-controls input[type="text"], .extras-controls select{
      padding:8px; border:1px solid var(--ring); border-radius:10px; background:#fff; min-width:280px;
    }
    .btn{ display:inline-block; padding:8px 12px; border-radius:10px; background:#0ea5e9; color:#fff; text-decoration:none; font-weight:700; border:0; cursor:pointer; }
    .btn.secondary{ background:#334155; }
    .btn.ghost{ background:#e2e8f0; color:#0f172a; }

    .colpicker-wrap{ position:relative; }
    .colpicker{ position:absolute; z-index:20; right:0; top:44px; min-width:360px; max-height:360px; overflow:auto;
      background:#fff; border:1px solid var(--ring); border-radius:12px; box-shadow:0 8px 24px rgba(2,6,23,.12); padding:10px; display:none;}
    .colpicker.show{ display:block; }
    .colpicker h4{ margin:2px 0 8px; font-size:14px;}
    .colgrid{ display:grid; grid-template-columns:1fr 1fr; gap:6px 12px; }
    .picker-actions{ display:flex; gap:8px; margin-top:10px; flex-wrap:wrap; }

    .scroll-x{ overflow-x:auto; }
    table{ width:100%; border-collapse:collapse; margin-top:10px; }
    th, td{ padding:10px 8px; border-bottom:1px solid var(--ring); text-align:left; vertical-align:top; }
    th{ font-size:13px; color:var(--muted); font-weight:700; white-space:nowrap; }
    td.num{ text-align:right; font-variant-numeric: tabular-nums; }

    th.sortable{ cursor:pointer; user-select:none; }
    th.sortable .arrow{ opacity:.7; margin-left:6px; font-size:12px; }
    th.sortable[aria-sort="ascending"] .arrow::after{ content:"▲"; }
    th.sortable[aria-sort="descending"] .arrow::after{ content:"▼"; }
  </style>
</head>
<body>
<header>
  <a class="back" href="map.php?ds=<?= urlencode($DATA_FILE) ?>">← Înapoi la hartă</a>
  <h1>Export – tabel proiecte (nivel hartă)</h1>
  <div class="sub">
    Vizualizare: <strong><?= htmlspecialchars($mode) ?></strong>
    <?php if ($mode==='program' && $program): ?>
      • Program: <strong><?= htmlspecialchars($program) ?></strong>
    <?php endif; ?>
    • Set date: <strong><?= htmlspecialchars($DATA_FILE) ?></strong>
  </div>
</header>

<div class="wrap">
  <div class="card">
    <div class="extras-controls">

      <div class="filter-row">
        <label class="muted" for="datasetSel">Valori pentru data :</label>
        <select id="datasetSel">
          <?php foreach ($DATASETS as $ds): ?>
            <option value="<?= htmlspecialchars($ds['file']) ?>" <?= $ds['file'] === $DATA_FILE ? 'selected' : '' ?>><?= htmlspecialchars($ds['label']) ?></option>
          <?php endforeach; ?>
        </select>
        <a class="btn ghost" href="map.php?ds=<?= urlencode($DATA_FILE) ?>">Deschide harta cu acest set</a>
      </div>

      <div class="filter-row">
        <label class="muted" for="programFilter">Filtru program (cheie):</label>
        <select id="programFilter"></select>
      </div>

      <div class="filter-row">
        <label class="muted" for="implementareFilter">Județ implementare:</label>
        <select id="implementareFilter"></select>
      </div>

      <div class="filter-row">
        <label class="muted" for="objectiveFilter">Obiective specifice:</label>
        <select id="objectiveFilter"></select>
      </div>

      <div class="filter-row">
        <label class="muted" for="statusFilter">Status:</label>
        <select id="statusFilter"></select>
      </div>

      <div class="filter-row">
        <input id="searchBox" type="text" placeholder="Caută text în rezultate…" />
      </div>

      <div class="filter-row">
        <label style="display:inline-flex; align-items:center; gap:6px;">
          <input type="checkbox" id="showAllCols" />
          Arată toate coloanele
        </label>

        <div class="colpicker-wrap">
          <button class="btn secondary" id="pickColsBtn" type="button">Alege coloane…</button>
          <div class="colpicker" id="colPicker" aria-label="Selectează coloanele">
            <h4>Selectează coloanele de afișat</h4>
            <div class="colgrid" id="colGrid"></div>
            <div class="picker-actions">
              <button type="button" class="btn ghost" id="colSelectAllBtn">Selectează toate</button>
              <button type="button" class="btn ghost" id="colClearBtn">Golește selecția</button>
              <button type="button" class="btn ghost" id="colDefaultBtn">Revino la implicite</button>
              <button type="button" class="btn" id="colApplyBtn">Aplică & închide</button>
            </div>
          </div>
        </div>

        <button class="btn secondary" id="exportBtn" type="button">Exportă rezultate (CSV)</button>
        <span class="muted" id="countInfo" style="margin-left:auto">—</span>
      </div>
    </div>

    <div class="scroll-x">
      <table id="tbl">
        <thead><tr id="tblHead"></tr></thead>
        <tbody id="tblBody"></tbody>
      </table>
    </div>

    <!-- Bottom controls: page size + pagination -->
    <div style="display:flex; gap:8px; justify-content:space-between; align-items:center; margin-top:10px; flex-wrap:wrap;">
      <div class="muted">
        Afișează:
        <select id="pageSizeSel" style="padding:6px 8px; border:1px solid var(--ring); border-radius:10px; background:#fff;">
          <option value="10">10</option>
          <option value="25">25</option>
          <option value="50">50</option>
          <option value="100">100</option>
          <option value="0">Toate</option>
        </select>
        înregistrări / pagină
      </div>
      <div>
        <button class="btn secondary" id="prevBtn" type="button">‹ Anterioare</button>
        <span class="muted" id="pageInfo">Pagina 1</span>
        <button class="btn secondary" id="nextBtn" type="button">Următoare ›</button>
      </div>
    </div>
  </div>
</div>

<script>
const PARAM_MODE    = <?= json_encode($mode) ?>;
const PARAM_METRIC  = <?= json_encode($metric) ?>;
const PARAM_PROGRAM = <?= json_encode($program) ?>;

const DATA_URL = '<?= addslashes($DATA_FILE) ?>';
const DS_FILE  = '<?= addslashes($DATA_FILE) ?>';

const PROGRAMS = [
  {key:'PDD', label:'Programul Dezvoltare Durabilă'},
  {key:'PEO', label:'Programul Educație și Ocupare'},
  {key:'PIDS', label:'Programul Incluziune și Demnitate Socială'},
  {key:'POCIDIF', label:'Programul Creștere Inteligentă, Digitalizare și Instrumente Financiare'},
  {key:'PS', label:'Programul Sănătate'},
  {key:'PT', label:'Programul Transport'},
  {key:'PTJ', label:'Programul Tranziție Justă'},
  {key:'PR', label:'Programe Regionale'},
  {key:'OTHER', label:'Programul Asistență Tehnică'}
];
const PROGRAM_LABEL = Object.fromEntries(PROGRAMS.map(p=>[p.key,p.label]));
const META_COLS = ['__program_key','__share_value','__share_projects','__counties_raw','__row_number','__program_label'];
const DEFAULT_EXTRA_COLS_RAW = ['PROGRAMUL','OBIECTIVE SPECIFICE','PRIORITATE','FOND','STATUS',];
const normKey = s => String(s).toUpperCase().replace(/[^A-Z0-9]/g,'');

const fmtMoney = n => new Intl.NumberFormat('ro-RO',{style:'currency',currency:'RON',maximumFractionDigits:0}).format(n||0);
const labelize = s => (s||'').replace(/^_+|_+$/g,'').replace(/_/g,' ').replace(/\s+/g,' ').replace(/\b\w/g,m=>m.toUpperCase());

let raw = [];
let rowsAll = [];
let filtered = [];
let colLabels = {};
let allCols = [];
let chosenCols = [];
let primaryCols = [];
let showAllCols = false;

let page = 1;
// PAGE_SIZE: 0 means "All"
let PAGE_SIZE = Number(localStorage.getItem('mapexp_page_size') || '10');
if (Number.isNaN(PAGE_SIZE)) PAGE_SIZE = 10;

// Sorting
let sortKey = null;   // '__share_value' | 'COD_SMIS' | any visible column key
let sortDir = 'asc';  // 'asc' | 'desc'

// Filter key mapping
const COL_KEY = { OBJECTIVE:null, STATUS:null, PROGRAMUL:null, IMPLEMENTARE:null };

function isMultiRow(r){ return String(r?.IMPLEMENTARE||'').toLowerCase().trim()==='multi_judete'; }

// Dataset switch
const dsSel = document.getElementById('datasetSel');
if (dsSel) {
  dsSel.addEventListener('change', (e) => {
    const ds = e.target.value;
    const params = new URLSearchParams(window.location.search);
    params.set('ds', ds);
    params.set('mode',   PARAM_MODE || 'general');
    params.set('metric', PARAM_METRIC || 'value');
    if (PARAM_MODE === 'program' && PARAM_PROGRAM) params.set('program', PARAM_PROGRAM);
    window.location.search = params.toString();
  });
}

async function loadData(){
  const r = await fetch(DATA_URL, {cache:'no-store'}); if(!r.ok) throw new Error('Nu pot încărca datasetul: ' + DATA_URL);
  raw = await r.json(); if(!Array.isArray(raw)) raw=[];

  // collect extras from all counties
  let all = [];
  for (const c of raw){
    const rr = Array.isArray(c.extras?.rows) ? c.extras.rows : [];
    rr.forEach(x => { if (!x.__program_label && x.__program_key) x.__program_label = PROGRAM_LABEL[x.__program_key] || x.__program_key; });
    all.push(...rr);
    if (!colLabels || Object.keys(colLabels).length===0) colLabels = c.extras?.col_labels || colLabels;
  }
  rowsAll = (PARAM_MODE === 'multi') ? all.filter(isMultiRow) : all.slice();

  computeColumns(rowsAll);
  mapCanonicalFilterKeys();

  if (!sortKey) { sortKey = '__share_value'; sortDir = 'desc'; }
}

function computeColumns(rows){
  const set = new Set();
  for (const r of rows) Object.keys(r).forEach(k => set.add(k));
  allCols = Array.from(set).filter(k => !META_COLS.includes(k));

  const counts = allCols.map(k=>{ let n=0; for (const r of rows){ const v=r[k]; if (v!=null && String(v).trim()!=='') n++; } return {k, n}; })
                        .sort((a,b)=> b.n - a.n);
  primaryCols = counts.slice(0,10).map(x=>x.k);

  const byNorm = {}; for (const k of allCols) byNorm[normKey(k)] = k;
  const resolved = [];
  for (const want of DEFAULT_EXTRA_COLS_RAW){
    const hit = byNorm[normKey(want)];
    if (hit) resolved.push(hit);
  }
  chosenCols = resolved.length ? resolved : primaryCols.slice();
}

function mapCanonicalFilterKeys(){
  const byNorm = {}; for (const k of allCols) byNorm[normKey(k)] = k;
  COL_KEY.OBJECTIVE    = byNorm['OBIECTIVESPECIFICE'] || byNorm['OBIECTIVE_SPECIFICE'] || null;
  COL_KEY.STATUS       = byNorm['STATUS']       || null;
  COL_KEY.PROGRAMUL    = byNorm['PROGRAMUL']    || null;
  COL_KEY.IMPLEMENTARE = byNorm['IMPLEMENTARE'] || null;
}

function labelOf(k){ return (colLabels && colLabels[k]) ? colLabels[k] : labelize(k); }

function buildColumnPicker(){
  const grid = document.getElementById('colGrid');
  grid.innerHTML = '';
  const cols = allCols.slice();
  cols.sort((a,b)=>{
    const ai = chosenCols.indexOf(a), bi = chosenCols.indexOf(b);
    if (ai === -1 && bi === -1) return a.localeCompare(b);
    if (ai === -1) return 1;
    if (bi === -1) return -1;
    return ai - bi;
  });
  for (const k of cols){
    const id = 'col_' + k;
    const wrapper = document.createElement('label');
    wrapper.setAttribute('for', id);
    wrapper.style.display = 'flex';
    wrapper.style.alignItems = 'center';
    wrapper.style.gap = '6px';
    wrapper.style.fontSize = '13px';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.id = id;
    cb.value = k;
    cb.checked = chosenCols.includes(k);

    const span = document.createElement('span');
    span.textContent = labelOf(k);

    wrapper.appendChild(cb);
    wrapper.appendChild(span);
    grid.appendChild(wrapper);
  }
}
function syncPickerChecks(){ document.querySelectorAll('#colGrid input[type="checkbox"]').forEach(b=> b.checked = chosenCols.includes(b.value)); }
function setAllPickerChecks(flag){
  const boxes = document.querySelectorAll('#colGrid input[type="checkbox"]');
  boxes.forEach(b=> b.checked = !!flag);
  chosenCols = flag ? Array.from(boxes).map(b=>b.value) : [];
}

function buildValueOptionsForColumn(actualKey, selectEl){
  if (!selectEl) return;
  const vals = new Set();
  if (actualKey){
    for (const r of rowsAll){
      const v = r[actualKey];
      const s = (v==null) ? '' : String(v).trim();
      if (s) vals.add(s);
    }
  }
  const arr = Array.from(vals).sort((a,b)=> a.localeCompare(b, 'ro'));
  selectEl.innerHTML = ['<option value="__ALL__">Toate</option>']
    .concat(arr.map(v => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`))
    .join('');
  selectEl.value = '__ALL__';
}
function escapeHtml(s){ return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

function initFilters(){
  const programSel = document.getElementById('programFilter');
  const keys = Array.from(new Set(rowsAll.map(r => r.__program_key).filter(Boolean)));
  const opts = [{key:'__ALL__', label:'Toate programele'}].concat(keys.map(k => ({key:k, label: PROGRAM_LABEL[k] || k})));
  programSel.innerHTML = opts.map(o=>`<option value="${o.key}">${escapeHtml(o.label)}</option>`).join('');
  programSel.value = (PARAM_MODE==='program' && PARAM_PROGRAM) ? PARAM_PROGRAM : '__ALL__';

  buildValueOptionsForColumn(COL_KEY.OBJECTIVE,    document.getElementById('objectiveFilter'));
  buildValueOptionsForColumn(COL_KEY.STATUS,       document.getElementById('statusFilter'));
  buildValueOptionsForColumn(COL_KEY.IMPLEMENTARE, document.getElementById('implementareFilter'));

  programSel.addEventListener('change', ()=>{ page=1; applyFiltersAndRender(); });
  document.getElementById('objectiveFilter').addEventListener('change', ()=>{ page=1; applyFiltersAndRender(); });
  document.getElementById('statusFilter').addEventListener('change', ()=>{ page=1; applyFiltersAndRender(); });
  document.getElementById('implementareFilter').addEventListener('change', ()=>{ page=1; applyFiltersAndRender(); });

  document.getElementById('searchBox').addEventListener('input', ()=>{ page=1; applyFiltersAndRender(); });

  const picker = document.getElementById('colPicker');
  document.getElementById('pickColsBtn').addEventListener('click', ()=>{ picker.classList.toggle('show'); syncPickerChecks(); });
  document.addEventListener('click', (e)=>{ const wrap=document.querySelector('.colpicker-wrap'); if (!wrap.contains(e.target)) picker.classList.remove('show'); });
  document.getElementById('colSelectAllBtn').addEventListener('click', ()=> setAllPickerChecks(true));
  document.getElementById('colClearBtn').addEventListener('click', ()=> setAllPickerChecks(false));
  document.getElementById('colDefaultBtn').addEventListener('click', ()=>{ computeColumns(rowsAll); buildColumnPicker(); syncPickerChecks(); });
  document.getElementById('colApplyBtn').addEventListener('click', ()=>{
    const boxes = document.querySelectorAll('#colGrid input[type="checkbox"]');
    const chosen=[]; boxes.forEach(b=>{ if (b.checked) chosen.push(b.value); });
    chosenCols = chosen; showAllCols=false;
    document.getElementById('showAllCols').checked = false;
    page=1; renderTable();
  });

  document.getElementById('showAllCols').addEventListener('change', (e)=>{ showAllCols = !!e.target.checked; page=1; renderTable(); });

  document.getElementById('prevBtn').addEventListener('click', ()=>{ if(page>1){ page--; renderTable(); } });
  document.getElementById('nextBtn').addEventListener('click', ()=>{ const pages=Math.max(1, Math.ceil(filtered.length/getPageSize())); if(page<pages){ page++; renderTable(); } });

  // Page size selector
  const pageSizeSel = document.getElementById('pageSizeSel');
  pageSizeSel.value = String(PAGE_SIZE);
  pageSizeSel.addEventListener('change', ()=>{
    const v = parseInt(pageSizeSel.value, 10);
    PAGE_SIZE = Number.isFinite(v) ? v : 10;
    localStorage.setItem('mapexp_page_size', String(PAGE_SIZE));
    page = 1;
    renderTable();
  });

  document.getElementById('exportBtn').addEventListener('click', exportCSV);
}

function visibleCols(){
  if (showAllCols) return allCols;
  if (chosenCols && chosenCols.length) return chosenCols;
  return primaryCols;
}

function applyFiltersAndRender(){
  const programSel = document.getElementById('programFilter').value;
  const objectSel  = document.getElementById('objectiveFilter').value;
  const statusSel  = document.getElementById('statusFilter').value;
  const implSel    = document.getElementById('implementareFilter').value;
  const q          = (document.getElementById('searchBox').value || '').toLowerCase();

  filtered = rowsAll.filter(r=>{
    if (programSel !== '__ALL__' && r.__program_key !== programSel) return false;
    if (objectSel !== '__ALL__'  && COL_KEY.OBJECTIVE    && String(r[COL_KEY.OBJECTIVE]    || '').trim() !== objectSel) return false;
    if (statusSel !== '__ALL__'  && COL_KEY.STATUS       && String(r[COL_KEY.STATUS]        || '').trim() !== statusSel) return false;
    if (implSel   !== '__ALL__'  && COL_KEY.IMPLEMENTARE && String(r[COL_KEY.IMPLEMENTARE]  || '').trim() !== implSel) return false;

    if (q){
      for (const [k,v] of Object.entries(r)){
        if (v == null) continue;
        const s = String(v).toLowerCase();
        if (s.includes(q)) return true;
      }
      return false;
    }
    return true;
  });

  page = 1;
  renderTable();
}

function projectLink(smis){
  const a = document.createElement('a');
  a.href = 'project.php?smis=' + encodeURIComponent(String(smis)) + '&ds=' + encodeURIComponent(DS_FILE);
  a.className = 'smis-link';
  a.textContent = String(smis);
  a.title = 'Deschide detalii proiect';
  return a;
}

// Sorting helpers
function parseNumberLoose(v){
  if (v == null) return NaN;
  if (typeof v === 'number') return v;
  const s = String(v).trim();
  if (!s) return NaN;
  const t = s.replace(/\./g,'').replace(/,/g,'.').replace(/[^\d\.\-eE]/g,'');
  const n = parseFloat(t);
  return Number.isFinite(n) ? n : NaN;
}
function compareValues(a, b, dir){
  const na = parseNumberLoose(a);
  const nb = parseNumberLoose(b);
  let cmp;
  if (!Number.isNaN(na) && !Number.isNaN(nb)) cmp = na - nb;
  else {
    const sa = (a==null?'':String(a)).toLocaleLowerCase('ro-RO');
    const sb = (b==null?'':String(b)).toLocaleLowerCase('ro-RO');
    cmp = sa.localeCompare(sb, 'ro');
  }
  return dir === 'asc' ? cmp : -cmp;
}
function getSortValue(row, key){
  if (key === '__share_value') return row.__share_value || 0;
  if (key === 'COD_SMIS') return (row.COD_SMIS ?? '');
  return row[key];
}

// Page size getter (0 => all)
function getPageSize(){ return PAGE_SIZE === 0 ? Number.MAX_SAFE_INTEGER : PAGE_SIZE; }

function renderTable(){
  const head = document.getElementById('tblHead');
  const body = document.getElementById('tblBody');
  const pageInfo = document.getElementById('pageInfo');
  const countInfo= document.getElementById('countInfo');

  const cols = visibleCols().filter(k => normKey(k) !== 'CODSMIS');

  // Headers (sortable)
  head.textContent = '';
  const headers = [
    {label:'COD SMIS', key:'COD_SMIS'},
    {label:'Valoare',  key:'__share_value'},
    ...cols.map(k=>({label:labelOf(k), key:k}))
  ];
  for (const h of headers){
    const th = document.createElement('th');
    th.textContent = h.label;
    th.classList.add('sortable');
    th.dataset.key = h.key;
    th.setAttribute('role','button');
    th.tabIndex = 0;

    const arrow = document.createElement('span');
    arrow.className = 'arrow';
    th.appendChild(arrow);

    th.addEventListener('click', ()=> onClickSort(h.key));
    th.addEventListener('keydown', (e)=>{ if (e.key==='Enter' || e.key===' ') { e.preventDefault(); onClickSort(h.key);} });

    th.setAttribute('aria-sort', sortKey === h.key ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none');
    head.appendChild(th);
  }

  // Sort rows
  const sorted = filtered.slice().sort((ra, rb) => compareValues(getSortValue(ra, sortKey), getSortValue(rb, sortKey), sortDir));

  // Pagination
  const total = sorted.length;
  const ps = getPageSize();
  const pages = Math.max(1, Math.ceil(total / ps));
  if (page > pages) page = pages;
  const start = (page-1) * ps;
  const end   = Math.min(total, start + ps);
  const slice = sorted.slice(start, end);

  // Body
  body.innerHTML = '';
  for (const r of slice){
    const tr = document.createElement('tr');

    const tdSmisFirst = document.createElement('td');
    if (r.COD_SMIS != null && String(r.COD_SMIS).trim() !== '') tdSmisFirst.appendChild(projectLink(r.COD_SMIS));
    else tdSmisFirst.textContent = '—';
    tr.appendChild(tdSmisFirst);

    const tdVal  = document.createElement('td');
    tdVal.className='num';
    tdVal.textContent = fmtMoney(r.__share_value || 0);
    tr.appendChild(tdVal);

    for (const k of cols){
      const td = document.createElement('td');
      let v = r[k]; if (v==null || String(v).trim()==='') v='—';
      td.textContent = String(v);
      tr.appendChild(td);
    }
    body.appendChild(tr);
  }

  // Page info
  const pagesTxt = (PAGE_SIZE === 0) ? '1 / 1' : `${page} / ${pages}`;
  pageInfo.textContent = `Pagina ${pagesTxt}`;
  countInfo.textContent = `${total} Proiecte`;
}

function onClickSort(key){
  if (sortKey === key){
    sortDir = (sortDir === 'asc') ? 'desc' : 'asc';
  } else {
    sortKey = key;
    const probe = filtered.length ? getSortValue(filtered[0], key) : '';
    sortDir = Number.isFinite(parseNumberLoose(probe)) ? 'desc' : 'asc';
  }
  page = 1;
  renderTable();
}

function exportCSV(){
  const cols = visibleCols().filter(k => normKey(k) !== 'CODSMIS');
  const header = ['COD SMIS','Valoare'].concat(cols.map(k => labelOf(k)));
  const lines = [header.join(',')];

  const sorted = filtered.slice().sort((ra, rb) => compareValues(getSortValue(ra, sortKey), getSortValue(rb, sortKey), sortDir));
  for (const r of sorted){
    const row = [
      String(r.COD_SMIS || '').replace(/"/g,'""'),
      String(r.__share_value || 0)
    ];
    for (const k of cols){
      const v = (r[k] == null) ? '' : String(r[k]);
      row.push(/[",\n]/.test(v) ? `"${v.replace(/"/g,'""')}"` : v);
    }
    lines.push(row.join(','));
  }

  const safeDs = DS_FILE.replace(/[^A-Za-z0-9_.-]/g,'_');
  const name   = `export_harta_${PARAM_MODE}${PARAM_PROGRAM?'_'+PARAM_PROGRAM:''}_${safeDs}.csv`;

  const blob = new Blob([lines.join('\n')], {type:'text/csv;charset=utf-8;'}); const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

// Boot
(async function boot(){
  try{
    await loadData();
    buildColumnPicker();
    initFilters();
    applyFiltersAndRender();
  }catch(e){
    console.warn(e); alert('A apărut o eroare la încărcarea datelor.');
  }
})();
</script>
</body>
</html>
