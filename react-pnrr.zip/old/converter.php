<?php
// upload_funds_converter.php  (enhanced + writes *-funds-lite.json too)
// - Remembers last choices in the browser (localStorage)
// - Defaults output name to today's ddmmyyyy-funds.json
// - Lists existing *-funds.json; easy to pick/avoid overwrites
// - After success, shows quick links (including lite)
// - ALSO: generates a compact <name>-funds-lite.json that map.php can load fast

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '1');

// ------------------------ CONFIG ------------------------
$CONFIG = [
  'output_dir' => __DIR__ . '',
  'county_map' => [
    'AB'=>'Alba','AG'=>'Argeș','AR'=>'Arad','BC'=>'Bacău','BH'=>'Bihor','BN'=>'Bistrița-Năsăud',
    'BR'=>'Brăila','BT'=>'Botoșani','BV'=>'Brașov','BZ'=>'Buzău','CJ'=>'Cluj','CL'=>'Călărași',
    'CS'=>'Caraș-Severin','CT'=>'Constanța','CV'=>'Covasna','DB'=>'Dâmbovița','DJ'=>'Dolj','GJ'=>'Gorj',
    'GL'=>'Galați','GR'=>'Giurgiu','HD'=>'Hunedoara','HR'=>'Harghita','IF'=>'Ilfov','IL'=>'Ialomița',
    'IS'=>'Iași','MH'=>'Mehedinți','MM'=>'Maramureș','MS'=>'Mureș','NT'=>'Neamț','OT'=>'Olt',
    'PH'=>'Prahova','SB'=>'Sibiu','SJ'=>'Sălaj','SM'=>'Satu Mare','SV'=>'Suceava','TL'=>'Tulcea',
    'TM'=>'Timiș','TR'=>'Teleorman','VL'=>'Vâlcea','VN'=>'Vrancea','VS'=>'Vaslui','BI'=>'București'
  ],
  'county_columns'        => ['IMPLEMENTARE','IMPLEMETARE','JUDEȚE PROIECT IMPLEMENTARE','JUDEȚ','JUD','Judet','Județ','Beneficiar județ','JUD_IMP'],
  'program_columns'       => ['PROGRAMUL'],
  'value_columns'         => ['VALOARE TOTALĂ PROIECT','BUGET TOTAL UE','VALOARE TOTALA UE','VALOARE TOTALĂ UE','VALOARE','VALOARE PROIECT','BUGET TOTAL'],
  'project_count_columns' => ['NR PROIECTE','NR_PROIECTE','NUMAR PROIECTE','NUMĂR PROIECTE'],
  'program_dict' => [
    'PDD'=>['Dezvoltare Durabilă','dezvoltare','dezvoltare durabilă','dezvoltare durabila'],
    'PEO'=>['Educație și Ocupare','educatie si ocupare','educație și ocupare','ocupare'],
    'PIDS'=>['Incluziune și Demnitate Socială','incluziune si demnitate sociala','incluziune'],
    'POCIDIF'=>['Creștere Inteligentă, Digitalizare și Instrumente Financiare','instrumente','crestere inteligenta','digitalizare','instrumente financiare','cdif'],
    'PS'=>['Sănătate','sanatate','program sănătate','sănătate','spitalicești'],
    'PT'=>['Transport','transport'],
    'PTJ'=>['Tranziție Justă','tranzitie justa','justa'],
    'PR'=>['Regional','regional','programe regionale']
  ],
  'column_label_overrides' => [
    'OPERAIUNE'=>'OPERAȚIUNE','TIP_ORGANIZAIE'=>'TIP ORGANIZAȚIE',
    'JUDEE_PROIECT_IMPLEMENTARE'=>'JUDEȚE PROIECT IMPLEMENTARE','REGIUNE_PROIECT_IMPLEMENTARE'=>'REGIUNE PROIECT IMPLEMENTARE',
    'AUTORITATE_RESPONSABIL'=>'AUTORITATE RESPONSABILĂ','OBIECTIVE_SPECIFICE'=>'OBIECTIVE SPECIFICE',
    'DATA_NCEPERE_PROIECT'=>'DATA ÎNCEPERE PROIECT','CUI_LIDER'=>'CUI LIDER','TITLU_PROIECT'=>'TITLU PROIECT',
    'BUGET_TOTAL_ELIGIBIL'=>'BUGET TOTAL ELIGIBIL','BUGET_DE_STAT_TOTAL'=>'BUGET DE STAT TOTAL',
    'BUGET_CONTRIBUIE_PROPRIE_TOTAL'=>'BUGET CONTRIBUȚIE PROPRIE TOTALĂ',
    'VALOARE_TOTAL_PROIECT'=>'VALOARE TOTAL PROIECT','COD_APEL'=>'COD APEL','TITLU_APEL'=>'TITLU APEL',
    'TIP_APEL'=>'TIP APEL','PROGRAMUL'=>'PROGRAMUL','PRIORITATE'=>'PRIORITATE','FOND'=>'FOND','COD_SMIS'=>'COD SMIS','STATUS'=>'STATUS',
  ],
  'special_buckets' => [
    'multi_judete' => 'Multi-județe',
    'nespecificat' => 'Nespecificat'
  ],
];

// ---------- helper functions ----------
function to_ascii_lower(string $s): string { $s2=@iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s); if($s2===false)$s2=$s; return strtolower($s2); }
function detect_delimiter(string $file): string { $fh=@fopen($file,'r'); if(!$fh) return ','; $line=fgets($fh); fclose($fh);
  $cand=[',',';','\t','|']; $best=','; $max=0; foreach($cand as $d){ $parts=str_getcsv((string)$line,$d); if(count($parts)>$max){$max=count($parts);$best=$d;}} return $best; }
function parse_money($raw): float { if($raw===null) return 0.0; $s=trim((string)$raw); if($s==='') return 0.0; $s=preg_replace('/[^\d\-,\.]/u','',$s);
  if(strpos($s,',')!==false && strpos($s,'.')!==false){ $s=preg_replace('/\.(?=\d{3}(\D|$))/', '', $s); $s=str_replace(',','.',$s); }
  else { if(strpos($s,',')!==false) $s=str_replace(',','.',$s); } return (float)$s; }
function split_counties($cell): array { $parts=preg_split('/[,;\/\|\+\–-]+/u',(string)$cell); $out=[]; foreach($parts as $p){$p=trim($p); if($p!=='')$out[]=$p;} return $out; }
function normalize_county_to_code(string $raw, array $county_map): ?string {
  $raw=trim($raw); if($raw==='') return null;
  $t=strtoupper(preg_replace('/\s+/','',$raw));
  if(in_array($t,['B','BU','BI','B-IF','BIF'],true)) return 'BI';
  if(isset($county_map[$t])) return $t;
  if(preg_match('/\bRO-([A-Z]{1,2})\b/i',$raw,$m)){ $c2=strtoupper($m[1]); if(in_array($c2,['B','BU','BI'],true)) return 'BI'; return $county_map[$c2]??null ? $c2 : null; }
  if(preg_match('/\(([A-Z]{1,2})\)/',$raw,$m)){ $c2=strtoupper($m[1]); if(in_array($c2,['B','BU','BI'],true)) return 'BI'; return $county_map[$c2]??null ? $c2 : null; }
  if(preg_match('/\b([A-Z]{1,2})\b/',$raw,$m)){ $c2=strtoupper($m[1]); if(isset($county_map[$c2])) return $c2; }
  $low=to_ascii_lower($raw); if(strpos($low,'bucure')!==false) return 'BI';
  foreach($county_map as $code=>$name){ $name_ascii=to_ascii_lower($name); if($low===$name_ascii) return $code; if(strpos($low,$name_ascii)!==false) return $code; }
  return null;
}
function sanitize_key(string $s): string { $s=trim($s); $s=preg_replace('/\s+/','_',$s); $s=preg_replace('/[^A-Za-z0-9_]/','',$s); return $s===''?'col':$s; }
function ensure_programs_zeroes(): array {
  return ['PDD'=>['value'=>0,'projects'=>0],'PEO'=>['value'=>0,'projects'=>0],'PIDS'=>['value'=>0,'projects'=>0],
          'POCIDIF'=>['value'=>0,'projects'=>0],'PS'=>['value'=>0,'projects'=>0],'PT'=>['value'=>0,'projects'=>0],
          'PTJ'=>['value'=>0,'projects'=>0],'PR'=>['value'=>0,'projects'=>0],'OTHER'=>['value'=>0,'projects'=>0]];
}
function normalize_program_key(string $label, array $dict): string {
  $k=to_ascii_lower(trim($label));
  foreach($dict as $key=>$variants){ foreach($variants as $v){ if(strpos($k,to_ascii_lower($v))!==false) return $key; } }
  $simple=strtoupper(preg_replace('/[^A-Za-z]/','',$label));
  return isset($dict[$simple]) ? $simple : 'OTHER';
}
function find_col(array $colIndex, array $cands): array {
  foreach($cands as $c) if(array_key_exists($c,$colIndex)) return [$c,$colIndex[$c]];
  foreach($cands as $cand) foreach($colIndex as $name=>$i) if(strcasecmp($name,$cand)===0) return [$name,$i];
  return [null,null];
}
function web_path_for(string $absFile): ?string {
  if(!isset($_SERVER['DOCUMENT_ROOT'])) return null;
  $doc=rtrim(realpath($_SERVER['DOCUMENT_ROOT'])?:$_SERVER['DOCUMENT_ROOT'],'/\\');
  $abs=realpath($absFile)?:$absFile;
  if(strpos($abs,$doc)===0){ $rel=substr($abs,strlen($doc)); $rel=str_replace(DIRECTORY_SEPARATOR,'/',$rel); return $rel===''?'/':$rel; }
  return null;
}
function json_min(array $data): string {
  $j = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if ($j === false) throw new RuntimeException('JSON encode failed');
  return $j;
}

// ---------- lite helpers ----------
function r2($n){ return round((float)$n, 2); }

/**
 * Parse targets from JUDEE_PROIECT_IMPLEMENTARE / JUDETE_PROIECT_IMPLEMENTARE (if present).
 * Returns array of C2 codes (e.g., ["CT","AB"]).
 */
function parse_targets_from_row(array $row, array $sanMap, array $colIndex, array $county_map): array {
  $candSans = ['JUDEE_PROIECT_IMPLEMENTARE','JUDETE_PROIECT_IMPLEMENTARE'];
  $vals = [];
  foreach ($candSans as $san){
    if (!isset($sanMap[$san])) continue;
    $orig = $sanMap[$san];
    $cell = $row[$colIndex[$orig]] ?? '';
    if ($cell === '' || $cell === null) continue;
    $parts = preg_split('/[,;\/\|\+\–-]+/u', (string)$cell) ?: [];
    foreach ($parts as $p){
      $c2 = normalize_county_to_code($p, $county_map);
      if ($c2) $vals[] = $c2;
    }
  }
  if (!$vals) return [];
  // unique, preserve order
  $seen = []; $out = [];
  foreach ($vals as $c2){ if (!isset($seen[$c2])){ $seen[$c2]=1; $out[]=$c2; } }
  return $out;
}

/** Build the "lite" array from full data + precomputed multi aggs */
function build_lite_from_full(array $full, array $multiAggCounty, array $multiAggProgram): array {
  $lite = [];
  foreach ($full as $r){
    $code = (string)($r['code'] ?? '');
    $name = (string)($r['name'] ?? '');
    if ($code === '' || stripos($code,'RO-') !== 0) continue;       // skip special slugs
    $upper = strtoupper($code);
    if ($upper === 'RO-MULTI' || $upper === 'RO-NS') continue;      // skip invented in base
    $tot = $r['total'] ?? ['value'=>0,'projects'=>0];
    $progs = $r['programs'] ?? [];
    $row = [
      'code'     => $code,
      'name'     => $name,
      'total'    => ['value'=>r2($tot['value'] ?? 0), 'projects'=>r2($tot['projects'] ?? 0)],
      'programs' => []
    ];
    foreach ($progs as $k=>$pv){
      $row['programs'][$k] = ['value'=>r2($pv['value'] ?? 0), 'projects'=>r2($pv['projects'] ?? 0)];
    }
    $lite[] = $row;
  }
  // append RO-MULTI carrier with precomputed extras
  $lite[] = [
    'code' => 'RO-MULTI',
    'name' => 'Multi județe',
    'extras' => [
      'multi_agg_by_county'  => $multiAggCounty,
      'multi_agg_by_program' => $multiAggProgram
    ]
  ];
  // keep alphabetical by name for counties only; leave RO-MULTI last
  usort($lite, function($a,$b){
    if (($a['code'] ?? '') === 'RO-MULTI') return 1;
    if (($b['code'] ?? '') === 'RO-MULTI') return -1;
    return strcasecmp($a['name'] ?? '', $b['name'] ?? '');
  });
  return $lite;
}

// ---------- converter core ----------
function convert_csv_to_funds_json_with_meta(
  string $csvPath, string $delimiter, array $county_map, array $county_columns, array $program_columns,
  array $value_columns, array $project_count_columns, array $program_dict,
  string $bucharest_out_ro_code, string $projects_mode, bool $include_row_dumps
): array {
  $initProgDebug=function(array $program_dict): array{
    $codes=array_keys($program_dict); $codes[]='OTHER'; $by=[]; foreach($codes as $c){$by[$c]=['rows'=>0,'examples'=>[]];}
    return ['aliases'=>$program_dict,'by_code'=>$by];
  };
  $meta=['delimiter'=>$delimiter,'columns'=>['county'=>null,'program'=>null,'value'=>null,'projects'=>null],
    'stats'=>['rows_total'=>0,'rows_used'=>0,'rows_skipped_no_county'=>0,'rows_skipped_unknown_county'=>0,'rows_with_value_nonzero'=>0,'rows_with_projects_nonzero'=>0],
    'program_debug'=>$initProgDebug($program_dict)
  ];
  $fh=@fopen($csvPath,'r'); if(!$fh) throw new RuntimeException('Nu pot deschide CSV-ul.');
  $header=fgetcsv($fh,0,$delimiter); if($header===false) throw new RuntimeException('CSV gol.');
  if(isset($header[0])) $header[0]=preg_replace('/^\xEF\xBB\xBF/','',(string)$header[0]);
  $colIndex=[]; $sanMap=[];
  foreach($header as $i=>$name){ $name=trim((string)$name); $colIndex[$name]=$i; $sanMap[sanitize_key($name)]=$name; }

  global $CONFIG; $overrides=$CONFIG['column_label_overrides']??[]; $colLabels=[];
  foreach($sanMap as $san=>$orig){ $pretty=$overrides[$san]??$orig; $pretty=preg_replace('/_+/',' ',$pretty); $pretty=preg_replace('/\s+/',' ',$pretty); $colLabels[$san]=$pretty; }

  [$countyColName,$countyColIdx]=find_col($colIndex,$county_columns);
  [$programColName,$programColIdx]=find_col($colIndex,$program_columns);
  if($countyColIdx===null){ foreach($colIndex as $name=>$i){ $n=to_ascii_lower($name); if(preg_match('/jud|implem|beneficiar.*jud|jude?t/u',$n)){ $countyColName=$name; $countyColIdx=$i; break; }}}
  if($programColIdx===null){ foreach($colIndex as $name=>$i){ $n=to_ascii_lower($name); if(preg_match('/program/u',$n)){ $programColName=$name; $programColIdx=$i; break; }}}

  $valueColName=null; $valueColIdx=null;
  foreach($value_columns as $cand){ [$n,$i]=find_col($colIndex,[$cand]); if($n!==null){ $valueColName=$n; $valueColIdx=$i; break; } }
  if($valueColIdx===null){ foreach($colIndex as $name=>$i){ $n=to_ascii_lower($name); if(preg_match('/valoar|buget|total|sum|eligib/u',$n)){ $valueColName=$name; $valueColIdx=$i; break; }}}
  $projColName=null; $projColIdx=null;
  foreach($project_count_columns as $cand){ [$n,$i]=find_col($colIndex,[$cand]); if($n!==null){ $projColName=$n; $projColIdx=$i; break; } }
  if($projColIdx===null){ foreach($colIndex as $name=>$i){ $n=to_ascii_lower($name); if(preg_match('/proj|numar.*proj|nr.*proj/u',$n)){ $projColName=$name; $projColIdx=$i; break; }}}

  // Fallback auto-pick for value
  if($valueColIdx===null){
    $fh2=@fopen($csvPath,'r'); if($fh2){
      fgetcsv($fh2,0,$delimiter);
      $scores=array_fill(0,count($header),0.0); $seen=0;
      while(($r=fgetcsv($fh2,0,$delimiter))!==false && $seen<200){
        foreach($r as $i=>$cell){ $v=parse_money($cell); if($v!==0.0) $scores[$i]+=abs($v); }
        $seen++;
      }
      fclose($fh2);
      $bestIdx=null; $bestVal=-1;
      foreach($scores as $i=>$sc) if($sc>$bestVal){$bestVal=$sc; $bestIdx=$i;}
      if($bestIdx!==null && $bestVal>0){
        $valueColIdx=$bestIdx; $valueColName=array_search($bestIdx,$colIndex,true);
        if($valueColName===false) $valueColName='col_'.$bestIdx;
      }
    }
  }

  $meta['columns']=['county'=>$countyColName,'program'=>$programColName,'value'=>$valueColName,'projects'=>$projColName];
  if($countyColIdx===null) throw new RuntimeException('Nu am găsit coloana pentru județ (ex. IMPLEMENTARE/JUDET).');

  // Seed all buckets
  $agg=[];
  foreach($county_map as $code2=>$name){
    $ro="RO-$code2"; if($code2==='BI' && $bucharest_out_ro_code) $ro=$bucharest_out_ro_code;
    $agg[$ro]=['code'=>$ro,'name'=>$name,'total'=>['value'=>0,'projects'=>0],'programs'=>ensure_programs_zeroes(),'extras'=>['rows'=>[],'col_labels'=>$colLabels]];
  }
  $special=$CONFIG['special_buckets']??[];
  foreach($special as $slug=>$label){
    $agg[$slug]=['code'=>$slug,'name'=>$label,'total'=>['value'=>0,'projects'=>0],'programs'=>ensure_programs_zeroes(),'extras'=>['rows'=>[],'col_labels'=>$colLabels]];
  }

  // --- NEW: precompute MULTI aggregations for the LITE file ---
  $multiAggByCounty = [];   // c2 => [value, projects]
  $multiAggByProgram = [];  // progKey => [value, projects]

  ini_set('auto_detect_line_endings','1'); set_time_limit(0);
  $rowNum=1;

  while(($row=fgetcsv($fh,0,$delimiter))!==false){
    $meta['stats']['rows_total']++; $rowNum++;
    if(count($row)<count($header)) $row=array_pad($row,count($header),'');

    $countyCell=$row[$countyColIdx]??'';
    if($countyCell===''||$countyCell===null){ $meta['stats']['rows_skipped_no_county']++; continue; }
    $countyParts=split_counties($countyCell); $codesRO=[];
    foreach($countyParts as $cp){
      $slug=preg_replace('/\s+/', '_', to_ascii_lower($cp));
      if(isset($special[$slug])){ $codesRO[$slug]=true; continue; }
      $c2=normalize_county_to_code($cp,$county_map);
      if($c2!==null){ $ro="RO-$c2"; if($c2==='BI' && $bucharest_out_ro_code) $ro=$bucharest_out_ro_code; $codesRO[$ro]=true; }
    }
    if(!$codesRO){ $meta['stats']['rows_skipped_unknown_county']++; continue; }

    $nCounties=count($codesRO);
    $value=0.0; if($valueColIdx!==null){ $value=parse_money($row[$valueColIdx]??''); if($value!=0.0) $meta['stats']['rows_with_value_nonzero']++; }
    $projects=1.0; if($projColIdx!==null){ $p=trim((string)($row[$projColIdx]??'')); $projects=is_numeric(str_replace(',','.',$p))?(float)str_replace(',','.',$p):0.0; if($projects!=0.0)$meta['stats']['rows_with_projects_nonzero']++; }

    $progLabelRaw=$programColIdx!==null?(string)$row[$programColIdx]:''; $progKey=normalize_program_key($progLabelRaw,$program_dict);
    if(!isset($meta['program_debug']['by_code'][$progKey])) $meta['program_debug']['by_code'][$progKey]=['rows'=>0,'examples'=>[]];
    $meta['program_debug']['by_code'][$progKey]['rows']++;
    $exList=&$meta['program_debug']['by_code'][$progKey]['examples']; $exTrim=trim($progLabelRaw);
    if($exTrim!=='' && !in_array($exTrim,$exList,true)){ if(count($exList)<6)$exList[]=$exTrim; } unset($exList);

    foreach(array_keys($codesRO) as $ro){ if(!isset($agg[$ro]['programs'][$progKey])) $agg[$ro]['programs'][$progKey]=['value'=>0,'projects'=>0]; }

    $valueShare=$nCounties>0?($value/$nCounties):$value;
    $projectWeight=($projects_mode==='weighted')?(($projects?:1.0)/$nCounties):($projects?:1.0);

    // Optional row dump
    $dump=null;
    if($include_row_dumps){
      $dump=[]; foreach($sanMap as $san=>$orig){ $dump[$san]=$row[$colIndex[$orig]]??''; }
      $dump['__program_key']=$progKey; $dump['__counties_raw']=$countyCell; $dump['__share_value']=$valueShare; $dump['__share_projects']=$projectWeight; $dump['__row_number']=$rowNum;
    }

    foreach(array_keys($codesRO) as $ro){
      $agg[$ro]['total']['value']+=$valueShare; $agg[$ro]['total']['projects']+=$projectWeight;
      $agg[$ro]['programs'][$progKey]['value']+=$valueShare; $agg[$ro]['programs'][$progKey]['projects']+=$projectWeight;
      if($dump!==null) $agg[$ro]['extras']['rows'][]=$dump;
    }

    // --- NEW: live MULTI aggregation for LITE (using explicit target columns if present) ---
    $targets = parse_targets_from_row($row, $sanMap, $colIndex, $county_map); // array of C2
    if ($targets) {
      $perCounty = $value / max(1, count($targets)); // value split equally across targets
      foreach ($targets as $c2){
        if (!isset($multiAggByCounty[$c2])) $multiAggByCounty[$c2] = ['value'=>0.0,'projects'=>0.0];
        $multiAggByCounty[$c2]['value']    += $perCounty;
        $multiAggByCounty[$c2]['projects'] += $projects; // projects counted fully in each target
      }
      if (!isset($multiAggByProgram[$progKey])) $multiAggByProgram[$progKey] = ['value'=>0.0,'projects'=>0.0];
      $multiAggByProgram[$progKey]['value']    += $value;    // full row value
      $multiAggByProgram[$progKey]['projects'] += $projects; // full row projects
    }

    $meta['stats']['rows_used']++;
  }
  fclose($fh);

  // Round county/program totals
  foreach($agg as &$c){
    $c['total']['value']=round($c['total']['value'],2);
    $c['total']['projects']=round($c['total']['projects'],2);
    foreach($c['programs'] as &$pp){ $pp['value']=round($pp['value'],2); $pp['projects']=round($pp['projects'],2); } unset($pp);
  } unset($c);

  // Round LITE multi aggs
  foreach($multiAggByCounty as &$v){ $v['value']=r2($v['value']); $v['projects']=r2($v['projects']); } unset($v);
  foreach($multiAggByProgram as &$v){ $v['value']=r2($v['value']); $v['projects']=r2($v['projects']); } unset($v);

  $outArr=array_values($agg);
  usort($outArr, fn($a,$b)=> strcasecmp($a['name'],$b['name']));

  return ['data'=>$outArr,'meta'=>$meta,'multiCounty'=>$multiAggByCounty,'multiProgram'=>$multiAggByProgram];
}

// ------------------------ SERVER-SIDE: datasets list + defaults ------------------------
$dir = $CONFIG['output_dir'];
$todayDefault = date('dmY') . '-funds.json';
$existing = glob($dir . '/*-funds.json') ?: [];
usort($existing, function($a,$b){
  $fa=basename($a); $fb=basename($b);
  preg_match('/(\d{8})-funds\.json$/',$fa,$ma);
  preg_match('/(\d{8})-funds\.json$/',$fb,$mb);
  $ta=isset($ma[1]) ? DateTime::createFromFormat('dmY',$ma[1]) : false;
  $tb=isset($mb[1]) ? DateTime::createFromFormat('dmY',$mb[1]) : false;
  $tsa=$ta ? (int)$ta->format('U') : 0;
  $tsb=$tb ? (int)$tb->format('U') : 0;
  return $tsb <=> $tsa; // newest first
});
$existingNames = array_map('basename', $existing);

// ------------------------ HANDLE REQUEST ------------------------
$errors = [];
$result = null;
$downloadUrl = null;
$lastMeta = null;

// lite results (new)
$litePath = null;
$liteUrl  = null;
$liteBytes = 0;
$liteFile = null;

$prefillOutName = $todayDefault;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!is_dir($CONFIG['output_dir'])) { @mkdir($CONFIG['output_dir'], 0775, true); }
  if (!is_dir($CONFIG['output_dir']) || !is_writable($CONFIG['output_dir'])) {
    $errors[] = 'Output directory is not writable: ' . htmlspecialchars($CONFIG['output_dir']);
  }
  if (!isset($_FILES['csv']) || ($_FILES['csv']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    $errors[] = 'Nu s-a încărcat niciun fișier CSV.';
  } else {
    $tmp = $_FILES['csv']['tmp_name'];
    if (!is_uploaded_file($tmp)) $errors[] = 'Fișierul încărcat nu este valid.';
  }

  $outName = trim($_POST['out_name'] ?? $todayDefault);
  if ($outName === '') $outName = $todayDefault;
  $outName = preg_replace('/[^\w\.\-]+/','_', $outName);
  if (!preg_match('/\.json$/i', $outName)) $outName .= '.json';
  $prefillOutName = $outName;
  $outPath = rtrim($CONFIG['output_dir'],'/\\') . DIRECTORY_SEPARATOR . $outName;

  $autoDelim = isset($_POST['auto_delim']);
  $userDelim = $_POST['delimiter'] ?? ',';
  $selDelim  = ($userDelim === '\\t') ? "\t" : ($userDelim ?: ',');
  $projectsMode = ($_POST['projects_mode'] ?? 'weighted') === 'per_row' ? 'per_row' : 'weighted';
  $includeRows  = isset($_POST['include_rows']);
  $buchCode     = ($_POST['buch_code'] ?? 'RO-BI') === 'RO-B' ? 'RO-B' : 'RO-BI';

  if (!$errors) {
    try {
      $csvPath = $_FILES['csv']['tmp_name'];
      $delimiter = $autoDelim ? detect_delimiter($csvPath) : $selDelim;

      $out = convert_csv_to_funds_json_with_meta(
        $csvPath, $delimiter, $CONFIG['county_map'], $CONFIG['county_columns'], $CONFIG['program_columns'],
        $CONFIG['value_columns'], $CONFIG['project_count_columns'], $CONFIG['program_dict'],
        $buchCode, $projectsMode, $includeRows
      );
      $data = $out['data'];
      $lastMeta = $out['meta'];

      // Write full JSON (pretty)
      $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      if ($json === false) throw new RuntimeException('Eroare la encodare JSON.');
      if (file_put_contents($outPath, $json) === false) {
        throw new RuntimeException('Nu pot scrie fișierul de ieșire: ' . $outPath);
      }

      // --- NEW: build & write LITE JSON (minified) ---
      $liteArr = build_lite_from_full($data, $out['multiCounty'] ?? [], $out['multiProgram'] ?? []);
      $litePath = preg_replace('/\.json$/i', '-lite.json', $outPath);
      $liteStr = json_min($liteArr);
      if (file_put_contents($litePath, $liteStr) === false) {
        throw new RuntimeException('Nu pot scrie fișierul LITE: ' . $litePath);
      }
      $liteBytes = strlen($liteStr);
      $liteFile  = basename($litePath);
      $liteUrl   = web_path_for($litePath);

      // success info
      $result = [
        'outPath'   => $outPath,
        'bytes'     => strlen($json),
        'counties'  => count($data),
        'delimiter' => $lastMeta['delimiter'] ?? $delimiter,
        'file'      => basename($outPath),
        'litePath'  => $litePath,
        'liteBytes' => $liteBytes,
        'liteFile'  => $liteFile,
      ];
      $downloadUrl = web_path_for($outPath);

    } catch (Throwable $ex) {
      $errors[] = $ex->getMessage();
    }
  }
}

// ------------------------ HTML ------------------------
?>
<!doctype html>
<html lang="ro">
<head>
<meta charset="utf-8">
<title>CSV → funds.json (upload & convert)</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:#f7fafc;color:#0f172a;margin:0;}
  .wrap{max-width:900px;margin:24px auto;padding:0 16px;}
  h1{font-size:22px;margin:0 0 12px;}
  .card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 8px 24px rgba(2,6,23,.06);padding:16px;}
  .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  @media (max-width:720px){.row{grid-template-columns:1fr}}
  label{display:block;font-weight:600;margin:10px 0 6px;}
  input[type="text"], select{width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px;}
  .muted{color:#64748b;font-size:13px}
  .btn{display:inline-block;background:#0ea5e9;color:#fff;padding:10px 14px;border:0;border-radius:10px;font-weight:700;cursor:pointer}
  .btn:disabled{opacity:.6;cursor:not-allowed}
  .msg{margin-top:14px;padding:10px;border-radius:10px}
  .ok{background:#ecfeff;border:1px solid #a5f3fc}
  .err{background:#fef2f2;border:1px solid #fecaca}
  pre{white-space:pre-wrap;font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;background:#0f172a;color:#e2e8f0;padding:10px;border-radius:10px;overflow:auto}
  table{border-collapse:collapse;width:100%;font-size:14px;margin-top:8px}
  th,td{border:1px solid #e2e8f0;padding:6px 8px;text-align:left;vertical-align:top}
  th{background:#f8fafc;color:#475569}
  code{background:#f1f5f9;padding:1px 4px;border-radius:4px}
  .alias{display:inline-block;background:#eef2ff;padding:2px 6px;border-radius:999px;margin:2px 4px 0 0;font-size:12px}
  .tag{display:inline-block;background:#e2e8f0;border-radius:999px;padding:2px 8px;margin:2px 6px 0 0;font-size:12px}
</style>
</head>
<body>
<div class="wrap">
  <h1>CSV → funds.json</h1>

  <div class="card">
    <form method="post" enctype="multipart/form-data" id="convForm">
      <label>CSV (mare)</label>
      <input type="file" name="csv" accept=".csv,text/csv" required>

      <div class="row">
        <div>
          <label for="out_name">Output filename</label>
          <input type="text" name="out_name" id="out_name" placeholder="ddmmyyyy-funds.json" list="dsList" value="<?=htmlspecialchars($prefillOutName)?>">
          <datalist id="dsList">
            <option value="<?=htmlspecialchars($todayDefault)?>"></option>
            <?php foreach ($existingNames as $fn): ?>
              <option value="<?=htmlspecialchars($fn)?>"></option>
            <?php endforeach; ?>
            <option value="funds.json"></option>
          </datalist>
          <div class="muted">Va fi salvat în: <code><?=htmlspecialchars($CONFIG['output_dir'])?></code></div>
          <div class="muted" style="margin-top:4px">Sugestie: lasă <code><?=htmlspecialchars($todayDefault)?></code> pentru timeline coerent.</div>
        </div>
        <div>
          <label>Proiecte – împărțire</label>
          <select name="projects_mode" id="projects_mode">
            <option value="weighted" selected>Weighted (împarte la nr. de județe din rând)</option>
            <option value="per_row">Per row (valoarea din coloană nu se împarte)</option>
          </select>
        </div>
      </div>

      <div class="row">
        <div>
          <label>Cod București în JSON</label>
          <select name="buch_code" id="buch_code">
            <option value="RO-BI" selected>RO-BI (potrivit cu judet.php actual)</option>
            <option value="RO-B">RO-B (dacă vrei să treci pe RO-B)</option>
          </select>
        </div>
        <div>
          <label>Delimitator CSV</label>
          <select name="delimiter" id="delimiter">
            <option value=",">Virgulă (,)</option>
            <option value=";">Punct și virgulă (;)</option>
            <option value="\t">Tab</option>
            <option value="|">Pipe (|)</option>
          </select>
          <div>
            <label style="margin:6px 0 0;">
              <input type="checkbox" name="auto_delim" id="auto_delim" checked> Detectează automat delimitatorul
            </label>
          </div>
        </div>
      </div>

      <label style="margin-top:8px;">
        <input type="checkbox" name="include_rows" id="include_rows" checked>
        Include <code>extras.rows</code> (toate coloanele, poate fi foarte mare)
      </label>

      <div style="margin-top:14px;">
        <button class="btn" type="submit">Încarcă & Convertește</button>
      </div>

      <div class="muted" style="margin-top:10px;">
        Sfaturi: dacă fișierul e imens, ajustează <code>upload_max_filesize</code>, <code>post_max_size</code> și <code>max_execution_time</code>.
      </div>
    </form>
  </div>

  <?php if ($errors): ?>
    <div class="msg err">
      <strong>Eroare:</strong>
      <ul>
        <?php foreach ($errors as $e): ?><li><?=htmlspecialchars($e)?></li><?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <?php if ($result): ?>
    <div class="msg ok" id="okBox">
      <div><strong>Succes!</strong> Am scris JSON-ul.</div>
      <div>Fișier: <code><?=htmlspecialchars($result['outPath'])?></code> (<?=$result['bytes']?> bytes)</div>
      <div>Județe: <?=$result['counties']?> • Delimitator: <code><?=htmlspecialchars($result['delimiter'])?></code></div>

      <?php if ($downloadUrl): ?>
        <div style="margin-top:6px;"><a class="btn" href="<?=htmlspecialchars($downloadUrl)?>" download>Descarcă JSON</a></div>
      <?php else: ?>
        <div class="muted" style="margin-top:6px;">Fișierul nu pare a fi sub document root, descarcă-l via SFTP/SSH din <code><?=htmlspecialchars($result['outPath'])?></code>.</div>
      <?php endif; ?>

      <?php if ($litePath): ?>
        <div style="margin-top:10px;">
          <strong>Lite generat:</strong>
          <div>Fișier: <code><?=htmlspecialchars($litePath)?></code> (<?= (int)$liteBytes ?> bytes)</div>
          <?php if ($liteUrl): ?>
            <div style="margin-top:6px;"><a class="btn" href="<?=htmlspecialchars($liteUrl)?>" download>Descarcă LITE</a></div>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <!-- Quick links that carry ?ds=<this file> -->
      <?php $dsq = '?ds=' . urlencode($result['file']); $dsl = $liteFile ? '?ds=' . urlencode($liteFile) : $dsq; ?>
      <div style="margin-top:10px;">
        <span class="muted">Deschide direct cu acest dataset:</span><br>
        <a class="tag" href="<?=htmlspecialchars('map.php'.$dsl)?>">map.php (LITE dacă există)</a>
        <a class="tag" href="<?=htmlspecialchars('map_export.php'.$dsq)?>">map_export.php</a>
        <a class="tag" href="<?=htmlspecialchars('animated.php'.$dsq)?>">animated.php</a>
        <a class="tag" href="<?=htmlspecialchars('multi.php'.$dsq)?>">multi.php</a>
        <a class="tag" href="<?=htmlspecialchars('judet.php?c=CT'.$dsq)?>">judet.php (CT)</a>
      </div>

      <?php if ($lastMeta): ?>
        <div class="muted" style="margin-top:10px">
          <div><strong>Detecții coloane</strong> —
            County: <code><?=htmlspecialchars($lastMeta['columns']['county'] ?? '—')?></code>,
            Program: <code><?=htmlspecialchars($lastMeta['columns']['program'] ?? '—')?></code>,
            Value: <code><?=htmlspecialchars($lastMeta['columns']['value'] ?? '—')?></code>,
            Projects: <code><?=htmlspecialchars($lastMeta['columns']['projects'] ?? '—')?></code>
          </div>

          <?php if (!empty($lastMeta['program_debug'])):
            $pd = $lastMeta['program_debug'];
          ?>
          <div style="margin-top:8px;">
            <strong>Detecții Programe</strong>
            <table>
              <thead>
                <tr>
                  <th>Cod</th>
                  <th>Rânduri mapate</th>
                  <th>Exemple etichete din CSV (max 6)</th>
                  <th>Aliasuri acceptate (din configurare)</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($pd['by_code'] as $code => $info): ?>
                  <tr>
                    <td><code><?=htmlspecialchars($code)?></code></td>
                    <td><?= (int)($info['rows'] ?? 0) ?></td>
                    <td>
                      <?php $ex = $info['examples'] ?? [];
                        if (!$ex) echo '<span class="muted">—</span>';
                        else echo implode(';&nbsp; ', array_map('htmlspecialchars', $ex)); ?>
                    </td>
                    <td>
                      <?php $aliases = $pd['aliases'][$code] ?? [];
                        if (!$aliases) echo '<span class="muted">—</span>';
                        else foreach ($aliases as $al) echo '<span class="alias">'.htmlspecialchars($al).'</span>'; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <?php endif; ?>

          <div style="margin-top:8px;"><strong>Statistici</strong> —
            Total rânduri: <?= (int)($lastMeta['stats']['rows_total'] ?? 0) ?>,
            Folosite: <?= (int)($lastMeta['stats']['rows_used'] ?? 0) ?>,
            Fără județ: <?= (int)($lastMeta['stats']['rows_skipped_no_county'] ?? 0) ?>,
            Județ necunoscut: <?= (int)($lastMeta['stats']['rows_skipped_unknown_county'] ?? 0) ?>,
            Valori≠0: <?= (int)($lastMeta['stats']['rows_with_value_nonzero'] ?? 0) ?>,
            Proiecte≠0: <?= (int)($lastMeta['stats']['rows_with_projects_nonzero'] ?? 0) ?>
          </div>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <?php if ($existingNames): ?>
    <div class="card" style="margin-top:14px;">
      <strong>Datasets existente (cele mai noi primele)</strong>
      <div class="muted">Sunt detectate automat de <code>map.php</code>, <code>judet.php</code>, <code>multi.php</code>, <code>project.php</code>, <code>map_export.php</code> și <code>animated.php</code>.</div>
      <div style="margin-top:8px">
        <?php foreach ($existingNames as $fn): ?>
          <span class="tag"><?=htmlspecialchars($fn)?></span>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>

  <div class="card" style="margin-top:14px;">
    <strong>Structură produsă</strong>
    <div class="muted">Compatibilă cu <code>funds.json</code> (+ <code>extras.rows</code> & <code>extras.col_labels</code>). Include și pseudo-județe: <code>multi_judete</code>, <code>nespecificat</code>. Se generează automat și varianta <code>-funds-lite.json</code> pentru încărcare rapidă.</div>
    <pre>[ ... ]</pre>
  </div>
</div>

<script>
// ---- Remember form choices locally ----
(function(){
  const F = document.getElementById('convForm');
  if(!F) return;
  const ids = ['out_name','projects_mode','buch_code','delimiter','auto_delim','include_rows'];

  // Load from localStorage
  ids.forEach(id=>{
    const el = document.getElementById(id);
    if(!el) return;
    const k = 'conv_' + id;
    const v = localStorage.getItem(k);
    if(v==null) return;
    if(el.type === 'checkbox'){ el.checked = (v === '1'); }
    else { el.value = v; }
  });

  // Store on change
  ids.forEach(id=>{
    const el = document.getElementById(id);
    if(!el) return;
    el.addEventListener('change', ()=>{
      const k = 'conv_' + id;
      const v = (el.type === 'checkbox') ? (el.checked ? '1':'0') : el.value;
      localStorage.setItem(k, v);
    });
  });

  // After success, store last dataset filename for other pages
  <?php if ($result && !empty($result['file'])): ?>
    try{ localStorage.setItem('last_ds', <?= json_encode($result['file']) ?>); }catch(e){}
  <?php endif; ?>
})();
</script>
</body>
</html>
