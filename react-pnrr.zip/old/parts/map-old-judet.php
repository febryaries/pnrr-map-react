<!-- County-only map -->
<div id="countyMapWrap" style="max-width:1200px;margin:12px auto 0;padding:0 20px;" hidden>
  <div style="position:relative;border-radius:16px;overflow:hidden;background:#e2e8f0;
              box-shadow:0 8px 24px rgba(2,6,23,.06);">
    <div id="countyMap" role="img" aria-label="Hartă județ" style="width:100%;height:460px;"></div>
    <div id="countyMapCaption" style="position:absolute;right:10px;bottom:10px;padding:6px 10px;font-size:12px;
         border-radius:999px;background:rgba(15,23,42,.7);color:#fff;"></div>
  </div>
</div>

<div class="card" id="scopeLocalitiesCard" hidden>
  <h3 style="margin:0 0 8px 0;">Localități sprijinite</h3>
  <div class="muted" id="scopeLocalitiesSummary"></div>
  <div class="table-wrap">
    <table id="tblScopeLocalities">
      <thead>
  <tr>
    <th>Localitate</th>
    <th class="num">Numarul de proiecte în care aceasta localitate este menționată </th>
    <!--<th class="num">Valoare (RON)</th>-->
  </tr>
</thead>
      <tbody></tbody>
    </table>
  </div>
</div>

<script>
// --- Map & SCOP_PROIECT locality pins (self-contained) ---
let countyMapChart = null;
const CITIES_URL = 'data/ro_localities.min.json';

const norm = s => (s || '')
  .toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
  .replace(/ș|ş/g,'s').replace(/ț|ţ/g,'t')
  .toLowerCase().trim();

function escapeRegExp(s){ return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }

async function renderCountyOnlyMap(){
  const wrap = document.getElementById('countyMapWrap');
  const cap  = document.getElementById('countyMapCaption');
  const MAP_URL = 'https://code.highcharts.com/mapdata/countries/ro/ro-all.topo.json';

  const isBucharest = (COUNTY_2 === 'BI');
  const isoTarget = `RO-${COUNTY_2}`;
  const postalSet = new Set(isBucharest ? ['B','BU','BI'] : [COUNTY_2]);
  const hcKeySet  = new Set([`ro-${COUNTY_2.toLowerCase()}`]);
  if (isBucharest) hcKeySet.add('ro-b');
  const nameSet = new Set([
    norm(COUNTY_NAME),
    norm(`Judetul ${COUNTY_NAME}`),
    norm(`Județul ${COUNTY_NAME}`),
    ...(isBucharest ? [norm('Bucuresti'), norm('Municipiul Bucuresti'), norm('Municipiul București')] : [])
  ]);

  const res = await fetch(MAP_URL, {cache:'no-store'});
  if (!res.ok) return null;
  const topology = await res.json();
  const all = Highcharts.geojson(topology);

  const county = all.filter(f => {
    const p = f.properties || {};
    const name  = norm(p.name || p.NAME || '');
    const hcKey = (p['hc-key'] || p.hcKey || '').toLowerCase();
    const postal= (p['postal-code'] || p.postal || p['postal_code'] || '').toUpperCase();
    const iso   = (p['iso_3166_2'] || p['iso-3166-2'] || p.iso3166_2 || '').toUpperCase();
    const id    = (p.id || '').toUpperCase();
    const hasc  = (p.hasc || '').toUpperCase();
    if (iso === isoTarget) return true;
    if (id === isoTarget || id === isoTarget.replace('-', '.')) return true;
    if (postal && postalSet.has(postal)) return true;
    if (hcKey && hcKeySet.has(hcKey)) return true;
    if (hasc && (hasc === `RO.${COUNTY_2}` || (isBucharest && (hasc === 'RO.B' || hasc === 'RO.BU')))) return true;
    if (name && nameSet.has(name)) return true;
    return false;
  });
  if (!county.length) return null;

  const geo = { type:'FeatureCollection', features: county };

  const chart = Highcharts.mapChart('countyMap', {
    chart: { map: geo, spacing:[0,0,0,0], backgroundColor:'transparent' },
    title: { text: null }, credits: { enabled:false },
    mapNavigation: { enabled:true, enableDoubleClickZoomTo:true,
      buttonOptions:{ verticalAlign:'bottom' } },
    tooltip: { enabled:false }, legend: { enabled:false },
    series: [{
      name: COUNTY_NAME,
      data: county,
      color: '#0ea5e9',
      borderColor: '#334155',
      borderWidth: 1.1,
      enableMouseTracking: false
    }]
  });

  if (chart?.mapView && county[0]?.bounds) {
    chart.mapView.fitToBounds(county[0].bounds, { padding:20 });
  }

  cap.textContent = COUNTY_NAME;
  wrap.hidden = false;
  countyMapChart = chart;
  return chart;
}

// ---- Localities from SCOP_PROIECT ----
let _allCities = null;
async function loadAllCities(){
  if (_allCities) return _allCities;
  try{
    const r = await fetch(CITIES_URL, {cache:'no-store'});
    if(!r.ok) throw new Error('cities not ok');
    _allCities = await r.json();
  }catch(e){ console.warn('Nu pot încărca localitățile:', e); _allCities = []; }
  return _allCities;
}
function buildCountyCityIndex(allCities){
  const list = allCities.filter(c => (c.county || '').toUpperCase() === COUNTY_2);
  return list.map(c => {
    const base = c.name || '';
    const aliasSet = new Set([
      base, ...(c.aliases || []),
      `Municipiul ${base}`, `Orașul ${base}`, `Orasul ${base}`,
      `Comuna ${base}`, `Satul ${base}`,
      base.replace(/-/g,' '), base.replace(/ /g,'-')
    ].map(norm));
    return { name: c.name, lat:+c.lat, lon:+c.lon, aliases: Array.from(aliasSet) };
  });
}
function countLocalitiesFromScope(cityIndex){
  const counts = new Map();
  for (const row of (extrasRows || [])){
    const text = norm(row?.SCOP_PROIECT || row?.Scop_Proiect || row?.Scop || '');
    if (!text) continue;
    const matchedThisRow = new Set();
    for (const city of cityIndex){
      if (matchedThisRow.has(city.name)) continue;
      for (const alias of city.aliases){
        if (!alias) continue;
        const re = new RegExp(`(^|[^a-z0-9])${escapeRegExp(alias)}([^a-z0-9]|$)`, 'i');
        if (re.test(text)){ matchedThisRow.add(city.name); break; }
      }
    }
    matchedThisRow.forEach(name => {
      const city = cityIndex.find(c => c.name === name);
      const prev = counts.get(name);
      counts.set(name, { city, count: (prev?.count || 0) + 1 });
    });
  }
  return Array.from(counts.values()).sort((a,b)=> b.count - a.count);
}
function addScopePinsToMap(chart, hits){
  if (!chart || !hits?.length) return;
  const data = hits.map(h => ({
    name: h.city.name,
    lat:  h.city.lat,
    lon:  h.city.lon,
    count: h.count
  }));

  chart.addSeries({
    type: 'mappoint',
    name: 'Localități din SCOP_PROIECT',
    data,
    marker: { radius: 5, fillColor: '#ef4444', lineColor: '#fff', lineWidth: 1 },
    dataLabels: {
      enabled: true,
      // Show labels at all zoom levels (those that collide are hidden).
      // As you zoom in, more labels get room and appear.
      formatter: function(){ return this.point.name; },
      allowOverlap: false,
      crop: true,
      style: { fontSize: '10px', textOutline: 'none' }
    },
    tooltip:{
      useHTML:true,
      pointFormatter:function(){
        return `<b>${this.name}</b><br/>Proiecte: <b>${this.count}</b>`;
      }
    },
    point: {
      events: {
        click: function(){
          const url = `locality.php?c=${encodeURIComponent(COUNTY_2)}&city=${encodeURIComponent(this.name)}`;
          window.location.assign(url);
        }
      }
    },
    states: { hover: { halo: { size: 8 } } }
  }, true);
}

function renderScopeLocalitiesTable(hits){
  const card = document.getElementById('scopeLocalitiesCard');
  const sum  = document.getElementById('scopeLocalitiesSummary');
  const body = document.querySelector('#tblScopeLocalities tbody');
  if (!hits?.length){ card.hidden = true; return; }

  body.innerHTML = '';
  let total = 0;
  for (const h of hits){
    total += h.count;
    const href = `locality.php?c=${encodeURIComponent(COUNTY_2)}&city=${encodeURIComponent(h.city.name)}`;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><a href="${href}" style="color:#0ea5e9;font-weight:600;text-decoration:none;">${h.city.name}</a></td>
      <td class="num">${new Intl.NumberFormat('ro-RO').format(h.count)}</td>
    `;
    body.appendChild(tr);
  }
  sum.textContent = `${hits.length} localități identificate • ${new Intl.NumberFormat('ro-RO').format(total)} proiecte (sumă pe localități)`;
  card.hidden = false;
}
async function analyzeScopeAndPlot(){
  if (!countyMapChart) await renderCountyOnlyMap();
  const all = await loadAllCities();
  const cityIndex = buildCountyCityIndex(all);
  if (!cityIndex.length){ renderScopeLocalitiesTable([]); return; }
  const hits = countLocalitiesFromScope(cityIndex);
  renderScopeLocalitiesTable(hits);
  if (countyMapChart) addScopePinsToMap(countyMapChart, hits);
}

// React to data ready
document.addEventListener('judet-data-ready', async () => {
  try{
    await renderCountyOnlyMap();
    await analyzeScopeAndPlot();
  }catch(e){ console.warn(e); }
});
</script>
