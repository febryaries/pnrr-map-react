<!-- County-only map -->
<div id="countyMapWrap" style="max-width:1200px;margin:12px auto 0;padding:0 20px;" hidden>
  <div style="position:relative;border-radius:16px;overflow:hidden;background:#e2e8f0;
              box-shadow:0 8px 24px rgba(2,6,23,.06);">
    <div id="countyMap" role="img" aria-label="Hartă județ" style="width:100%;height:460px;"></div>
    <div id="countyMapCaption" style="position:absolute;right:10px;bottom:10px;padding:6px 10px;font-size:12px;
         border-radius:999px;background:rgba(15,23,42,.7);color:#fff;"></div>
  </div>
</div>

<div class="card" id="scopeLocalitiesCard" hidden>
  <h3 style="margin:0 0 8px 0;">Localități sprijinite</h3>
  <div class="muted" id="scopeLocalitiesSummary"></div>
  <div class="table-wrap">
    <table id="tblScopeLocalities">
      <thead>
        <tr>
          <th>Localitate</th>
          <th class="num">Numărul de proiecte în care această localitate este menționată</th>
          <!-- păstrăm lista pe proiecte; valoarea este în tooltip -->
        </tr>
      </thead>
      <tbody></tbody>
    </table>
  </div>
  <div id="scopeToggleWrap" style="margin-top:8px; text-align:right; display:none;">
    <button id="scopeToggleBtn" type="button"
            style="padding:8px 12px;border-radius:10px;background:#e2e8f0;color:#0f172a;border:0;font-weight:700;cursor:pointer">
      Afișează toate
    </button>
  </div>
</div>

<script>
(function() {
  'use strict';
// --- Map & SCOP_PROIECT locality pins (self-contained) ---
let countyMapChart = null;
const CITIES_URL = 'data/ro_localities.min.json';

const norm = s => (s || '')
  .toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
  .replace(/ș|ş/g,'s').replace(/ț|ţ/g,'t')
  .toLowerCase().trim();

function escapeRegExp(s){ return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }

const fmtMoney = n => new Intl.NumberFormat('ro-RO',{style:'currency',currency:'RON',maximumFractionDigits:0}).format(n||0);
const fmtNum   = n => new Intl.NumberFormat('ro-RO').format(n||0);

async function renderCountyOnlyMap(){
  const wrap = document.getElementById('countyMapWrap');
  const cap  = document.getElementById('countyMapCaption');
  const MAP_URL = 'https://code.highcharts.com/mapdata/countries/ro/ro-all.topo.json';

  const isBucharest = (COUNTY_2 === 'BI');
  const isoTarget = `RO-${COUNTY_2}`;
  const postalSet = new Set(isBucharest ? ['B','BU','BI'] : [COUNTY_2]);
  const hcKeySet  = new Set([`ro-${COUNTY_2.toLowerCase()}`]);
  if (isBucharest) hcKeySet.add('ro-b');
  const nameSet = new Set([
    norm(COUNTY_NAME),
    norm(`Judetul ${COUNTY_NAME}`),
    norm(`Județul ${COUNTY_NAME}`),
    ...(isBucharest ? [norm('Bucuresti'), norm('Municipiul Bucuresti'), norm('Municipiul București')] : [])
  ]);

  const res = await fetch(MAP_URL, {cache:'no-store'});
  if (!res.ok) return null;
  const topology = await res.json();
  const all = Highcharts.geojson(topology);

  const county = all.filter(f => {
    const p = f.properties || {};
    const name  = norm(p.name || p.NAME || '');
    const hcKey = (p['hc-key'] || p.hcKey || '').toLowerCase();
    const postal= (p['postal-code'] || p.postal || p['postal_code'] || '').toUpperCase();
    const iso   = (p['iso_3166_2'] || p['iso-3166-2'] || p.iso3166_2 || '').toUpperCase();
    const id    = (p.id || '').toUpperCase();
    const hasc  = (p.hasc || '').toUpperCase();
    if (iso === isoTarget) return true;
    if (id === isoTarget || id === isoTarget.replace('-', '.')) return true;
    if (postal && postalSet.has(postal)) return true;
    if (hcKey && hcKeySet.has(hcKey)) return true;
    if (hasc && (hasc === `RO.${COUNTY_2}` || (isBucharest && (hasc === 'RO.B' || hasc === 'RO.BU')))) return true;
    if (name && nameSet.has(name)) return true;
    return false;
  });
  if (!county.length) return null;

  const geo = { type:'FeatureCollection', features: county };

  const chart = Highcharts.mapChart('countyMap', {
    chart: { map: geo, spacing:[0,0,0,0], backgroundColor:'transparent' },
    title: { text: null }, credits: { enabled:false },
    mapNavigation: { enabled:true, enableDoubleClickZoomTo:true, buttonOptions:{ verticalAlign:'bottom' } },
    tooltip: { enabled:true },   // enable tooltips (pins will provide their own HTML)
    legend: { enabled:false },
    series: [{
      name: COUNTY_NAME,
      data: county,
      color: '#0ea5e9',
      borderColor: '#334155',
      borderWidth: 1.1,
      enableMouseTracking: false  // no polygon tooltip
    }]
  });

  if (chart?.mapView && county[0]?.bounds) {
    chart.mapView.fitToBounds(county[0].bounds, { padding:20 });
  }

  cap.textContent = COUNTY_NAME;
  wrap.hidden = false;
  countyMapChart = chart;
  return chart;
}

// ---- Localities from SCOP_PROIECT ----
let _allCities = null;
async function loadAllCities(){
  if (_allCities) return _allCities;
  try{
    const r = await fetch(CITIES_URL, {cache:'no-store'});
    if(!r.ok) throw new Error('cities not ok');
    _allCities = await r.json();
  }catch(e){ console.warn('Nu pot încărca localitățile:', e); _allCities = []; }
  return _allCities;
}
function buildCountyCityIndex(allCities){
  const list = allCities.filter(c => (c.county || '').toUpperCase() === COUNTY_2);
  return list.map(c => {
    const base = c.name || '';
    const aliasSet = new Set([
      base, ...(c.aliases || []),
      `Municipiul ${base}`, `Orașul ${base}`, `Orasul ${base}`,
      `Comuna ${base}`, `Satul ${base}`,
      base.replace(/-/g,' '), base.replace(/ /g,'-')
    ].map(norm));
    return { name: c.name, lat:+c.lat, lon:+c.lon, aliases: Array.from(aliasSet) };
  });
}

/* Count projects & sum values per localitate.
   For rows that mention multiple localities, value share is split equally between matches in that row. */
function countLocalitiesFromScope(cityIndex){
  const counts = new Map();
  for (const row of (extrasRows || [])){
    const text = norm(row?.SCOP_PROIECT || row?.Scop_Proiect || row?.Scop || '');
    if (!text) continue;

    // which cities match in this row?
    const matched = [];
    for (const city of cityIndex){
      // prevent duplicate alias hits for the same city in a single row
      let hit = false;
      for (const alias of city.aliases){
        if (!alias) continue;
        const re = new RegExp(`(^|[^a-z0-9])${escapeRegExp(alias)}([^a-z0-9]|$)`, 'i');
        if (re.test(text)){ hit = true; break; }
      }
      if (hit) matched.push(city);
    }
    if (!matched.length) continue;

    const rowShareValue = Number(row?.__share_value || 0) || 0;
    const perCityValue = matched.length ? (rowShareValue / matched.length) : 0;

    for (const city of matched){
      const prev = counts.get(city.name) || { city, count:0, money:0 };
      prev.count += 1;
      prev.money += perCityValue;
      counts.set(city.name, prev);
    }
  }
  // sort by count desc, then money desc, then name
  return Array.from(counts.values()).sort((a,b) =>
    (b.count - a.count) || (b.money - a.money) || a.city.name.localeCompare(b.city.name)
  );
}

/* Add pins to map, with tooltip showing projects & value and a link button */
function addScopePinsToMap(chart, hits){
  if (!chart || !hits?.length) return;
  const data = hits.map(h => ({
    name:  h.city.name,
    lat:   h.city.lat,
    lon:   h.city.lon,
    count: h.count,
    money: h.money || 0
  }));

  chart.addSeries({
    type: 'mappoint',
    name: 'Localități din SCOP_PROIECT',
    data,
    marker: { radius: 5, fillColor: '#ef4444', lineColor: '#fff', lineWidth: 1 },
    dataLabels: {
      enabled: true,
      formatter: function(){ return this.point.name; },
      allowOverlap: false,
      crop: true,
      style: { fontSize: '10px', textOutline: 'none' }
    },
    tooltip:{
      useHTML:true,
      pointFormatter:function(){
        const url = `locality.php?c=${encodeURIComponent(COUNTY_2)}&city=${encodeURIComponent(this.name)}`;
        return `<b>${this.name}</b><br/>
                Proiecte: <b>${fmtNum(this.count)}</b><br/>
                Valoare: <b>${fmtMoney(this.money)}</b>
                <div style="margin-top:6px">
                  <a href="${url}" style="display:inline-block;padding:6px 10px;border-radius:8px;
                    background:#0ea5e9;color:#fff;text-decoration:none;font-weight:600">Deschide localitatea</a>
                </div>`;
      }
    },
    point: {
      events: {
        click: function(){
          const url = `locality.php?c=${encodeURIComponent(COUNTY_2)}&city=${encodeURIComponent(this.name)}`;
          window.location.assign(url);
        }
      }
    },
    states: { hover: { halo: { size: 8 } } }
  }, true);
}

/* Table with collapse/expand (default shows 5) */
let _scopeHitsCache = [];
let _scopeShowAll = false;

function renderScopeLocalitiesTable(hits){
  _scopeHitsCache = hits || [];
  const card = document.getElementById('scopeLocalitiesCard');
  const sum  = document.getElementById('scopeLocalitiesSummary');
  const body = document.querySelector('#tblScopeLocalities tbody');
  const togWrap = document.getElementById('scopeToggleWrap');
  const togBtn  = document.getElementById('scopeToggleBtn');

  if (!_scopeHitsCache.length){
    card.hidden = true;
    return;
  }

  const view = _scopeShowAll ? _scopeHitsCache : _scopeHitsCache.slice(0, 5);

  body.innerHTML = '';
  let totalProjects = 0;
  for (const h of view){
    totalProjects += h.count;
    const href = `locality.php?c=${encodeURIComponent(COUNTY_2)}&city=${encodeURIComponent(h.city.name)}`;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><a href="${href}" style="color:#0ea5e9;font-weight:600;text-decoration:none;">${h.city.name}</a></td>
      <td class="num">${fmtNum(h.count)}</td>
    `;
    body.appendChild(tr);
  }

  // Summary uses totals for the whole set (not just the visible slice)
  const allProjects = _scopeHitsCache.reduce((s,h)=>s+h.count,0);
  sum.textContent = `${_scopeHitsCache.length} localități identificate • ${fmtNum(allProjects)} proiecte (sumă pe localități)`;

  // Toggle button visibility + label
  if (_scopeHitsCache.length > 5){
    togWrap.style.display = '';
    togBtn.textContent = _scopeShowAll ? 'Restrânge la 5' : `Afișează toate (${_scopeHitsCache.length})`;
  } else {
    togWrap.style.display = 'none';
  }

  card.hidden = false;
}

// Toggle handler
document.addEventListener('click', (e)=>{
  if (e.target && e.target.id === 'scopeToggleBtn'){
    _scopeShowAll = !_scopeShowAll;
    renderScopeLocalitiesTable(_scopeHitsCache);
  }
});

async function analyzeScopeAndPlot(){
  if (!countyMapChart) await renderCountyOnlyMap();
  const all = await loadAllCities();
  const cityIndex = buildCountyCityIndex(all);
  if (!cityIndex.length){ renderScopeLocalitiesTable([]); return; }
  const hits = countLocalitiesFromScope(cityIndex);
  renderScopeLocalitiesTable(hits);
  if (countyMapChart) addScopePinsToMap(countyMapChart, hits);
}

// React to data ready
document.addEventListener('judet-data-ready', async () => {
  try{
    await renderCountyOnlyMap();
    await analyzeScopeAndPlot();
  }catch(e){ console.warn(e); }
});
})();
</script>
