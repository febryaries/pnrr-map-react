<div class="card"> 
  <h3 style="margin:0 0 8px 0;">Detaliu pe programe</h3>
  <div class="muted" style="margin-bottom:10px;">Valorile sunt filtrate pentru județul <?=htmlspecialchars($name)?> (<?=$code?>)</div>

  <div class="table-wrap">
    <table id="tblPrograms">
      <thead>
        <tr>
          <th>Program</th>
          <th class="num">Valoare (RON)</th>
          <th class="num">Proiecte</th>
        </tr>
      </thead>
      <tbody></tbody>
    </table>
  </div>

  <!-- Multi-județe totals line (kept) -->
  <div class="muted" id="multiTotals" style="margin-top:8px;">—</div>
</div>

<script>
// Re-use globals from judet.php: countyRow, allData, COUNTY_2, fmtMoney, fmtNum, PROGRAMS, PROGRAM_COLORS
// Also re-uses chartPrograms, rightChart, metric

/* ===== Helpers for Multi județe (same logic) ===== */
function normc(t){
  const s = String(t||'').toUpperCase().trim();
  if (s === 'B' || s === 'BU' || s === 'BI') return 'BI';
  return s.replace(/[^A-Z]/g,'').slice(0,2);
}
function parseTargets(raw){
  return String(raw||'').split(',').map(x => normc(x)).filter(Boolean);
}
function isMultiRow(r){
  return String(r?.IMPLEMENTARE || '').toLowerCase().trim() === 'multi_judete';
}
/* value split egal între județe; proiecte numărate plin în fiecare județ */
function computeMultiTotalsForCounty(c2){
  let rows = [];
  const carrier = allData.find(x => x.code === 'RO-MULTI');
  if (carrier?.extras?.rows) rows = carrier.extras.rows.slice();
  else allData.forEach(x => Array.isArray(x.extras?.rows) && rows.push(...x.extras.rows));
  rows = rows.filter(isMultiRow);

  let val = 0, proj = 0;
  for (const r of rows){
    const targets = parseTargets(r['JUDEE_PROIECT_IMPLEMENTARE'] || r['JUDETE_PROIECT_IMPLEMENTARE']);
    if (!targets.length || !targets.includes(c2)) continue;
    const v = Number(r.__share_value || 0);
    const p = Number(r.__share_projects || 0);
    val  += (v / targets.length); // split value equally
    proj += p;                     // projects counted fully per county
  }
  return { value: val, projects: proj };
}

/* ===== Programs donut (OTHER removed, add "Multi județe") ===== */
const MULTI_COLOR = '#16a34a'; // distinct green for Multi județe

function renderProgramsChart(){
  // Build series from programs, excluding OTHER if present
  const base = PROGRAMS
    .filter(p => p.key !== 'OTHER')
    .map(p=>{
      const pr = countyRow.programs?.[p.key] || {value:0, projects:0};
      const y = (metric==='value') ? (pr.value||0) : (pr.projects||0);
      return { name: p.label, y, color: PROGRAM_COLORS[p.key] };
    });

  // Append Multi județe slice
  const m = computeMultiTotalsForCounty(COUNTY_2);
  const mY = (metric==='value') ? m.value : m.projects;
  if (mY > 0){
    base.push({ name:'Multi județe', y: mY, color: MULTI_COLOR });
  }

  const seriesData = base.filter(p=>p.y > 0);

  if (!chartPrograms || typeof chartPrograms.update !== 'function') {
    chartPrograms = Highcharts.chart('chartPrograms', {
      chart: { type:'pie' },
      title: { text: `Distribuție pe programe – ${metric==='value' ? 'Valoare (RON)' : 'Proiecte'}` },
      tooltip: {
        pointFormatter:function(){
          return metric==='value'
            ? `<span style="color:${this.color}">●</span> ${this.name}: <b>${fmtMoney(this.y)}</b>`
            : `<span style="color:${this.color}">●</span> ${this.name}: <b>${fmtNum(this.y)}</b>`;
        },
        useHTML:true
      },
      plotOptions: {
        pie: {
          innerSize:'55%',
          dataLabels:{ enabled:true, formatter(){ return this.percentage ? Highcharts.numberFormat(this.percentage, 1) + '%' : null; } }
        }
      },
      series:[{ name:'Programe', data:seriesData }],
      credits:{enabled:false}, exporting:{enabled:true}
    });
  } else {
    chartPrograms.update({
      title:{ text:`Distribuție pe programe – ${metric==='value' ? 'Valoare (RON)' : 'Proiecte'}` },
      series:[{ data:seriesData }]
    }, true, true);
  }
}

/* ===== Right-side ranking (unchanged) ===== */
function renderRightPane(){
  if (rightChart && typeof rightChart.destroy === 'function') {
    rightChart.destroy();
  }
  const rows = allData.map(r => {
    const y = (metric==='value') ? (r.total?.value||0) : (r.total?.projects||0);
    return { code:(r.code||'').replace('RO-',''), name:r.name || r.code, y };
  }).sort((a,b)=> b.y - a.y);

  const rankIndex = rows.findIndex(p => p.code === COUNTY_2);
  const rankText  = (rankIndex >= 0) ? `Locul ${rankIndex+1} din ${rows.length}` : '';

  let top = rows.slice(0,10);
  if (!top.some(p => p.code === COUNTY_2)) {
    const cur = rows.find(p => p.code === COUNTY_2);
    if (cur) top[top.length - 1] = cur;
  }

  const seriesData = top.map(p => ({
    name: `${p.code} · ${p.name}`,
    y: p.y,
    color: p.code === COUNTY_2 ? '#0ea5e9' : '#cbd5e1',
    code: p.code,
    cursor: 'pointer'
  }));

  rightChart = Highcharts.chart('rightPane', {
    chart:{ type:'bar' },
    title:{ text:`Clasament județe – ${metric==='value' ? 'Valoare (RON)' : 'Proiecte'}` },
    xAxis:{ categories: seriesData.map(p=>p.name), title:{ text:null } },
    yAxis:{ title:{ text:null }, labels:{ formatter(){ return metric==='value' ? fmtMoney(this.value) : fmtNum(this.value); } } },
    tooltip:{ useHTML:true, formatter(){ return metric==='value' ? `<b>${fmtMoney(this.point.y)}</b>` : `<b>${fmtNum(this.point.y)}</b>`; } },
    plotOptions:{ series:{ dataLabels:{ enabled:true, formatter(){ return metric==='value' ? fmtMoney(this.y) : fmtNum(this.y); } } } },
    series:[{ name: metric==='value' ? 'Valoare' : 'Proiecte', data:seriesData }],
    legend:{ enabled:false }, credits:{ enabled:false }
  });

  appendRankShareBelow('rightPane', rankText);
}

function appendRankShareBelow(containerId, rankText){
  const el = document.getElementById(containerId);
  if (!el) return;
  const total = allData.reduce((s,r)=> s + (metric==='value' ? (r.total?.value||0) : (r.total?.projects||0)), 0);
  const cur   = allData.find(r => (r.code||'').replace('RO-','') === COUNTY_2);
  const part  = metric==='value' ? (cur?.total?.value||0) : (cur?.total?.projects||0);
  const pct   = total ? (part / total) * 100 : 0;
  const avg   = (allData.length && total) ? total / allData.length : 0;
  const diff  = part - avg;
  const diffTxt = metric==='value' ? fmtMoney(Math.abs(diff)) : fmtNum(Math.abs(diff));

  let info = el.nextElementSibling;
  if (!info || !info.classList || !info.classList.contains('muted')) {
    info = document.createElement('div');
    info.className = 'muted'; info.style.marginTop='8px';
    el.parentNode.appendChild(info);
  }
  info.textContent =
    `${rankText} • Pondere ${COUNTY_2} din total național (${metric==='value' ? 'Valoare' : 'Proiecte'}): ${pct.toFixed(1)}% • ` +
    `Diferență față de media județeană: ${diff >= 0 ? '+' : '−'}${diffTxt}`;
}

/* ===== Programs table (OTHER removed, add "Multi județe") ===== */
function renderProgramsTable(){
  const tbody = document.querySelector('#tblPrograms tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  const rows = PROGRAMS
    .filter(p => p.key !== 'OTHER')
    .map(p=>{
      const pr = countyRow.programs?.[p.key] || {value:0, projects:0};
      return { program:p.label, value:pr.value||0, projects:pr.projects||0 };
    });

  // Append Multi județe row
  const m = computeMultiTotalsForCounty(COUNTY_2);
  rows.push({ program:'Multi județe', value:m.value||0, projects:m.projects||0 });

  // Sort by current metric
  rows.sort((a,b)=> (metric==='value' ? b.value - a.value : b.projects - a.projects));

  for (const r of rows){
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${r.program}</td><td class="num">${fmtMoney(r.value)}</td><td class="num">${fmtNum(r.projects)}</td>`;
    tbody.appendChild(tr);
  }

  // Update the Multi-județe totals line underneath
  renderMultiTotalsNote();
}

function renderMultiTotalsNote(){
  const box = document.getElementById('multiTotals');
  if (!box) return;
  const { value, projects } = computeMultiTotalsForCounty(COUNTY_2);
 // box.textContent = `Multi județe în ${COUNTY_2}: Valoare (share) ${fmtMoney(value)} • Proiecte ${fmtNum(projects)}`;
}

/* Events */
document.addEventListener('judet-data-ready', () => {
  renderProgramsChart(); renderRightPane(); renderProgramsTable();
});
document.addEventListener('judet-metric-changed', () => {
  renderProgramsChart(); renderRightPane(); renderProgramsTable();
});
</script>
