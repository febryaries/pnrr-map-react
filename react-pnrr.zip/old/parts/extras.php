<div class="card">
  <h3 style="margin:0 0 8px 0;">Proiecte în acest județ</h3>
  <div class="muted">Rândurile corespunzătoare județului selectat (după împărțirea pe județe din conversie).</div>

  <div class="extras-controls">
    <label class="pill">Filtre</label>
    <select id="extraProgramFilter"></select>
    <input id="extraSearch" type="text" placeholder="Caută text în rânduri…" />
    <label style="display:inline-flex; align-items:center; gap:6px;">
      <input type="checkbox" id="extraShowAllCols" /> Arată toate coloanele
    </label>

    <div class="colpicker-wrap">
      <button class="btn secondary" id="extraPickColsBtn" type="button">Alege coloane…</button>
      <div class="colpicker" id="extraColPicker" aria-label="Selectează coloanele">
        <h4>Selectează coloanele de afișat</h4>
        <div class="colgrid" id="colGrid"></div>
        <div class="picker-actions">
          <button type="button" class="btn ghost" id="colSelectAllBtn">Selectează toate</button>
          <button type="button" class="btn ghost" id="colClearBtn">Golește selecția</button>
          <button type="button" class="btn ghost" id="colDefaultBtn">Revino la implicite</button>
          <button type="button" class="btn" id="colApplyBtn">Aplică & închide</button>
        </div>
      </div>
    </div>

    <button class="btn secondary" id="extraExportBtn" type="button">Exportă rezultate (CSV)</button>
    <span class="muted" id="extraCount" style="margin-left:auto"></span>
  </div>

  <div class="scroll-x">
    <table id="tblExtras">
      <thead><tr id="tblExtrasHead"></tr></thead>
      <tbody id="tblExtrasBody"></tbody>
    </table>
  </div>
  <div style="display:flex; gap:8px; justify-content:flex-end; align-items:center; margin-top:10px;">
    <button class="btn secondary" id="extraPrev" type="button">‹ Anterioare</button>
    <span class="muted" id="extraPageInfo">Pagina 1</span>
    <button class="btn secondary" id="extraNext" type="button">Următoare ›</button>
  </div>
</div>

<script>
// --- Extras (self-contained) ---
const DEFAULT_EXTRA_COLS_RAW = ['STATUS','PROGRAMUL','PRIORITATE','OBIECTIVE_SPECIFICE','FOND','COD_SMIS'];
const META_COLS = ['__program_key','__share_value','__share_projects','__counties_raw','__row_number','__program_label'];
const normKey = s => String(s).toUpperCase().replace(/[^A-Z0-9]/g,'');

let extrasFiltered = [];
let extrasShowAllCols = false;
let extrasPrimaryCols = [];
let extrasAllCols = [];
let extrasChosenCols = [];
let extrasPage = 1;
const EXTRAS_PAGE_SIZE = 10;

function labelOf(k){ return (COL_LABELS && COL_LABELS[k]) ? COL_LABELS[k] : niceHead(k); }

function computeExtrasColumns(){
  const set = new Set();
  for (const r of extrasRows) Object.keys(r).forEach(k => set.add(k));
  extrasAllCols = Array.from(set).filter(k => !META_COLS.includes(k));

  const counts = extrasAllCols.map(k=>{
    let n=0; for (const r of extrasRows){ const v=r[k]; if (v!==null && v!==undefined && String(v).trim()!=='') n++; }
    return {k,n};
  }).sort((a,b)=> b.n - a.n);

  extrasPrimaryCols = counts.slice(0,7).map(x=>x.k);

  const byNorm = {}; for (const k of extrasAllCols) byNorm[normKey(k)] = k;
  const resolved = [];
  for (const want of DEFAULT_EXTRA_COLS_RAW){ const hit = byNorm[normKey(want)]; if (hit) resolved.push(hit); }
  extrasChosenCols = resolved.length ? resolved : extrasPrimaryCols.slice();
}

function buildColumnPicker(){
  const grid = document.getElementById('colGrid');
  grid.innerHTML = '';
  const cols = extrasAllCols.slice();
  cols.sort((a,b)=>{
    const ai = extrasChosenCols.indexOf(a), bi = extrasChosenCols.indexOf(b);
    if (ai === -1 && bi === -1) return a.localeCompare(b);
    if (ai === -1) return 1;
    if (bi === -1) return -1;
    return ai - bi;
  });
  for (const k of cols){
    const id = 'col_'+k, lbl = labelOf(k), checked = extrasChosenCols.includes(k);
    grid.insertAdjacentHTML('beforeend',
      `<label for="${id}"><input type="checkbox" id="${id}" value="${k}" ${checked?'checked':''}> ${lbl}</label>`);
  }
}
function syncPickerChecks(){
  document.querySelectorAll('#colGrid input[type="checkbox"]').forEach(b=>{
    b.checked = extrasChosenCols.includes(b.value);
  });
}
function setAllPickerChecks(flag){
  const boxes = document.querySelectorAll('#colGrid input[type="checkbox"]');
  boxes.forEach(b => b.checked = !!flag);
  extrasChosenCols = flag ? Array.from(boxes).map(b=>b.value) : [];
}

function visibleExtraColumns(){
  if (extrasShowAllCols) return extrasAllCols;
  if (extrasChosenCols && extrasChosenCols.length) return extrasChosenCols;
  return extrasPrimaryCols;
}

function renderExtrasTable(){
  const head = document.getElementById('tblExtrasHead');
  const body = document.getElementById('tblExtrasBody');
  const info = document.getElementById('extraPageInfo');
  const count= document.getElementById('extraCount');

  const cols = visibleExtraColumns();
  head.innerHTML = ['<th class="nowrap">Program</th>','<th class="num nowrap">Valoare</th>']
    .concat(cols.map(k=>`<th>${labelOf(k)}</th>`)).join('');

  const total = extrasFiltered.length;
  const pages = Math.max(1, Math.ceil(total / EXTRAS_PAGE_SIZE));
  if (extrasPage > pages) extrasPage = pages;
  const start = (extrasPage-1)*EXTRAS_PAGE_SIZE;
  const end   = Math.min(total, start+EXTRAS_PAGE_SIZE);
  const slice = extrasFiltered.slice(start, end);

  body.innerHTML = '';
  for (const r of slice){
    const cells = [
      `<td>${r.__program_label || '—'}</td>`,
      `<td class="num">${fmtMoney(r.__share_value || 0)}</td>`
    ];

    for (const k of cols){
      const isSMIS = normKey(k) === 'CODSMIS';
      const rawVal = r[k];

      // COD SMIS: link to project.php
      if (isSMIS) {
        const smis = (rawVal != null && String(rawVal).trim() !== '') ? rawVal : r.COD_SMIS;
        const html = smis
          ? `<a href="project.php?smis=${encodeURIComponent(String(smis))}">${String(smis)}</a>`
          : '—';
        cells.push(`<td>${html}</td>`);
        continue;
      }

      // Other fields: keep your numeric-as-money formatting
      if (typeof rawVal === 'string' && rawVal.match(/^\s*[-]?\d{1,3}([.,]\d{3})*[.,]\d+\s*$/)){
        cells.push(`<td class="num">${fmtMoney(Number(String(rawVal).replace(/[^\d.,-]/g,'').replace(',','.')))}</td>`);
      } else {
        cells.push(`<td>${(rawVal===null||rawVal===undefined||String(rawVal).trim()==='') ? '—' : String(rawVal)}</td>`);
      }
    }

    const tr = document.createElement('tr');
    tr.innerHTML = cells.join('');
    body.appendChild(tr);
  }

  info.textContent  = `Pagina ${extrasPage} / ${pages}`;
  count.textContent = `${total} rânduri`;
}


function applyExtrasFiltersAndRender(){
  const programSel = document.getElementById('extraProgramFilter').value;
  const q = (document.getElementById('extraSearch').value || '').toLowerCase();

  extrasFiltered = extrasRows.filter(r=>{
    if (programSel !== '__ALL__' && r.__program_key !== programSel) return false;
    if (q){
      for (const [k,v] of Object.entries(r)){
        if (v === null || v === undefined) continue;
        if (String(v).toLowerCase().includes(q)) return true;
      }
      return false;
    }
    return true;
  });

  extrasPage = 1;
  renderExtrasTable();
}

function initExtrasUI(){
  const select = document.getElementById('extraProgramFilter');
  const keysInRows = Array.from(new Set(extrasRows.map(r => r.__program_key).filter(Boolean)));
  const opts = [{key:'__ALL__', label:'Toate programele'}].concat(keysInRows.map(k => ({key:k, label: PROGRAM_LABEL[k] || k})));
  select.innerHTML = opts.map(o=>`<option value="${o.key}">${o.label}</option>`).join('');
  select.value = '__ALL__';

  document.getElementById('extraShowAllCols').checked = extrasShowAllCols = false;

  select.addEventListener('change', ()=>{ extrasPage=1; applyExtrasFiltersAndRender(); });
  document.getElementById('extraSearch').addEventListener('input', ()=>{ extrasPage=1; applyExtrasFiltersAndRender(); });
  document.getElementById('extraShowAllCols').addEventListener('change', (e)=>{
    extrasShowAllCols = !!e.target.checked; extrasPage=1; renderExtrasTable();
  });
  document.getElementById('extraPrev').addEventListener('click', ()=>{ if (extrasPage>1){ extrasPage--; renderExtrasTable(); }});
  document.getElementById('extraNext').addEventListener('click', ()=>{
    const pages = Math.max(1, Math.ceil(extrasFiltered.length / EXTRAS_PAGE_SIZE));
    if (extrasPage < pages){ extrasPage++; renderExtrasTable(); }
  });
  document.getElementById('extraExportBtn').addEventListener('click', exportExtrasCSV);

  const picker = document.getElementById('extraColPicker');
  const btn = document.getElementById('extraPickColsBtn');
  btn.addEventListener('click', ()=>{ picker.classList.toggle('show'); syncPickerChecks(); });
  document.addEventListener('click', (e)=>{
    const wrap = document.querySelector('.colpicker-wrap');
    if (!wrap.contains(e.target)) picker.classList.remove('show');
  });
  document.getElementById('colSelectAllBtn').addEventListener('click', ()=> setAllPickerChecks(true));
  document.getElementById('colClearBtn').addEventListener('click', ()=> setAllPickerChecks(false));
  document.getElementById('colDefaultBtn').addEventListener('click', ()=>{
    const byNorm = {}; for (const k of extrasAllCols) byNorm[normKey(k)] = k;
    extrasChosenCols = [];
    for (const want of DEFAULT_EXTRA_COLS_RAW){ const hit = byNorm[normKey(want)]; if (hit) extrasChosenCols.push(hit); }
    syncPickerChecks();
  });
  document.getElementById('colApplyBtn').addEventListener('click', ()=>{
    const boxes = document.querySelectorAll('#colGrid input[type="checkbox"]');
    const chosen = []; boxes.forEach(b => { if (b.checked) chosen.push(b.value); });
    extrasChosenCols = chosen;
    extrasShowAllCols = false; document.getElementById('extraShowAllCols').checked = false;
    picker.classList.remove('show'); extrasPage=1; renderExtrasTable();
  });
}

function exportExtrasCSV(){
  const cols = visibleExtraColumns();
  const header = ['Program','Valoare_share','Proiecte_share','Judete_raw'].concat(cols.map(k => labelOf(k)));
  const lines = [header.join(',')];
  for (const r of extrasFiltered){
    const row = [
      (r.__program_label||'').replace(/"/g,'""'),
      String(r.__share_value||0),
      String(r.__share_projects||0),
      (r.__counties_raw||'').replace(/"/g,'""')
    ];
    for (const k of cols){
      const v = r[k]; const s = (v===null||v===undefined) ? '' : String(v);
      if (/[",\n]/.test(s)) row.push('"' + s.replace(/"/g,'""') + '"'); else row.push(s);
    }
    lines.push(row.join(','));
  }
  const blob = new Blob([lines.join('\n')], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = `extras_${COUNTY_2}.csv`;
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

// React to data ready (initialize once)
document.addEventListener('judet-data-ready', ()=>{
  // decorate with program label (if not already)
  extrasRows.forEach(r => { r.__program_label = PROGRAM_LABEL[r.__program_key] || r.__program_key || '—'; });
  computeExtrasColumns();
  buildColumnPicker();
  initExtrasUI();
  applyExtrasFiltersAndRender();
}, { once:true });
</script>
