import { useState, useEffect } from 'react'
import MapView from './components/MapView'
import CountyDetails from './components/CountyDetails'
import { mockData } from './data/mockData'
import { getRealPNRRData } from './data/realData'
import './App.css'

function App() {
  const [currentView, setCurrentView] = useState('map') // 'map' or 'county'
  const [selectedCounty, setSelectedCounty] = useState(null)
  const [viewMode, setViewMode] = useState('general') // 'general', 'multi', 'total', 'program'
  const [metric, setMetric] = useState('value') // 'value' or 'projects'
  const [activeProgram, setActiveProgram] = useState(null)
  const [data, setData] = useState(mockData)
  const [isLoadingRealData, setIsLoadingRealData] = useState(false)
  const [useRealData, setUseRealData] = useState(false)

  // Load real data on component mount
  useEffect(() => {
    const loadRealData = async () => {
      setIsLoadingRealData(true)
      try {
        const realData = await getRealPNRRData()
        if (realData && realData.length > 0) {
          setData(realData)
          setUseRealData(true)
          console.log('Successfully loaded real PNRR data')
        }
      } catch (error) {
        console.warn('Failed to load real data, using mock data:', error)
        setData(mockData)
        setUseRealData(false)
      } finally {
        setIsLoadingRealData(false)
      }
    }
    
    loadRealData()
  }, [])

  const handleCountyClick = (countyCode, countyName) => {
    const county = data.find(c => c.code === countyCode)
    if (county) {
      setSelectedCounty({ code: countyCode, name: countyName, data: county })
      setCurrentView('county')
    }
  }

  const handleBackToMap = () => {
    setCurrentView('map')
    setSelectedCounty(null)
  }

  return (
    <div className="app">
      {currentView === 'map' ? (
        <MapView 
          data={data}
          viewMode={viewMode}
          setViewMode={setViewMode}
          metric={metric}
          setMetric={setMetric}
          activeProgram={activeProgram}
          setActiveProgram={setActiveProgram}
          onCountyClick={handleCountyClick}
          isLoadingRealData={isLoadingRealData}
          useRealData={useRealData}
        />
      ) : (
        <CountyDetails 
          county={selectedCounty}
          data={data}
          onBackToMap={handleBackToMap}
          useRealData={useRealData}
        />
      )}
    </div>
  )
}

export default App
