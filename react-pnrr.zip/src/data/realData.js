// Real PNRR data fetcher and processor
import { COUNTY_MAP } from './mockData'

// Component and measure mappings based on Componente_și_investiții.xlsx
const COMPONENT_MAPPING = {
  'C1': { key: 'PDD', label: 'Dezvoltare Durabilă', program: 'PDD' },
  'C2': { key: 'PEO', label: 'Educație și Ocupare', program: 'PEO' },
  'C3': { key: 'PIDS', label: 'Incluziune și Demnitate Socială', program: 'PIDS' },
  'C4': { key: 'POCIDIF', label: 'Creștere Inteligentă', program: 'POCIDIF' },
  'C5': { key: 'PS', label: 'Sănătate', program: 'PS' },
  'C6': { key: 'PT', label: 'Transport', program: 'PT' },
  'C7': { key: 'POCIDIF', label: 'Creștere Inteligentă - Digitalizare', program: 'POCIDIF' },
  'C8': { key: 'POCIDIF', label: 'Creștere Inteligentă - Digitalizare', program: 'POCIDIF' },
  'C9': { key: 'PTJ', label: 'Tranziție Justă', program: 'PTJ' },
  'C10': { key: 'PR', label: 'Dezvoltare Regională', program: 'PR' },
  'C11': { key: 'PDD', label: 'Dezvoltare Durabilă - Mediu', program: 'PDD' },
  'C12': { key: 'PDD', label: 'Dezvoltare Durabilă - Energie', program: 'PDD' },
  'C13': { key: 'PT', label: 'Transport - Mobilitate', program: 'PT' },
  'C14': { key: 'PS', label: 'Sănătate - Reziliență', program: 'PS' },
  'C15': { key: 'PEO', label: 'Educație și Ocupare - Reforme', program: 'PEO' }
}

// Helper function to normalize county names
const normalizeCountyName = (countyName) => {
  if (!countyName) return null
  
  const normalized = countyName.toUpperCase().trim()
  
  // Handle special cases
  if (normalized.includes('BUCUREŞTI') || normalized.includes('BUCUREȘTI')) {
    return 'BI'
  }
  
  // Try to find county code by matching county names
  for (const [code, name] of Object.entries(COUNTY_MAP)) {
    if (normalized.includes(name.toUpperCase())) {
      return code
    }
  }
  
  // Handle common variations
  const countyMappings = {
    'ALBA': 'AB',
    'ARGEŞ': 'AG', 'ARGES': 'AG',
    'ARAD': 'AR',
    'BACĂU': 'BC', 'BACAU': 'BC',
    'BIHOR': 'BH',
    'BISTRIŢA': 'BN', 'BISTRITA': 'BN',
    'BRĂILA': 'BR', 'BRAILA': 'BR',
    'BOTOŞANI': 'BT', 'BOTOSANI': 'BT',
    'BRAŞOV': 'BV', 'BRASOV': 'BV',
    'BUZĂU': 'BZ', 'BUZAU': 'BZ',
    'CLUJ': 'CJ',
    'CĂLĂRAŞI': 'CL', 'CALARASI': 'CL',
    'CARAŞ': 'CS', 'CARAS': 'CS',
    'CONSTANŢA': 'CT', 'CONSTANTA': 'CT',
    'COVASNA': 'CV',
    'DÂMBOVIŢA': 'DB', 'DAMBOVITA': 'DB',
    'DOLJ': 'DJ',
    'GALAŢI': 'GL', 'GALATI': 'GL',
    'GIURGIU': 'GR',
    'GORJ': 'GJ',
    'HUNEDOARA': 'HD',
    'HARGHITA': 'HR',
    'ILFOV': 'IF',
    'IALOMIŢA': 'IL', 'IALOMITA': 'IL',
    'IAŞI': 'IS', 'IASI': 'IS',
    'MEHEDINŢI': 'MH', 'MEHEDINTI': 'MH',
    'MARAMUREŞ': 'MM', 'MARAMURES': 'MM',
    'MUREŞ': 'MS', 'MURES': 'MS',
    'NEAMŢ': 'NT', 'NEAMT': 'NT',
    'OLT': 'OT',
    'PRAHOVA': 'PH',
    'SIBIU': 'SB',
    'SĂLAJ': 'SJ', 'SALAJ': 'SJ',
    'SATU MARE': 'SM',
    'SUCEAVA': 'SV',
    'TULCEA': 'TL',
    'TIMIŞ': 'TM', 'TIMIS': 'TM',
    'TELEORMAN': 'TR',
    'VÂLCEA': 'VL', 'VALCEA': 'VL',
    'VRANCEA': 'VN',
    'VASLUI': 'VS'
  }
  
  for (const [key, code] of Object.entries(countyMappings)) {
    if (normalized.includes(key)) {
      return code
    }
  }
  
  return null
}

// Fetch data from PNRR API
export const fetchPNRRData = async (offset = 0, limit = 1000) => {
  try {
    const response = await fetch(`https://pnrr.fonduri-ue.ro/ords/pnrr/mfe/plati_pnrr?offset=${offset}&limit=${limit}`)
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    const data = await response.json()
    return data.items || []
  } catch (error) {
    console.warn('Error fetching PNRR data:', error)
    return []
  }
}

// Process raw PNRR data into our format
export const processPNRRData = (rawData) => {
  const countyData = {}
  const multiCountyProjects = []
  
  // Initialize county data structure
  Object.keys(COUNTY_MAP).forEach(code => {
    countyData[code] = {
      code: `RO-${code}`,
      name: COUNTY_MAP[code],
      total: { value: 0, projects: 0 },
      programs: {
        PDD: { value: 0, projects: 0 },
        PEO: { value: 0, projects: 0 },
        PIDS: { value: 0, projects: 0 },
        POCIDIF: { value: 0, projects: 0 },
        PS: { value: 0, projects: 0 },
        PT: { value: 0, projects: 0 },
        PTJ: { value: 0, projects: 0 },
        PR: { value: 0, projects: 0 }
      },
      extras: {
        rows: [],
        col_labels: {
          'NUME_BENEFICIAR': 'Nume Beneficiar',
          'VALOARE_PLATA_FE': 'Valoare Plată (RON)',
          'VALOARE_PLATA_FE_EURO': 'Valoare Plată (EUR)',
          'DATA_PLATA': 'Data Plată',
          'MASURA': 'Măsura',
          'SURSA_FINANTARE': 'Sursa Finanțare',
          'LOCALITATE_BENEFICIAR': 'Localitate Beneficiar',
          'SCOP_PROIECT': 'Scop Proiect'
        }
      }
    }
  })
  
  // Process each payment record
  rawData.forEach(item => {
    const countyCode = normalizeCountyName(item.judet_beneficiar)
    const componentMapping = COMPONENT_MAPPING[item.cod_componenta]
    
    if (!countyCode || !componentMapping) {
      // Handle as multi-county or unknown
      return
    }
    
    const county = countyData[countyCode]
    if (!county) return

    const programKey = componentMapping.program
    const value = parseFloat(item.valoare_plata_fe_euro) || 0
    
    // Add to county totals
    county.total.value += value
    county.total.projects += 1
    
    // Update county extras
    county.extras.col_labels.VALOARE_PLATA_EURO = 'Valoare Plată (EUR)'
    if (county.programs[programKey]) {
      county.programs[programKey].value += value
      county.programs[programKey].projects += 1
    }
    
    // Create project row for extras
    const projectRow = {
      NUME_BENEFICIAR: item.nume_beneficiar || '',
      VALOARE_PLATA_EURO: value,
      DATA_PLATA: item.data_plata || '',
      MASURA: item.masura || '',
      SURSA_FINANTARE: item.sursa_finantare || '',
      LOCALITATE_BENEFICIAR: item.localitate_beneficiar || '',
      COD_COMPONENTA: item.cod_componenta || '',
      COD_MASURA: item.cod_masura || '',
      CRI: item.cri || '',
      CUI_BENEFICIAR_FINAL: item.cui_beneficiar_final || '',
      COD_DIVIZIUNE_CAEN: item.cod_diviziune_caen || '',
      DESCRIERE_DIVIZIUNE_CAEN: item.descriere_diviziune_caen || '',
      SCOP_PROIECT: `${item.masura || ''} - ${item.localitate_beneficiar || ''}`.trim(),
      __program_key: programKey,
      __share_value: value,
      __share_projects: 1
    }
    
    county.extras.rows.push(projectRow)
  })
  
  // Convert to array format
  const result = Object.values(countyData)
  
  // Add multi-county data if exists
  if (multiCountyProjects.length > 0) {
    const multiData = {
      code: 'RO-MULTI',
      name: 'Multi Județe',
      total: { 
        value: multiCountyProjects.reduce((sum, item) => sum + (parseFloat(item.valoare_plata_fe) || 0), 0),
        projects: multiCountyProjects.length 
      },
      programs: {
        PDD: { value: 0, projects: 0 },
        PEO: { value: 0, projects: 0 },
        PIDS: { value: 0, projects: 0 },
        POCIDIF: { value: 0, projects: 0 },
        PS: { value: 0, projects: 0 },
        PT: { value: 0, projects: 0 },
        PTJ: { value: 0, projects: 0 },
        PR: { value: 0, projects: 0 }
      },
      extras: {
        rows: multiCountyProjects.map(item => ({
          NUME_BENEFICIAR: item.nume_beneficiar || '',
          VALOARE_PLATA_EURO: parseFloat(item.valoare_plata_fe_euro) || 0,
          DATA_PLATA: item.data_plata || '',
          MASURA: item.masura || '',
          SURSA_FINANTARE: item.sursa_finantare || '',
          LOCALITATE_BENEFICIAR: item.localitate_beneficiar || '',
          SCOP_PROIECT: `${item.masura || ''} - ${item.localitate_beneficiar || ''}`.trim(),
          __program_key: COMPONENT_MAPPING[item.cod_componenta]?.program || 'PR',
          __share_value: parseFloat(item.valoare_plata_fe) || 0,
          __share_projects: 1
        })),
        multi_agg_by_county: {}
      }
    }
    
    result.push(multiData)
  }
  
  return result
}

// Fetch all data with pagination
export const fetchAllPNRRData = async () => {
  const allData = []
  let offset = 0
  const limit = 5000 // API limit per request
  let hasMoreData = true
  
  console.log('Starting to fetch all PNRR data...')
  
  while (hasMoreData) {
    try {
      console.log(`Fetching batch: offset=${offset}, limit=${limit}`)
      const batchData = await fetchPNRRData(offset, limit)
      
      if (batchData.length === 0) {
        // No more data available
        hasMoreData = false
        console.log('No more data available')
      } else {
        allData.push(...batchData)
        console.log(`Fetched ${batchData.length} records. Total so far: ${allData.length}`)
        
        // If we got less than the limit, we've reached the end
        if (batchData.length < limit) {
          hasMoreData = false
          console.log('Reached end of data (partial batch)')
        } else {
          // Move to next batch
          offset += limit
          
          // Add a small delay to be respectful to the API
          await new Promise(resolve => setTimeout(resolve, 100))
        }
      }
    } catch (error) {
      console.error(`Error fetching batch at offset ${offset}:`, error)
      // Continue with next batch or stop depending on error type
      if (error.message.includes('404') || error.message.includes('400')) {
        // Likely reached the end or invalid offset
        hasMoreData = false
      } else {
        // Network error, try to continue
        offset += limit
        if (offset > 50000) { // Safety limit to prevent infinite loops
          console.warn('Reached safety limit, stopping fetch')
          hasMoreData = false
        }
      }
    }
  }
  
  console.log(`Finished fetching. Total records: ${allData.length}`)
  return allData
}

// Main function to get processed PNRR data
export const getRealPNRRData = async () => {
  try {
    console.log('Fetching complete PNRR database...')
    const rawData = await fetchAllPNRRData()
    console.log(`Successfully fetched ${rawData.length} payment records from complete database`)
    
    if (rawData.length === 0) {
      console.warn('No data received from API')
      throw new Error('No data available')
    }
    
    const processedData = processPNRRData(rawData)
    console.log(`Processed data for ${processedData.length} entities`)
    
    return processedData
  } catch (error) {
    console.error('Error getting real PNRR data:', error)
    // Return empty structure if API fails
    return Object.keys(COUNTY_MAP).map(code => ({
      code: `RO-${code}`,
      name: COUNTY_MAP[code],
      total: { value: 0, projects: 0 },
      programs: {
        PDD: { value: 0, projects: 0 },
        PEO: { value: 0, projects: 0 },
        PIDS: { value: 0, projects: 0 },
        POCIDIF: { value: 0, projects: 0 },
        PS: { value: 0, projects: 0 },
        PT: { value: 0, projects: 0 },
        PTJ: { value: 0, projects: 0 },
        PR: { value: 0, projects: 0 }
      },
      extras: { rows: [], col_labels: {} }
    }))
  }
}

// Export component mapping for use in other files
export { COMPONENT_MAPPING }
