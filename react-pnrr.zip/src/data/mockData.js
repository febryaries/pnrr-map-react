// Mock data structure based on the original project
export const PROGRAMS = [
  { key: 'PDD', label: 'Dezvoltare Durabilă' },
  { key: 'PEO', label: 'Educație și Ocupare' },
  { key: 'PIDS', label: 'Incluziune și Demnitate Socială' },
  { key: 'POCIDIF', label: 'Creștere Inteligentă' },
  { key: 'PS', label: 'Sănătate' },
  { key: 'PT', label: 'Transport' },
  { key: 'PTJ', label: 'Tranziție Justă' },
  { key: 'PR', label: 'Dezvoltare Regională' }
];

export const PROGRAM_COLORS = {
  PDD: '#0ea5e9',
  PEO: '#6366f1', 
  PIDS: '#ef4444',
  POCIDIF: '#a855f7',
  PS: '#f59e0b',
  PT: '#06b6d4',
  PTJ: '#f97316',
  PR: '#334155',
  OTHER: '#94a3b8'
};

export const COUNTY_MAP = {
  'AB': 'Alba', 'AG': 'Argeș', 'AR': 'Arad', 'BC': 'Bacău', 'BH': 'Bihor', 'BN': 'Bistrița-Năsăud',
  'BR': 'Brăila', 'BT': 'Botoșani', 'BV': 'Brașov', 'BZ': 'Buzău', 'CJ': 'Cluj', 'CL': 'Călărași',
  'CS': 'Caraș-Severin', 'CT': 'Constanța', 'CV': 'Covasna', 'DB': 'Dâmbovița', 'DJ': 'Dolj', 'GJ': 'Gorj',
  'GL': 'Galați', 'GR': 'Giurgiu', 'HD': 'Hunedoara', 'HR': 'Harghita', 'IF': 'Ilfov', 'IL': 'Ialomița',
  'IS': 'Iași', 'MH': 'Mehedinți', 'MM': 'Maramureș', 'MS': 'Mureș', 'NT': 'Neamț', 'OT': 'Olt',
  'PH': 'Prahova', 'SB': 'Sibiu', 'SJ': 'Sălaj', 'SM': 'Satu Mare', 'SV': 'Suceava', 'TL': 'Tulcea',
  'TM': 'Timiș', 'TR': 'Teleorman', 'VL': 'Vâlcea', 'VN': 'Vrancea', 'VS': 'Vaslui', 'BI': 'București'
};

// Generate mock county data
export const mockCountyData = Object.entries(COUNTY_MAP).map(([code, name]) => {
  const baseValue = Math.random() * 5000000000; // Random base value up to 5 billion RON
  const baseProjects = Math.floor(Math.random() * 200) + 10; // 10-210 projects
  
  // Generate program distribution
  const programs = {};
  let remainingValue = baseValue;
  let remainingProjects = baseProjects;
  
  PROGRAMS.forEach((program, index) => {
    const isLast = index === PROGRAMS.length - 1;
    const valueShare = isLast ? remainingValue : Math.random() * remainingValue * 0.4;
    const projectShare = isLast ? remainingProjects : Math.floor(Math.random() * remainingProjects * 0.4);
    
    programs[program.key] = {
      value: Math.max(0, valueShare),
      projects: Math.max(0, projectShare)
    };
    
    remainingValue -= valueShare;
    remainingProjects -= projectShare;
  });

  return {
    code: `RO-${code}`,
    name,
    total: {
      value: baseValue,
      projects: baseProjects
    },
    programs,
    extras: {
      rows: generateMockProjects(code, baseProjects),
      col_labels: {
        'TITLU_PROIECT': 'Titlul Proiectului',
        'NUME_BENEFICIAR': 'Nume Beneficiar',
        'SURSA_FINANTARE': 'Sursa Finanțare',
        'VALOARE_PLATA_FE': 'Valoare Plată (RON)',
        'VALOARE_PLATA_FE_EURO': 'Valoare Plată (EUR)',
        'PROGRES_FIZIC': 'Progres Fizic (%)',
        'COD_COMPONENTA': 'Cod Componentă',
        'COD_MASURA': 'Cod Măsură'
      }
    }
  };
});

function generateMockProjects(countyCode, count) {
  const projects = [];
  const beneficiaryTypes = ['Primăria', 'Consiliul Județean', 'SC', 'SRL', 'Universitatea', 'Spitalul'];
  const fundingSources = ['FEDR', 'FSE+', 'FC', 'FEPAM'];
  
  // Sample localities per county for SCOP_PROIECT generation
  const sampleLocalities = {
    'AB': ['Alba Iulia', 'Sebeș', 'Aiud', 'Blaj', 'Cugir'],
    'AG': ['Pitești', 'Curtea de Argeș', 'Câmpulung', 'Mioveni'],
    'AR': ['Arad', 'Ineu', 'Lipova', 'Pecica'],
    'BC': ['Bacău', 'Onești', 'Moinești', 'Comănești'],
    'BH': ['Oradea', 'Salonta', 'Marghita', 'Beiuș'],
    'BI': ['București', 'Sectorul 1', 'Sectorul 2', 'Sectorul 3'],
    'BN': ['Bistrița', 'Beclean', 'Năsăud'],
    'BR': ['Brăila', 'Ianca', 'Însurăței'],
    'BT': ['Botoșani', 'Dorohoi', 'Săveni'],
    'BV': ['Brașov', 'Făgăraș', 'Săcele', 'Codlea'],
    'BZ': ['Buzău', 'Râmnicu Sărat', 'Nehoiu'],
    'CJ': ['Cluj-Napoca', 'Turda', 'Dej', 'Câmpia Turzii'],
    'CL': ['Călărași', 'Oltenița', 'Fundulea'],
    'CS': ['Reșița', 'Caransebeș', 'Lugoj'],
    'CT': ['Constanța', 'Mangalia', 'Medgidia', 'Năvodari'],
    'CV': ['Sfântu Gheorghe', 'Târgu Secuiesc', 'Covasna'],
    'DB': ['Târgoviște', 'Moreni', 'Pucioasa'],
    'DJ': ['Craiova', 'Băilești', 'Calafat'],
    'GL': ['Galați', 'Tecuci', 'Târgu Bujor'],
    'GR': ['Giurgiu', 'Bolintin-Vale', 'Mihăilești'],
    'GJ': ['Târgu Jiu', 'Motru', 'Rovinari'],
    'HD': ['Deva', 'Hunedoara', 'Petroșani', 'Vulcan'],
    'HR': ['Miercurea Ciuc', 'Odorheiu Secuiesc', 'Gheorgheni'],
    'IF': ['Buftea', 'Otopeni', 'Voluntari', 'Pantelimon'],
    'IL': ['Slobozia', 'Fetești', 'Țăndărei'],
    'IS': ['Iași', 'Pașcani', 'Târgu Frumos'],
    'MH': ['Drobeta-Turnu Severin', 'Orșova', 'Vânju Mare'],
    'MM': ['Baia Mare', 'Sighetu Marmației', 'Borșa'],
    'MS': ['Târgu Mureș', 'Reghin', 'Sighișoara'],
    'NT': ['Piatra Neamț', 'Roman', 'Târgu Neamț'],
    'OT': ['Slatina', 'Caracal', 'Balș'],
    'PH': ['Ploiești', 'Câmpina', 'Băicoi'],
    'SB': ['Sibiu', 'Mediaș', 'Cisnădie'],
    'SJ': ['Zalău', 'Șimleu Silvaniei', 'Jibou'],
    'SM': ['Satu Mare', 'Carei', 'Negrești-Oaș'],
    'SV': ['Suceava', 'Fălticeni', 'Rădăuți'],
    'TL': ['Tulcea', 'Babadag', 'Măcin'],
    'TM': ['Timișoara', 'Lugoj', 'Sânnicolau Mare'],
    'TR': ['Alexandria', 'Rosiori de Vede', 'Turnu Măgurele'],
    'VL': ['Râmnicu Vâlcea', 'Drăgășani', 'Băbeni'],
    'VN': ['Focșani', 'Adjud', 'Mărășești'],
    'VS': ['Vaslui', 'Bârlad', 'Huși']
  };
  
  const localities = sampleLocalities[countyCode] || [COUNTY_MAP[countyCode]];
  
  for (let i = 0; i < Math.min(count, 50); i++) { // Limit to 50 projects for demo
    const program = PROGRAMS[Math.floor(Math.random() * PROGRAMS.length)];
    const value = Math.random() * 10000000; // Up to 10M RON per project
    
    // Generate SCOP_PROIECT with locality mentions
    const randomLocality = localities[Math.floor(Math.random() * localities.length)];
    const scopeTemplates = [
      `Modernizarea infrastructurii în ${randomLocality}`,
      `Dezvoltarea serviciilor publice în municipiul ${randomLocality}`,
      `Proiect de reabilitare urbană în orașul ${randomLocality}`,
      `Îmbunătățirea calității vieții în comuna ${randomLocality}`,
      `Investiții în infrastructura din ${randomLocality}`,
      `Dezvoltare durabilă în ${randomLocality} și împrejurimi`
    ];
    
    projects.push({
      TITLU_PROIECT: `Proiect ${program.label} ${i + 1} - ${COUNTY_MAP[countyCode]}`,
      NUME_BENEFICIAR: `${beneficiaryTypes[Math.floor(Math.random() * beneficiaryTypes.length)]} ${COUNTY_MAP[countyCode]} ${i + 1}`,
      SURSA_FINANTARE: fundingSources[Math.floor(Math.random() * fundingSources.length)],
      VALOARE_PLATA_FE: value,
      VALOARE_PLATA_FE_EURO: value / 4.95, // Approximate EUR conversion
      PROGRES_FIZIC: Math.floor(Math.random() * 100),
      COD_COMPONENTA: `C${Math.floor(Math.random() * 15) + 1}`,
      COD_MASURA: `M${Math.floor(Math.random() * 50) + 1}`,
      SCOP_PROIECT: scopeTemplates[Math.floor(Math.random() * scopeTemplates.length)],
      __program_key: program.key,
      __share_value: value,
      __share_projects: 1
    });
  }
  
  return projects;
}

// Mock multi-county data
export const mockMultiCountyData = {
  code: 'RO-MULTI',
  name: 'Multi Județe',
  total: { value: 2000000000, projects: 45 },
  programs: {
    PT: { value: 1500000000, projects: 25 },
    PDD: { value: 300000000, projects: 10 },
    POCIDIF: { value: 200000000, projects: 10 }
  },
  extras: {
    rows: [],
    multi_agg_by_county: generateMultiCountyAggregation()
  }
};

function generateMultiCountyAggregation() {
  const agg = {};
  Object.keys(COUNTY_MAP).forEach(code => {
    agg[code] = {
      value: Math.random() * 100000000, // Random multi-county value per county
      projects: Math.floor(Math.random() * 5) + 1 // 1-5 multi-county projects
    };
  });
  return agg;
}

// Combine all data
export const mockData = [...mockCountyData, mockMultiCountyData];

// Utility functions
export const fmtMoney = (n) => {
  const abs = Math.abs(n || 0);
  // For large amounts, use short format
  if (abs >= 1e6) {
    return fmtMoneyShort(n);
  }
  // For smaller amounts, use full currency format
  return new Intl.NumberFormat('ro-RO', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(n || 0);
};

export const fmtNum = (n) => new Intl.NumberFormat('ro-RO').format(n || 0);

export const fmtMoneyShort = (n) => {
  const abs = Math.abs(n || 0);
  if (abs >= 1e9) {
    const billions = n / 1e9;
    return `${billions.toFixed(2)} miliarde €`;
  }
  if (abs >= 1e6) {
    const millions = n / 1e6;
    return `${millions.toFixed(2)} milioane €`;
  }
  if (abs >= 1e3) {
    const thousands = n / 1e3;
    return `${thousands.toFixed(2)} mii €`;
  }
  return `${(n || 0).toFixed(2)} €`;
};

// Alternative short format for very compact display
export const fmtMoneyCompact = (n) => {
  const abs = Math.abs(n || 0);
  if (abs >= 1e9) return `${(n / 1e9).toFixed(2)} mld €`;
  if (abs >= 1e6) return `${(n / 1e6).toFixed(2)} mil €`;
  if (abs >= 1e3) return `${(n / 1e3).toFixed(2)} k €`;
  return `${(n || 0).toFixed(2)} €`;
};
