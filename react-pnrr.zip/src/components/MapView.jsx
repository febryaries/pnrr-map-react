import { useState, useEffect, useMemo } from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'
import HighchartsMap from 'highcharts/modules/map'
import { PROGRAMS, PROGRAM_COLORS, fmtMoney, fmtNum, fmtMoneyShort } from '../data/mockData'
import { COMPONENT_MAPPING } from '../data/realData'

// Initialize Highcharts Map module
HighchartsMap(Highcharts)

const MapView = ({
    data,
    viewMode,
    setViewMode,
    metric,
    setMetric,
    activeProgram,
    setActiveProgram,
    onCountyClick,
    isLoadingRealData,
    useRealData
}) => {
    const [showAllRanking, setShowAllRanking] = useState(false)
    const [mapData, setMapData] = useState(null)
    const [totalIndicators, setTotalIndicators] = useState(null)
    const [loadingIndicators, setLoadingIndicators] = useState(false)
    const [topBeneficiaries, setTopBeneficiaries] = useState(null)
    const [loadingBeneficiaries, setLoadingBeneficiaries] = useState(false)

    // Load Romania map data (topology + geojson)
    useEffect(() => {
        const loadMapData = async () => {
            try {
                const response = await fetch('https://code.highcharts.com/mapdata/countries/ro/ro-all.topo.json')
                if (!response.ok) {
                    console.warn('Could not load Romania map data:', response.statusText)
                    return
                }
                const topology = await response.json()
                setMapData({ topology })
            } catch (error) {
                console.warn('Error loading Romania map data:', error)
            }
        }
        loadMapData()
    }, [])

    // Fetch total indicators on component mount
    useEffect(() => {
        const fetchTotalIndicators = async () => {
            setLoadingIndicators(true)
            try {
                const response = await fetch('https://pnrr.fonduri-ue.ro/ords/pnrr/mfe/indicatori_total')
                if (response.ok) {
                    const data = await response.json()
                    if (data.items && data.items.length > 0) {
                        setTotalIndicators(data.items[0])
                    }
                }
            } catch (error) {
                console.error('Error fetching total indicators:', error)
            } finally {
                setLoadingIndicators(false)
            }
        }

        fetchTotalIndicators()
    }, [])

    // Fetch top beneficiaries on component mount
    useEffect(() => {
        const fetchTopBeneficiaries = async () => {
            setLoadingBeneficiaries(true)
            try {
                const response = await fetch('https://pnrr.fonduri-ue.ro/ords/pnrr/mfe/top_beneficiari')
                if (response.ok) {
                    const data = await response.json()
                    setTopBeneficiaries(data)
                }
            } catch (error) {
                console.error('Error fetching top beneficiaries:', error)
            } finally {
                setLoadingBeneficiaries(false)
            }
        }

        fetchTopBeneficiaries()
    }, [])

    // Process data based on current view mode and metric
    const processedData = useMemo(() => {
        const baseCounties = data.filter(d => d.code !== 'RO-MULTI')
        const multiData = data.find(d => d.code === 'RO-MULTI')
        let result = []

        if (viewMode === 'general') {
            result = baseCounties.map(county => ({
                'hc-key': county.code.toLowerCase().replace('ro-', 'ro-'),
                code: county.code,
                name: county.name,
                value: metric === 'value' ? county.total.value : county.total.projects,
                money: county.total.value,
                projects: county.total.projects
            }))
        } else if (viewMode === 'program' && activeProgram) {
            result = baseCounties.map(county => {
                const programData = county.programs[activeProgram] || { value: 0, projects: 0 }
                return {
                    'hc-key': county.code.toLowerCase().replace('ro-', 'ro-'),
                    code: county.code,
                    name: county.name,
                    value: metric === 'value' ? programData.value : programData.projects,
                    money: programData.value,
                    projects: programData.projects
                }
            })
        } else if (viewMode === 'multi') {
            const multiAgg = multiData?.extras?.multi_agg_by_county || {}
            result = baseCounties.map(county => {
                const countyCode = county.code.replace('RO-', '')
                const multiShare = multiAgg[countyCode] || { value: 0, projects: 0 }
                return {
                    'hc-key': county.code.toLowerCase().replace('ro-', 'ro-'),
                    code: county.code,
                    name: county.name,
                    value: metric === 'value' ? multiShare.value : multiShare.projects,
                    money: multiShare.value,
                    projects: multiShare.projects
                }
            })
        } else if (viewMode === 'total') {
            const multiAgg = multiData?.extras?.multi_agg_by_county || {}
            result = baseCounties.map(county => {
                const countyCode = county.code.replace('RO-', '')
                const multiShare = multiAgg[countyCode] || { value: 0, projects: 0 }
                const totalValue = county.total.value + multiShare.value
                const totalProjects = county.total.projects + multiShare.projects
                return {
                    'hc-key': county.code.toLowerCase().replace('ro-', 'ro-'),
                    code: county.code,
                    name: county.name,
                    value: metric === 'value' ? totalValue : totalProjects,
                    money: totalValue,
                    projects: totalProjects
                }
            })
        }

        return result.sort((a, b) => (b.value || 0) - (a.value || 0))
    }, [data, viewMode, metric, activeProgram])

    // Map chart configuration
    const mapOptions = useMemo(() => {
        if (!mapData) return null

        const seriesData = processedData
        const values = seriesData.map(d => d.value || 0).filter(v => v > 0)
        
        // Use percentile-based scaling to handle outliers better
        const sortedValues = [...values].sort((a, b) => a - b)
        const p95Index = Math.floor(sortedValues.length * 0.95) // 95th percentile
        const maxValue = sortedValues.length > 0 ? sortedValues[p95Index] || sortedValues[sortedValues.length - 1] : 1
        const minValue = sortedValues.length > 0 ? sortedValues[0] : 0
        
        console.log(`Map scale: min=${minValue.toLocaleString()}, max=${maxValue.toLocaleString()}, actual max=${sortedValues[sortedValues.length - 1]?.toLocaleString()}`)

        return {
            chart: {
                map: mapData.topology,
                height: 500
            },
            title: {
                text: getMapTitle(),
                align: 'left',
                margin: 0,
                style: {
                    fontSize: '22px',
                    fontWeight: 700,
                    color: '#0f172a'
                }
            },
            subtitle: {
                text: '',
                align: 'left',
                style: {
                    color: '#64748b',
                    fontSize: '13px'
                },
                y: 28
            },
            mapNavigation: {
                enabled: true,
                buttonOptions: {
                    verticalAlign: 'bottom'
                }
            },
            colorAxis: {
                min: 0,
                max: maxValue,
                stops: [
                    [0, '#f0f9ff'],      // Very light blue for zero values
                    [0.05, '#e0f2fe'],   // Light blue for very low values
                    [0.15, '#bae6fd'],   // Light medium blue
                    [0.3, '#7dd3fc'],    // Medium light blue
                    [0.5, '#38bdf8'],    // Medium blue
                    [0.7, '#0ea5e9'],    // Strong blue
                    [0.85, '#0284c7'],   // Dark blue
                    [1, '#0c4a6e']       // Darkest blue for highest values
                ],
                labels: {
                    formatter: function () {
                        return metric === 'value' ? fmtMoneyShort(this.value) : fmtNum(this.value)
                    }
                }
            },
            tooltip: {
                useHTML: true,
                outside: true,
                followPointer: true,
                stickOnContact: true,
                hideDelay: 2000,
                formatter: function () {
                    const point = this.point
                    const displayValue = metric === 'value' ? fmtMoney(point.money) : fmtNum(point.projects)
                    const otherValue = metric === 'value' ? `Proiecte: ${fmtNum(point.projects)}` : `Valoare: ${fmtMoney(point.money)}`

                    return `
          <strong>${point.name}</strong><br/>
          ${metric === 'value' ? 'Valoare' : 'Proiecte'}: <strong>${displayValue}</strong><br/>
          ${otherValue}<br/>
          <div style="margin-top: 8px;">
            <button onclick="window.handleCountyClick('${point.code}', '${point.name}')" 
                    style="padding: 6px 10px; background: #0ea5e9; color: #fff; border: 0; border-radius: 8px; font-weight: 600; cursor: pointer;">
              Click pe județ pentru detalii
            </button>
          </div>
        `
                }
            },
            series: [{
                data: seriesData,
                name: 'Counties',
                states: {
                    hover: {
                        color: '#a4edba'
                    }
                },
                borderColor: '#ffffff',
                borderWidth: 0.6,
                dataLabels: {
                    enabled: false
                },
                point: {
                    events: {
                        click: function () {
                            onCountyClick(this.code, this.name)
                        }
                    }
                }
            }],
            credits: {
                enabled: false
            }
        }
    }, [mapData, processedData, metric, onCountyClick])

    // Expose county click handler globally for tooltip
    useEffect(() => {
        window.handleCountyClick = onCountyClick
        return () => {
            delete window.handleCountyClick
        }
    }, [onCountyClick])

    function getMapTitle() {
        if (viewMode === 'general') {
            return `General (toate programele) - ${metric === 'value' ? 'Valoare (EUR)' : 'Număr proiecte'}`
        } else if (viewMode === 'program') {
            return `Program ${activeProgram} - ${metric === 'value' ? 'Valoare (EUR)' : 'Număr proiecte'}`
        } else if (viewMode === 'total') {
            return `Total (General + Multi județe) - ${metric === 'value' ? 'Valoare (EUR)' : 'Număr proiecte'}`
        } else {
            return `Multi județe - ${metric === 'value' ? 'Valoare (RON, împărțită egal între județe)' : 'Număr proiecte (plin în fiecare județ)'}`
        }
    }

    // Component totals for pie chart
    const componentTotals = useMemo(() => {
        const baseCounties = data.filter(d => d.code !== 'RO-MULTI')
        const totals = {}

        // Initialize component totals
        Object.entries(COMPONENT_MAPPING).forEach(([componentKey, componentInfo]) => {
            totals[componentKey] = {
                value: 0,
                projects: 0,
                label: componentInfo.label
            }
        })

        // Aggregate data from all counties
        baseCounties.forEach(county => {
            if (county.extras && county.extras.rows) {
                county.extras.rows.forEach(project => {
                    const componentKey = project.COD_COMPONENTA
                    if (totals[componentKey]) {
                        const projectValue = project.VALOARE_PLATA_EURO || project.VALOARE_PLATA_FE_EURO || 0
                        totals[componentKey].value += projectValue
                        totals[componentKey].projects += 1
                    }
                })
            }
        })

        // Add multi-county data if exists
        const multiData = data.find(d => d.code === 'RO-MULTI')
        if (multiData && multiData.extras && multiData.extras.rows) {
            multiData.extras.rows.forEach(project => {
                const componentKey = project.COD_COMPONENTA
                if (totals[componentKey]) {
                    const projectValue = project.VALOARE_PLATA_EURO || project.VALOARE_PLATA_FE_EURO || 0
                    totals[componentKey].value += projectValue
                    totals[componentKey].projects += 1
                }
            })
        }

        // Generate colors for components (using program colors as base)
        const componentColors = {}
        Object.entries(COMPONENT_MAPPING).forEach(([componentKey, componentInfo]) => {
            componentColors[componentKey] = PROGRAM_COLORS[componentInfo.program] || '#94a3b8'
        })

        return Object.entries(totals)
            .filter(([_, data]) => (metric === 'value' ? data.value : data.projects) > 0)
            .map(([key, data]) => ({
                name: data.label,
                y: metric === 'value' ? data.value : data.projects,
                color: componentColors[key],
                key
            }))
            .sort((a, b) => b.y - a.y)
    }, [data, metric])

    // Pie chart configuration
    const pieOptions = {
        chart: {
            type: 'pie'
        },
        title: {
            text: `Distribuție pe componente – ${metric === 'value' ? 'Valoare (EUR)' : 'Proiecte'}`
        },
        tooltip: {
            useHTML: true,
            pointFormatter: function () {
                const val = metric === 'value' ? fmtMoney(this.y) : fmtNum(this.y)
                return `<span style="color:${this.color}">●</span> ${this.name}: <b>${val}</b>`
            }
        },
        plotOptions: {
            pie: {
                innerSize: '55%',
                dataLabels: {
                    enabled: true,
                    formatter: function () {
                        return this.percentage ? Highcharts.numberFormat(this.percentage, 1) + '%' : null
                    }
                },
                cursor: 'pointer',
                point: {
                    events: {
                        click: function () {
                            setViewMode('program')
                            setActiveProgram(this.options.key)
                        }
                    }
                }
            }
        },
        series: [{
            name: 'Componente',
            data: componentTotals
        }],
        credits: {
            enabled: false
        }
    }

    const rankingData = processedData.slice(0, showAllRanking ? processedData.length : 10)
    const maxValue = processedData.length > 0 ? processedData[0].value : 1

    const pageTitle = 'Tablou de bord PNRR – Harta județelor'

    // Show loading state while map data or real data is loading
    if (!mapData || isLoadingRealData) {
        return (
            <main className="page page--map">
                <header className="page-header">
                    <h1>{pageTitle}</h1>
                </header>
                <div className="map-container map-container--loading">
                    <div className="loading-indicator">
                        <div className="loading-spinner"></div>
                        <div className="loading-text">
                            {isLoadingRealData ? (
                                <>
                                    <strong>Se descarcă datele PNRR...</strong><br/>
                                    <span className="loading-subtext">Acest proces poate dura câteva secunde</span>
                                </>
                            ) : (
                                <>
                                    <strong>Se încarcă harta României...</strong><br/>
                                    <span className="loading-subtext">Se descarcă geometria județelor</span>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </main>
        )
    }

    return (
        <main className="page page--map">
            <header className="page-header">
                <h1>{pageTitle}</h1>
            </header>

            <div className="controls controls--map">
                {/* General segment */}
                <div className="segment">
                    <button
                        className={viewMode === 'general' && metric === 'value' ? 'active' : ''}
                        onClick={() => { setViewMode('general'); setMetric('value'); setActiveProgram(null) }}
                    >
                        General · Valoare
                    </button>
                    <button
                        className={viewMode === 'general' && metric === 'projects' ? 'active' : ''}
                        onClick={() => { setViewMode('general'); setMetric('projects'); setActiveProgram(null) }}
                    >
                        General · Proiecte
                    </button>
                </div>

                {/* Multi segment */}
                {/* <div className="segment">
                    <button
                        className={viewMode === 'multi' && metric === 'value' ? 'active' : ''}
                        onClick={() => { setViewMode('multi'); setMetric('value'); setActiveProgram(null) }}
                    >
                        Multi județe · Valoare
                    </button>
                    <button
                        className={viewMode === 'multi' && metric === 'projects' ? 'active' : ''}
                        onClick={() => { setViewMode('multi'); setMetric('projects'); setActiveProgram(null) }}
                    >
                        Multi județe · Proiecte
                    </button>
                </div> */}

                {/* Total segment */}
                <div className="segment">
                    <button
                        className={viewMode === 'total' && metric === 'value' ? 'active' : ''}
                        onClick={() => { setViewMode('total'); setMetric('value'); setActiveProgram(null) }}
                    >
                        Total · Valoare
                    </button>
                    <button
                        className={viewMode === 'total' && metric === 'projects' ? 'active' : ''}
                        onClick={() => { setViewMode('total'); setMetric('projects'); setActiveProgram(null) }}
                    >
                        Total · Proiecte
                    </button>
                </div>

                {/* Programs */}
                <div className="programs">
                    {PROGRAMS.map(program => (
                        <button
                            key={program.key}
                            className={viewMode === 'program' && activeProgram === program.key ? 'active' : ''}
                            onClick={(e) => {
                                setViewMode('program')
                                setActiveProgram(program.key)
                                setMetric(e.shiftKey ? 'projects' : 'value')
                            }}
                            title={`Click: ${program.label} · Valoare | Shift+Click: ${program.label} · Proiecte`}
                        >
                            {program.label}
                            {viewMode === 'program' && activeProgram === program.key && (metric === 'projects' ? ' •P' : ' •V')}
                        </button>
                    ))}
                </div>
            </div>

            {/* Total Indicators Cards */}
            <section className="indicators-section">
                {loadingIndicators ? (
                    <div className="indicators-loading">
                        <div className="loading-spinner-small"></div>
                        <span>Se încarcă indicatorii totali...</span>
                    </div>
                ) : totalIndicators ? (
                    <div className="indicators-grid">
                        <div className="indicator-card">
                            <div className="indicator-value">{fmtMoney(totalIndicators.alocat_eur)}</div>
                            <div className="indicator-label">Alocat Total</div>
                            <div className="indicator-sublabel">{fmtMoney(totalIndicators.alocat_eur * 4.95)} RON</div>
                        </div>
                        <div className="indicator-card">
                            <div className="indicator-value">{fmtMoney(totalIndicators.platit_eur)}</div>
                            <div className="indicator-label">Plătit catre beneficiari</div>
                            <div className="indicator-sublabel">{fmtMoney(totalIndicators.platit_eur * 4.95)} RON</div>
                        </div>
                        <div className="indicator-card">
                            <div className="indicator-value">{fmtMoney(totalIndicators.incasat_eur)} </div>
                            <div className="indicator-label">Încasat de la U.E.</div>
                            <div className="indicator-sublabel">{fmtMoney(totalIndicators.incasat_eur * 4.95)} RON</div>
                        </div>
                        <div className="indicator-card">
                            <div className="indicator-value">{fmtNum(totalIndicators.nr_beneficiari_plati)}</div>
                            <div className="indicator-label">Număr Beneficiari Catre care s-au facut plati</div>
                            <div className="indicator-sublabel">Beneficiari cu plăți</div>
                        </div>
                        <div className="indicator-card">
                            <div className="indicator-value">{fmtNum(totalIndicators.nr_proiecte)}</div>
                            <div className="indicator-label">Număr Proiecte</div>
                            <div className="indicator-sublabel">{fmtNum(totalIndicators.nr_beneficiari_plati)} beneficiari</div>
                        </div>
                    </div>
                ) : null}
            </section>

            {/* Map */}
            <section className="map-container">
                <div className="map-chart">
                    {mapOptions && (
                        <HighchartsReact
                            highcharts={Highcharts}
                            constructorType={'mapChart'}
                            options={mapOptions}
                        />
                    )}
                </div>
            </section>

            {/* Top Beneficiaries Section */}
            <section className="beneficiaries-section">
                <h2>Topul beneficiarilor PNRR raportat la plăți</h2>
                {loadingBeneficiaries ? (
                    <div className="beneficiaries-loading">
                        <div className="loading-spinner-small"></div>
                        <span>Se încarcă topul beneficiarilor...</span>
                    </div>
                ) : topBeneficiaries && topBeneficiaries.items ? (
                    <div className="beneficiaries-content">
                        <div className="beneficiaries-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Beneficiar</th>
                                        <th>CUI</th>
                                        {/* <th className="num">Nerambursabil</th>
                                        <th className="num">Rambursabil</th> */}
                                        <th className="num">Total (EUR)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {topBeneficiaries.items.map((beneficiary, index) => (
                                        <tr key={index}>
                                            <td>
                                                <a 
                                                    href={`https://pnrr.fonduri-ue.ro/ords/pnrr/r/dashboard-status-pnrr/detalii-beneficiar?p2_cui=${beneficiary.cui}`}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="beneficiary-link"
                                                >
                                                    {beneficiary.beneficiar}
                                                </a>
                                            </td>
                                            <td>{beneficiary.cui}</td>
                                            {/* <td className="num">
                                                {beneficiary.nerambursabil ? fmtMoney(beneficiary.nerambursabil / 4.95) : '-'}
                                            </td>
                                            <td className="num">
                                                {beneficiary.rambursabil ? fmtMoney(beneficiary.rambursabil / 4.95) : '-'}
                                            </td> */}
                                            <td className="num">
                                                <strong>{fmtMoney(beneficiary.total_euro)}</strong>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <div className="beneficiaries-actions">
                            <a 
                                href="https://pnrr.fonduri-ue.ro/ords/pnrr/r/dashboard-status-pnrr/home"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="btn btn-primary"
                            >
                                Vezi toți beneficiarii
                            </a>
                        </div>
                    </div>
                ) : null}
            </section>

            {/* Below grid */}
            <section className="below-grid">
                <div className="card pie-card">
                    <HighchartsReact
                        highcharts={Highcharts}
                        options={pieOptions}
                    />
                </div>

                <div className="card rank-card">
                    <h3>Clasament județe – {getSelectionLabel()}</h3>
                    <ol className="rank-list">
                        {rankingData.map((county, index) => {
                            const percentage = maxValue ? Math.max(2, (county.value / maxValue) * 100) : 0
                            const displayValue = metric === 'value' ? fmtMoney(county.money) : fmtNum(county.projects)

                            return (
                                <li
                                    key={county.code}
                                    className="rank-item"
                                    onClick={() => onCountyClick(county.code, county.name)}
                                >
                                    <div className="rank-pos">{index + 1}</div>
                                    <div className="rank-name">{county.name}</div>
                                    <div className="rank-bar-wrap">
                                        <div className="rank-bar" style={{ width: `${percentage}%` }}></div>
                                    </div>
                                    <div className="rank-value">{displayValue}</div>
                                </li>
                            )
                        })}
                    </ol>
                    <div className="rank-actions">
                        <button
                            className="btn ghost"
                            onClick={() => setShowAllRanking(!showAllRanking)}
                        >
                            {showAllRanking ? 'Restrânge' : 'Afișează tot'}
                        </button>
                    </div>
                    <div className="rank-note">
                        Clic pe un județ pentru a deschide pagina lui. (Ctrl/⌘-clic pentru un nou tab.)
                    </div>
                </div>
            </section>

        </main>
    )

    function getSelectionLabel() {
        if (viewMode === 'general') return `General · ${metric === 'value' ? 'Valoare' : 'Proiecte'}`
        if (viewMode === 'program') {
            const program = PROGRAMS.find(p => p.key === activeProgram)
            return `${program?.label || activeProgram} · ${metric === 'value' ? 'Valoare' : 'Proiecte'}`
        }
        if (viewMode === 'total') return `Total · ${metric === 'value' ? 'Valoare' : 'Proiecte'}`
        return `Multi județe · ${metric === 'value' ? 'Valoare' : 'Proiecte'}`
    }
}

export default MapView
