import { useState, useMemo, useEffect } from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'
import HighchartsMap from 'highcharts/modules/map'
import { PROGRAMS, PROGRAM_COLORS, COUNTY_MAP, fmtMoney, fmtNum } from '../data/mockData'

// Initialize Highcharts Map module
HighchartsMap(Highcharts)

const CountyDetails = ({ county, data, onBackToMap, useRealData }) => {
  const [metric, setMetric] = useState('value')
  const [showAllProjects, setShowAllProjects] = useState(false)
  const [countyMapData, setCountyMapData] = useState(null)
  const [localityData, setLocalityData] = useState([])

  if (!county) return null

  const countyCode = county.code.replace('RO-', '')
  const countyData = county.data

  // Load county map data by filtering Romania topology
  useEffect(() => {
    const loadCountyMap = async () => {
      try {
        // Load full Romania topology and filter for the specific county
        const response = await fetch('https://code.highcharts.com/mapdata/countries/ro/ro-all.topo.json')
        if (!response.ok) {
          console.warn('Could not load Romania map data')
          setCountyMapData(null)
          return
        }
        
        const topology = await response.json()
        const allFeatures = Highcharts.geojson(topology)
        
        // Filter for the specific county
        const isBucharest = (countyCode === 'BI')
        const isoTarget = `RO-${countyCode}`
        const postalSet = new Set(isBucharest ? ['B', 'BU', 'BI'] : [countyCode])
        const hcKeySet = new Set([`ro-${countyCode.toLowerCase()}`])
        if (isBucharest) hcKeySet.add('ro-b')
        
        const norm = (s) => (s || '')
          .toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
          .replace(/ș|ş/g, 's').replace(/ț|ţ/g, 't')
          .toLowerCase().trim()
        
        const nameSet = new Set([
          norm(county.name),
          norm(`Judetul ${county.name}`),
          norm(`Județul ${county.name}`),
          ...(isBucharest ? [norm('Bucuresti'), norm('Municipiul Bucuresti'), norm('Municipiul București')] : [])
        ])
        
        const countyFeatures = allFeatures.filter(f => {
          const p = f.properties || {}
          const name = norm(p.name || p.NAME || '')
          const hcKey = (p['hc-key'] || p.hcKey || '').toLowerCase()
          const postal = (p['postal-code'] || p.postal || p['postal_code'] || '').toUpperCase()
          const iso = (p['iso_3166_2'] || p['iso-3166-2'] || p.iso3166_2 || '').toUpperCase()
          const id = (p.id || '').toUpperCase()
          const hasc = (p.hasc || '').toUpperCase()
          
          if (iso === isoTarget) return true
          if (id === isoTarget || id === isoTarget.replace('-', '.')) return true
          if (postal && postalSet.has(postal)) return true
          if (hcKey && hcKeySet.has(hcKey)) return true
          if (hasc && (hasc === `RO.${countyCode}` || (isBucharest && (hasc === 'RO.B' || hasc === 'RO.BU')))) return true
          if (name && nameSet.has(name)) return true
          return false
        })
        
        if (countyFeatures.length > 0) {
          const countyGeometry = { type: 'FeatureCollection', features: countyFeatures }
          setCountyMapData({ topology: countyGeometry, geojson: countyFeatures })
        } else {
          console.warn(`No geometry found for county ${countyCode}`)
          setCountyMapData(null)
        }
      } catch (error) {
        console.warn('Error loading county map:', error)
        setCountyMapData(null)
      }
    }
    loadCountyMap()
  }, [countyCode, county.name])

  // Load and process locality data
  useEffect(() => {
    const loadLocalityData = async () => {
      try {
        const response = await fetch('/data/ro_localities.min.json')
        if (!response.ok) {
          console.warn('Could not load localities data')
          return
        }
        
        const allCities = await response.json()
        const countyCities = allCities.filter(city => 
          (city.county || '').toUpperCase() === countyCode
        )
        
        // Build city index with aliases for matching
        const cityIndex = countyCities.map(city => {
          const base = city.name || ''
          const aliasSet = new Set([
            base, 
            ...(city.aliases || []),
            `Municipiul ${base}`, 
            `Orașul ${base}`, 
            `Orasul ${base}`,
            `Comuna ${base}`, 
            `Satul ${base}`,
            base.replace(/-/g, ' '), 
            base.replace(/ /g, '-')
          ].map(alias => norm(alias)))
          
          return {
            name: city.name,
            lat: +city.lat,
            lon: +city.lon,
            aliases: Array.from(aliasSet)
          }
        })
        
        // Count localities from project scopes
        const localityCounts = countLocalitiesFromScope(cityIndex)
        console.log(`County ${countyCode}: Found ${countyCities.length} cities, ${localityCounts.length} with projects`)
        console.log('Locality data:', localityCounts)
        setLocalityData(localityCounts)
        
      } catch (error) {
        console.warn('Error loading locality data:', error)
        setLocalityData([])
      }
    }
    
    loadLocalityData()
  }, [countyCode, countyData])

  // Helper function to normalize text (same as old project)
  const norm = (s) => (s || '')
    .toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/ș|ş/g, 's').replace(/ț|ţ/g, 't')
    .toLowerCase().trim()

  // Helper function to escape regex
  const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

  // Count projects & sum values per locality (same logic as old project)
  const countLocalitiesFromScope = (cityIndex) => {
    const counts = new Map()
    const projectRows = countyData.extras?.rows || []
    console.log(`Processing ${projectRows.length} project rows for county ${countyCode}`)
    
    for (const row of projectRows) {
      const text = norm(row?.SCOP_PROIECT || row?.Scop_Proiect || row?.Scop || '')
      if (!text) {
        console.log('No SCOP_PROIECT found in row:', row)
        continue
      }
      console.log('Processing scope text:', text)

      // Find which cities match in this row
      const matched = []
      for (const city of cityIndex) {
        let hit = false
        for (const alias of city.aliases) {
          if (!alias) continue
          const re = new RegExp(`(^|[^a-z0-9])${escapeRegExp(alias)}([^a-z0-9]|$)`, 'i')
          if (re.test(text)) {
            hit = true
            break
          }
        }
        if (hit) matched.push(city)
      }
      
      if (!matched.length) continue

      const rowShareValue = Number(row?.__share_value || 0) || 0
      const perCityValue = matched.length ? (rowShareValue / matched.length) : 0

      for (const city of matched) {
        const prev = counts.get(city.name) || { city, count: 0, money: 0 }
        prev.count += 1
        prev.money += perCityValue
        counts.set(city.name, prev)
      }
    }
    
    // Sort by count desc, then money desc, then name
    return Array.from(counts.values()).sort((a, b) =>
      (b.count - a.count) || (b.money - a.money) || a.city.name.localeCompare(b.city.name)
    )
  }

  // Calculate multi-county data for this county
  const multiData = data.find(d => d.code === 'RO-MULTI')
  const multiAgg = multiData?.extras?.multi_agg_by_county || {}
  const multiShare = multiAgg[countyCode] || { value: 0, projects: 0 }

  // Calculate rankings
  const allCounties = data.filter(d => d.code !== 'RO-MULTI')
  const valueRanking = allCounties
    .map(c => ({ code: c.code, name: c.name, value: c.total.value }))
    .sort((a, b) => b.value - a.value)
  const projectsRanking = allCounties
    .map(c => ({ code: c.code, name: c.name, projects: c.total.projects }))
    .sort((a, b) => b.projects - a.projects)

  const valueRank = valueRanking.findIndex(c => c.code === county.code) + 1
  const projectsRank = projectsRanking.findIndex(c => c.code === county.code) + 1

  // Calculate PNRR value (sum of all programs)
  const pnrrValue = Object.values(countyData.programs).reduce((sum, prog) => sum + (prog.value || 0), 0)

  // Program chart data
  const programChartData = useMemo(() => {
    return PROGRAMS
      .map(program => {
        const programData = countyData.programs[program.key] || { value: 0, projects: 0 }
        return {
          name: program.label,
          y: metric === 'value' ? programData.value : programData.projects,
          color: PROGRAM_COLORS[program.key]
        }
      })
      .filter(item => item.y > 0)
      .sort((a, b) => b.y - a.y)
  }, [countyData.programs, metric])

  // Ranking chart data (top 10 counties with current county highlighted)
  const rankingChartData = useMemo(() => {
    const ranking = metric === 'value' ? valueRanking : projectsRanking
    let top10 = ranking.slice(0, 10)
    
    // If current county is not in top 10, replace the 10th with current county
    if (!top10.some(c => c.code === county.code)) {
      const currentCounty = ranking.find(c => c.code === county.code)
      if (currentCounty) {
        top10[9] = currentCounty
      }
    }

    return top10.map(c => ({
      name: `${c.code.replace('RO-', '')} · ${c.name}`,
      y: metric === 'value' ? c.value : c.projects,
      color: c.code === county.code ? '#0ea5e9' : '#cbd5e1'
    }))
  }, [county.code, valueRanking, projectsRanking, metric])

  // Program pie chart options
  const programPieOptions = {
    chart: { type: 'pie' },
    title: { text: `Distribuție pe programe – ${metric === 'value' ? 'Valoare (EUR)' : 'Proiecte'}` },
    tooltip: {
      useHTML: true,
      pointFormatter: function() {
        const val = metric === 'value' ? fmtMoney(this.y) : fmtNum(this.y)
        return `<span style="color:${this.color}">●</span> ${this.name}: <b>${val}</b>`
      }
    },
    plotOptions: {
      pie: {
        innerSize: '55%',
        dataLabels: {
          enabled: true,
          formatter: function() {
            return this.percentage ? Highcharts.numberFormat(this.percentage, 1) + '%' : null
          }
        }
      }
    },
    series: [{ name: 'Programe', data: programChartData }],
    credits: { enabled: false }
  }

  // Ranking bar chart options
  const rankingBarOptions = {
    chart: { type: 'bar' },
    title: { text: `Clasament județe – ${metric === 'value' ? 'Valoare (EUR)' : 'Proiecte'}` },
    xAxis: { 
      categories: rankingChartData.map(item => item.name),
      title: { text: null }
    },
    yAxis: { 
      title: { text: null },
      labels: {
        formatter: function() {
          return metric === 'value' ? fmtMoney(this.value) : fmtNum(this.value)
        }
      }
    },
    tooltip: {
      useHTML: true,
      formatter: function() {
        return metric === 'value' ? `<b>${fmtMoney(this.point.y)}</b>` : `<b>${fmtNum(this.point.y)}</b>`
      }
    },
    plotOptions: {
      series: {
        dataLabels: {
          enabled: true,
          formatter: function() {
            return metric === 'value' ? fmtMoney(this.y) : fmtNum(this.y)
          }
        }
      }
    },
    series: [{ 
      name: metric === 'value' ? 'Valoare' : 'Proiecte',
      data: rankingChartData 
    }],
    legend: { enabled: false },
    credits: { enabled: false }
  }

  // County map configuration
  const countyMapOptions = useMemo(() => {
    if (!countyMapData) return null

    // Use real locality data with actual coordinates and investment counts
    const localityPins = localityData.filter(hit => hit.count > 0)

    return {
      chart: {
        map: countyMapData.topology,
        height: 460,
        spacing: [0, 0, 0, 0],
        backgroundColor: 'transparent'
      },
      title: {
        text: `Harta județului ${county.name}`,
        style: {
          fontSize: '16px',
          fontWeight: 600
        }
      },
      subtitle: {
        text: localityPins.length > 0 
          ? `${localityPins.length} localități cu investiții identificate din proiectele din acest județ`
          : 'Nu au fost identificate localități cu investiții în proiectele din acest județ'
      },
      mapNavigation: {
        enabled: true,
        enableDoubleClickZoomTo: true,
        buttonOptions: {
          verticalAlign: 'bottom'
        }
      },
      tooltip: {
        enabled: true
      },
      legend: {
        enabled: false
      },
      series: [
        {
          name: county.name,
          data: countyMapData.geojson,
          color: '#0ea5e9',
          borderColor: '#334155',
          borderWidth: 1.1,
          enableMouseTracking: false
        },
        {
          type: 'mappoint',
          name: 'Localități',
          data: localityPins.map(hit => ({
            name: hit.city.name,
            lat: hit.city.lat,
            lon: hit.city.lon,
            count: hit.count,
            money: hit.money
          })),
          marker: {
            radius: 5,
            fillColor: '#ef4444',
            lineColor: '#fff',
            lineWidth: 1
          },
          dataLabels: {
            enabled: true,
            formatter: function() {
              return this.point.name.split(' - ')[1] || this.point.name
            },
            allowOverlap: false,
            crop: true,
            style: {
              fontSize: '10px',
              textOutline: 'none'
            }
          },
          tooltip: {
            useHTML: true,
            pointFormatter: function() {
              return `
                <b>${this.name}</b><br/>
                Proiecte: <b>${fmtNum(this.count)}</b><br/>
                Valoare: <b>${fmtMoney(this.money)}</b>
              `
            }
          },
          states: {
            hover: {
              halo: {
                size: 8
              }
            }
          }
        }
      ],
      credits: {
        enabled: false
      }
    }
  }, [countyMapData, county.name, countyCode, metric])

  // Projects table data
  const projectsData = countyData.extras?.rows || []
  const displayedProjects = showAllProjects ? projectsData : projectsData.slice(0, 10)

  return (
    <main className="page page--county">
      <header className="page-header">
        <a href="#" className="back-link" onClick={(e) => { e.preventDefault(); onBackToMap() }}>
          ← Înapoi la hartă națională
        </a>
        <h1>{county.name} ({countyCode})</h1>
        <div className="sub">
          Tablou de bord PNRR • distribuție pe programe • Set date: <strong>{useRealData ? 'Date reale PNRR (baza completă)' : 'Date demonstrative'}</strong>
        </div>
      </header>

      <div className="controls controls--county">
        <div className="segment">
          <button 
            className={metric === 'value' ? 'active' : ''}
            onClick={() => setMetric('value')}
          >
            Valoare
          </button>
          <button 
            className={metric === 'projects' ? 'active' : ''}
            onClick={() => setMetric('projects')}
          >
            Proiecte
          </button>
        </div>
      </div>

      <div className="county-content">
        {/* KPIs */}
        <div className="kpis">
          <div className="kpi">
            <div className="label">Total valoare (toate programele, fără multi-județe)</div>
            <div className="value">{fmtMoney(countyData.total.value)}</div>
            <div className="subline">Multi județe: {fmtMoney(multiShare.value)}</div>
          </div>
          <div className="kpi">
            <div className="label">Total proiecte (toate programele, fără multi-județe)</div>
            <div className="value">{fmtNum(countyData.total.projects)}</div>
            <div className="subline">Multi județe: {fmtNum(multiShare.projects)} proiecte</div>
          </div>
          <div className="kpi">
            <div className="label">Informații suplimentare</div>
            <div className="value">
              Total PNRR: {fmtMoney(pnrrValue)}
            </div>
            <div className="subline">
              Clasament valoare: #{valueRank} • Clasament proiecte: #{projectsRank}
            </div>
          </div>
        </div>

        {/* County Map */}
        <section className="county-map-section">
          <div className="card county-map-card">
          {countyMapData && countyMapOptions ? (
            <HighchartsReact
              highcharts={Highcharts}
              constructorType={'mapChart'}
              options={countyMapOptions}
            />
          ) : (
            <div style={{ textAlign: 'center', padding: '40px', color: '#64748b' }}>
              <h3 style={{ margin: '0 0 8px 0', fontSize: '16px' }}>Harta județului {county.name}</h3>
              <p style={{ margin: 0 }}>Harta detaliată nu este disponibilă pentru acest județ</p>
            </div>
          )}
          </div>
        </section>

        {/* Localities Table */}
        {localityData.length > 0 && (
          <section className="localities-section">
            <div className="card">
            <h3 style={{ margin: '0 0 8px 0' }}>Localități sprijinite</h3>
            <div className="muted" style={{ marginBottom: '10px' }}>
              {localityData.length} localități identificate • {fmtNum(localityData.reduce((sum, hit) => sum + hit.count, 0))} proiecte (sumă pe localități)
            </div>
            <div className="scroll-x">
              <table>
                <thead>
                  <tr>
                    <th>Localitate</th>
                    <th className="num">Numărul de proiecte în care această localitate este menționată</th>
                    <th className="num">Valoare estimată (EUR)</th>
                  </tr>
                </thead>
                <tbody>
                  {localityData.slice(0, showAllProjects ? localityData.length : 10).map((hit, index) => (
                    <tr key={index}>
                      <td>
                        <strong style={{ color: '#0ea5e9' }}>{hit.city.name}</strong>
                      </td>
                      <td className="num">{fmtNum(hit.count)}</td>
                      <td className="num">{fmtMoney(hit.money)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {localityData.length > 10 && (
              <div style={{ marginTop: '8px', textAlign: 'right' }}>
                <button 
                  className="btn ghost"
                  onClick={() => setShowAllProjects(!showAllProjects)}
                >
                  {showAllProjects ? 'Restrânge la 10' : `Afișează toate (${localityData.length})`}
                </button>
              </div>
            )}
          </div>
          </section>
        )}

        {/* Charts Grid */}
        <div className="grid">
          <div className="card">
            <HighchartsReact
              highcharts={Highcharts}
              options={programPieOptions}
            />
          </div>
          <div className="card">
            <HighchartsReact
              highcharts={Highcharts}
              options={rankingBarOptions}
            />
          </div>
        </div>

        {/* Programs Table */}
        <div className="card" style={{ marginTop: 'var(--gap)' }}>
          <h3 style={{ margin: '0 0 8px 0' }}>Detaliu pe programe</h3>
          <div className="muted" style={{ marginBottom: '10px' }}>
            Valorile sunt filtrate pentru județul {county.name} ({countyCode})
          </div>

          <div className="scroll-x">
            <table>
              <thead>
                <tr>
                  <th>Program</th>
                  <th className="num">Valoare (EUR)</th>
                  <th className="num">Proiecte</th>
                </tr>
              </thead>
              <tbody>
                {PROGRAMS
                  .map(program => {
                    const programData = countyData.programs[program.key] || { value: 0, projects: 0 }
                    return {
                      program: program.label,
                      value: programData.value,
                      projects: programData.projects
                    }
                  })
                  .filter(row => row.value > 0 || row.projects > 0)
                  .sort((a, b) => metric === 'value' ? b.value - a.value : b.projects - a.projects)
                  .map((row, index) => (
                    <tr key={index}>
                      <td>{row.program}</td>
                      <td className="num">{fmtMoney(row.value)}</td>
                      <td className="num">{fmtNum(row.projects)}</td>
                    </tr>
                  ))}
                {/* Multi-county row */}
                <tr style={{ borderTop: '2px solid var(--ring)' }}>
                  <td><strong>Multi județe</strong></td>
                  <td className="num"><strong>{fmtMoney(multiShare.value)}</strong></td>
                  <td className="num"><strong>{fmtNum(multiShare.projects)}</strong></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Projects in this County */}
        <div className="card" style={{ marginTop: 'var(--gap)' }}>
          <h3 style={{ margin: '0 0 8px 0' }}>Investiții în acest județ</h3>
          <div className="muted">
            Proiectele corespunzătoare județului selectat ({projectsData.length} proiecte găsite)
          </div>

          <div style={{ margin: '10px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span className="muted">
              Afișate: {displayedProjects.length} din {projectsData.length} proiecte
            </span>
            {projectsData.length > 10 && (
              <button 
                className="btn ghost"
                onClick={() => setShowAllProjects(!showAllProjects)}
              >
                {showAllProjects ? 'Afișează doar primele 10' : `Afișează toate (${projectsData.length})`}
              </button>
            )}
          </div>

          <div className="scroll-x">
            <table>
              <thead>
                <tr>
                  <th>Titlu Proiect</th>
                  <th>Nume Beneficiar</th>
                  <th>Sursă Finanțare</th>
                  <th className="num">Valoare Plată (EUR)</th>
                  <th className="num">Progres Fizic (%)</th>
                  <th>Cod Componentă</th>
                  <th>Cod Măsură</th>
                </tr>
              </thead>
              <tbody>
                {displayedProjects.map((project, index) => (
                  <tr key={index}>
                    <td>{project.TITLU_PROIECT}</td>
                    <td>{project.NUME_BENEFICIAR}</td>
                    <td>{project.SURSA_FINANTARE}</td>
                    <td className="num">{fmtMoney(project.VALOARE_PLATA_EURO || project.VALOARE_PLATA_FE_EURO || 0)}</td>
                    <td className="num">{project.PROGRES_FIZIC}%</td>
                    <td>{project.COD_COMPONENTA}</td>
                    <td>{project.COD_MASURA}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {projectsData.length === 0 && (
            <div className="muted" style={{ textAlign: 'center', padding: '20px' }}>
              Nu au fost găsite proiecte pentru acest județ.
            </div>
          )}
        </div>
      </div>
    </main>
  )
}

export default CountyDetails
