# PNRR Data Download Script

This Node.js script downloads the complete PNRR payment database from the official API and saves it as a JSON file for inspection and analysis.

## Usage

### Option 1: Using npm script (recommended)
```bash
npm run download-data
```

### Option 2: Direct execution
```bash
node download-pnrr-data.js
```

### Option 3: Make executable and run
```bash
chmod +x download-pnrr-data.js
./download-pnrr-data.js
```

## What it does

1. **Downloads all payment records** from `https://pnrr.fonduri-ue.ro/ords/pnrr/mfe/plati_pnrr`
2. **Uses pagination** to fetch data in batches of 5,000 records
3. **Handles errors gracefully** with retry logic and exponential backoff
4. **Saves complete dataset** to `pnrr-data-complete.json`
5. **Provides detailed statistics** about the downloaded data

## Features

- ✅ **Complete database download** - Fetches all available records
- ✅ **Batch processing** - Uses 5,000 record batches for efficiency
- ✅ **Error handling** - Retries failed requests up to 3 times
- ✅ **Progress tracking** - Shows real-time download progress
- ✅ **Data validation** - Verifies data integrity during download
- ✅ **Statistics generation** - Provides summary of downloaded data
- ✅ **Graceful interruption** - Handles Ctrl+C cleanly

## Output

The script creates a file called `pnrr-data-complete.json` in the project root containing:

```json
[
  {
    "cod_componenta": "C7",
    "cod_masura": "I4",
    "cod_submasura": null,
    "masura": "Investiția 4. Digitalizarea sistemului judiciar",
    "cri": "MJ",
    "sursa_finantare": "grant",
    "valoare_plata_fe": 13903400,
    "valoare_plata_fe_euro": 2780680,
    "data_plata": "2023-07-25T21:00:00Z",
    "cui_beneficiar_final": 34770594,
    "nume_beneficiar": "METAMINDS S.A.",
    "judet_beneficiar": "MUNICIPIUL BUCUREŞTI",
    "localitate_beneficiar": "Sec. 1, Mun. Bucureşti",
    "cod_diviziune_caen": "46",
    "descriere_diviziune_caen": "Comerţ cu ridicata cu excepţa comerţului cu autovehicule şi motociclete"
  }
  // ... thousands more records
]
```

## Sample Output

```
🇷🇴 PNRR Data Downloader
========================

🚀 Starting PNRR data download...
📊 Batch size: 5,000 records
⏱️  Delay between requests: 100ms

📦 Batch 1: Fetching records 1-5000...
   ✓ Fetched 5000 records. Total: 5000
   ⏳ Waiting 100ms...

📦 Batch 2: Fetching records 5001-10000...
   ✓ Fetched 5000 records. Total: 10000
   ⏳ Waiting 100ms...

...

✅ Reached end of data (partial batch)

📈 Download Summary:
   Total records: 45,234
   Total batches: 10
   Duration: 12.45 seconds
   Average: 3,634 records/second

💾 Saving data to pnrr-data-complete.json...
✅ Data saved successfully!
   File: /path/to/project/pnrr-data-complete.json
   Size: 125.67 MB
   Records: 45,234

📊 Data Summary:
   Total value: 15,234,567,890 RON
   Unique components: 15
   Unique counties: 42

🏆 Top 5 Components:
   1. C1: 12,345 records
   2. C7: 8,901 records
   3. C4: 6,789 records
   4. C2: 5,432 records
   5. C8: 4,321 records

🏆 Top 5 Counties:
   1. MUNICIPIUL BUCUREŞTI: 15,678 records
   2. CLUJ: 3,456 records
   3. TIMIŞ: 2,890 records
   4. CONSTANŢA: 2,345 records
   5. BRAŞOV: 2,123 records

🎉 Download completed successfully!
📁 Check the file: pnrr-data-complete.json
```

## Configuration

You can modify these variables at the top of the script:

- `BATCH_SIZE`: Number of records per API request (default: 5000)
- `DELAY_BETWEEN_REQUESTS`: Milliseconds to wait between requests (default: 100)
- `MAX_RETRIES`: Number of retry attempts for failed requests (default: 3)
- `OUTPUT_FILE`: Name of the output JSON file (default: 'pnrr-data-complete.json')

## Dependencies

The script automatically installs `node-fetch` if not present. No other dependencies required.

## Error Handling

- **Network errors**: Retries with exponential backoff
- **API errors**: Handles 404/400 as end-of-data indicators
- **Timeout errors**: 30-second timeout per request
- **Interruption**: Graceful handling of Ctrl+C

## File Size

Expect the output file to be quite large (50-200+ MB) depending on the amount of data in the PNRR database.

## Use Cases

- **Data analysis** - Inspect the complete dataset structure
- **Development** - Use as offline data source for testing
- **Research** - Analyze PNRR payment patterns and distributions
- **Backup** - Create local copy of the data
