// Script to geocode localities using OpenStreetMap's Nominatim service
const fs = require('fs');
const path = require('path');
const https = require('https');

// Read the data.json file
const dataPath = path.join(__dirname, 'data.json');
const rawData = fs.readFileSync(dataPath, 'utf8');
const data = JSON.parse(rawData);

// Extract unique locality + county combinations
const uniqueLocalities = new Map();

data.items.forEach(item => {
    if (item.localitate_beneficiar && item.judet_beneficiar) {
        const key = `${item.localitate_beneficiar.trim()}, ${item.judet_beneficiar.trim()}, Romania`;
        if (!uniqueLocalities.has(key)) {
            uniqueLocalities.set(key, {
                localitate: item.localitate_beneficiar.trim(),
                judet: item.judet_beneficiar.trim(),
                searchTerm: key,
                coordinates: null
            });
        }
    }
});

console.log(`Found ${uniqueLocalities.size} unique localities to geocode`);

// Function to clean up locality names for better geocoding results
function cleanLocalityName(name) {
    // Remove prefixes like "Sec.", "Mun.", "Com.", etc.
    let cleaned = name
        .replace(/^Sec\.\s*(\d+)(?:,\s*Mun\.\s*Bucureşti)?/i, 'Sector $1 București')
        .replace(/^Mun\.\s*/i, '')
        .replace(/^Orş?\.\s*/i, '')
        .replace(/^Com\.\s*/i, '')
        .replace(/^Sat\s*/i, '')
        .replace(/^MRJ\.\s*/i, '')
        .replace(/\.\s*$/, ''); // Remove trailing periods
    
    return cleaned;
}

// Function to geocode a single locality
function geocodeLocality(locality, callback) {
    const cleanedName = cleanLocalityName(locality.localitate);
    const searchTerm = `${cleanedName}, ${locality.judet}, Romania`;
    
    // Encode the search term for URL
    const encodedSearchTerm = encodeURIComponent(searchTerm);
    
    const options = {
        hostname: 'nominatim.openstreetmap.org',
        path: `/search?format=json&q=${encodedSearchTerm}&limit=1`,
        method: 'GET',
        headers: {
            'User-Agent': 'PNRR-Map-Generator/1.0'
        }
    };
    
    const req = https.request(options, res => {
        let data = '';
        
        res.on('data', chunk => {
            data += chunk;
        });
        
        res.on('end', () => {
            try {
                const results = JSON.parse(data);
                if (results && results.length > 0) {
                    const result = results[0];
                    locality.coordinates = {
                        lat: parseFloat(result.lat),
                        lng: parseFloat(result.lon)
                    };
                    locality.osmData = {
                        displayName: result.display_name,
                        type: result.type,
                        importance: result.importance
                    };
                    callback(null, locality);
                } else {
                    callback(null, locality); // No results found
                }
            } catch (error) {
                callback(error, locality);
            }
        });
    });
    
    req.on('error', error => {
        callback(error, locality);
    });
    
    req.end();
}

// Process localities with a delay to respect Nominatim's usage policy
const delay = 1100; // 1.1 seconds between requests
let processed = 0;
const results = [];
const errors = [];

console.log('Starting geocoding process...');

// Convert Map to Array for processing
const localitiesArray = Array.from(uniqueLocalities.values());

function processNext(index) {
    if (index >= localitiesArray.length) {
        // All done, save results
        const successfulGeocodes = results.filter(l => l.coordinates !== null);
        
        console.log(`\nGeocoding completed:`);
        console.log(`- Total localities: ${localitiesArray.length}`);
        console.log(`- Successfully geocoded: ${successfulGeocodes.length}`);
        console.log(`- Failed to geocode: ${localitiesArray.length - successfulGeocodes.length}`);
        
        if (errors.length > 0) {
            console.log(`- Errors encountered: ${errors.length}`);
        }
        
        // Create a map of locality names to coordinates
        const coordinatesMap = {};
        successfulGeocodes.forEach(locality => {
            const key = `${locality.localitate}|${locality.judet}`;
            coordinatesMap[key] = locality.coordinates;
        });
        
        // Save to file
        fs.writeFileSync(
            path.join(__dirname, 'geocoded_localities.json'),
            JSON.stringify(results, null, 2),
            'utf8'
        );
        
        // Save coordinates map to file
        fs.writeFileSync(
            path.join(__dirname, 'locality_coordinates_map.json'),
            JSON.stringify(coordinatesMap, null, 2),
            'utf8'
        );
        
        // Generate JavaScript code for the HTML file
        const jsCode = `
// Locality coordinates from OpenStreetMap geocoding
const localityCoordinatesMap = ${JSON.stringify(coordinatesMap, null, 2)};

// Function to get coordinates for a locality within a county
function getLocalityCoordinates(localityName, countyKey) {
    if (!localityName || !countyKey) {
        return { lat: 44.4268, lng: 26.1025 }; // Default to Bucharest
    }
    
    // Try to find the locality in our geocoded map
    const key = \`\${localityName}|\${countyKey}\`;
    if (localityCoordinatesMap[key]) {
        return localityCoordinatesMap[key];
    }
    
    // Special case for Bucharest sectors
    if (normalizeCountyName(countyKey) === 'BUCURESTI') {
        const sectorMatch = localityName.match(/Sec\\. (\\d+)/i);
        if (sectorMatch) {
            const sectorNum = sectorMatch[1];
            const sectorCoords = {
                '1': { lat: 44.4783, lng: 26.0700 },
                '2': { lat: 44.4500, lng: 26.1300 },
                '3': { lat: 44.4200, lng: 26.1600 },
                '4': { lat: 44.3900, lng: 26.1000 },
                '5': { lat: 44.4000, lng: 26.0500 },
                '6': { lat: 44.4400, lng: 26.0300 }
            }[sectorNum];
            
            if (sectorCoords) {
                // Add small random offset to avoid exact overlap
                const smallOffset = 0.005;
                const latOffset = (Math.random() - 0.5) * smallOffset;
                const lngOffset = (Math.random() - 0.5) * smallOffset;
                
                return { 
                    lat: sectorCoords.lat + latOffset, 
                    lng: sectorCoords.lng + lngOffset 
                };
            }
        }
    }
    
    // Fall back to county coordinates with random offset
    const normalizedCountyKey = normalizeCountyName(countyKey);
    const county = romanianCounties[normalizedCountyKey];
    if (!county) {
        console.log(\`County not found for coordinates: \${countyKey} -> normalized: \${normalizedCountyKey}\`);
        return { lat: 44.4268, lng: 26.1025 }; // Default to Bucharest
    }

    // Add some randomness around county center for localities
    const offsetRange = normalizedCountyKey === 'BUCURESTI' ? 0.05 : 0.2;
    const latOffset = (Math.random() - 0.5) * offsetRange;
    const lngOffset = (Math.random() - 0.5) * offsetRange;
    
    return {
        lat: county.lat + latOffset,
        lng: county.lng + lngOffset
    };
}`;
        
        fs.writeFileSync(
            path.join(__dirname, 'locality_coordinates.js'),
            jsCode,
            'utf8'
        );
        
        console.log('\nFiles saved:');
        console.log('- geocoded_localities.json: Full geocoding results');
        console.log('- locality_coordinates_map.json: Simple map of locality names to coordinates');
        console.log('- locality_coordinates.js: JavaScript code for the HTML file');
        
        return;
    }
    
    const locality = localitiesArray[index];
    processed++;
    
    // Show progress
    if (processed % 10 === 0 || processed === 1 || processed === localitiesArray.length) {
        console.log(`Processing ${processed}/${localitiesArray.length}: ${locality.searchTerm}`);
    }
    
    geocodeLocality(locality, (error, result) => {
        if (error) {
            console.error(`Error geocoding ${locality.searchTerm}:`, error.message);
            errors.push({ locality: locality.searchTerm, error: error.message });
        } else {
            results.push(result);
        }
        
        // Process next locality after delay
        setTimeout(() => {
            processNext(index + 1);
        }, delay);
    });
}

// Start processing
processNext(0);

// Note: This script will take some time to run due to the rate limiting
console.log('Geocoding process started. This will take some time...');
console.log('Please be patient and respect Nominatim usage policy.');
