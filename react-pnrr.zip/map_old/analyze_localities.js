// Script to analyze locality formats in detail
const fs = require('fs');
const path = require('path');

// Read the data.json file
try {
    const dataPath = path.join(__dirname, 'data.json');
    const rawData = fs.readFileSync(dataPath, 'utf8');
    const data = JSON.parse(rawData);
    
    // Extract all unique localities
    const localities = new Map();
    const countyLocalities = new Map();
    
    data.items.forEach(item => {
        if (item.localitate_beneficiar && item.judet_beneficiar) {
            const locality = item.localitate_beneficiar;
            const county = normalizeCountyName(item.judet_beneficiar);
            
            // Count localities
            if (!localities.has(locality)) {
                localities.set(locality, 0);
            }
            localities.set(locality, localities.get(locality) + 1);
            
            // Group by county
            if (!countyLocalities.has(county)) {
                countyLocalities.set(county, new Set());
            }
            countyLocalities.get(county).add(locality);
        }
    });
    
    // Output locality statistics
    console.log('=== Locality Statistics ===');
    console.log(`Total unique localities: ${localities.size}`);
    
    // Most common localities
    console.log('\n=== Most Common Localities ===');
    const sortedLocalities = Array.from(localities.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 20);
    
    sortedLocalities.forEach(([locality, count]) => {
        console.log(`"${locality}": ${count} occurrences`);
    });
    
    // Counties with most localities
    console.log('\n=== Counties with Most Localities ===');
    const sortedCounties = Array.from(countyLocalities.entries())
        .sort((a, b) => b[1].size - a[1].size)
        .slice(0, 10);
    
    sortedCounties.forEach(([county, localitySet]) => {
        console.log(`${county}: ${localitySet.size} unique localities`);
    });
    
    // Analyze locality patterns
    console.log('\n=== Locality Pattern Analysis ===');
    
    const patterns = {
        sector: /^Sec\. \d+/i,
        municipiu: /^Mun\./i,
        oras: /^Or[sş]\./i,
        comuna: /^Com\./i,
        sat: /^Sat/i,
        other: /./
    };
    
    const patternCounts = {};
    Object.keys(patterns).forEach(key => {
        patternCounts[key] = 0;
    });
    
    localities.forEach((count, locality) => {
        let matched = false;
        for (const [key, pattern] of Object.entries(patterns)) {
            if (locality.match(pattern) && !matched) {
                patternCounts[key] += count;
                matched = true;
                if (key !== 'other') break;
            }
        }
    });
    
    console.log('Pattern occurrence counts:');
    Object.entries(patternCounts)
        .sort((a, b) => b[1] - a[1])
        .forEach(([pattern, count]) => {
            console.log(`${pattern}: ${count} occurrences`);
        });
    
    // Generate a mapping object for localities to counties
    console.log('\n=== Sample Locality to County Mapping ===');
    console.log('const localityToCounty = {');
    
    // Take a sample of localities from each county
    const sampleSize = 3;
    countyLocalities.forEach((localitySet, county) => {
        const sample = Array.from(localitySet).slice(0, sampleSize);
        sample.forEach(locality => {
            console.log(`    "${locality}": "${county}",`);
        });
    });
    
    console.log('};');
    
} catch (error) {
    console.error('Error processing the data file:', error);
    process.exit(1);
}

// Function to normalize county names
function normalizeCountyName(countyName) {
    if (!countyName) return '';
    
    // Convert to uppercase for consistency
    let normalized = countyName.toUpperCase();
    
    // Handle special case for Bucharest
    if (normalized === 'MUNICIPIUL BUCUREŞTI' || normalized === 'MUNICIPIUL BUCURESTI') {
        return 'BUCURESTI';
    }
    
    // Remove 'JUDETUL ' prefix if present
    normalized = normalized.replace(/^JUDETUL\s+/i, '');
    
    // Replace Romanian special characters with their ASCII equivalents
    const replacements = {
        'Ş': 'S', 'Ţ': 'T', 'Ă': 'A', 'Â': 'A', 'Î': 'I'
    };
    
    for (const [special, ascii] of Object.entries(replacements)) {
        normalized = normalized.replace(new RegExp(special, 'g'), ascii);
    }
    
    return normalized;
}
