// Script to validate county mapping against romanianCounties
const fs = require('fs');
const path = require('path');

// Read the data.json file
try {
    const dataPath = path.join(__dirname, 'data.json');
    const rawData = fs.readFileSync(dataPath, 'utf8');
    const data = JSON.parse(rawData);
    
    // Define the romanianCounties object as it appears in the HTML file
    const romanianCounties = {
        'ALBA': { name: 'Alba' },
        'ARAD': { name: 'Arad' },
        'ARGES': { name: 'Argeș' },
        'BACAU': { name: 'Bacău' },
        'BIHOR': { name: 'Bihor' },
        'BISTRITA-NASAUD': { name: 'Bistrița-Năsăud' },
        'BOTOSANI': { name: 'Botoșani' },
        'BRASOV': { name: 'Brașov' },
        'BRAILA': { name: 'Brăila' },
        'BUZAU': { name: 'Buzău' },
        'CARAS-SEVERIN': { name: 'Caraș-Severin' },
        'CALARASI': { name: 'Călărași' },
        'CLUJ': { name: 'Cluj' },
        'CONSTANTA': { name: 'Constanța' },
        'COVASNA': { name: 'Covasna' },
        'DAMBOVITA': { name: 'Dâmbovița' },
        'DOLJ': { name: 'Dolj' },
        'GALATI': { name: 'Galați' },
        'GIURGIU': { name: 'Giurgiu' },
        'GORJ': { name: 'Gorj' },
        'HARGHITA': { name: 'Harghita' },
        'HUNEDOARA': { name: 'Hunedoara' },
        'IALOMITA': { name: 'Ialomița' },
        'IASI': { name: 'Iași' },
        'ILFOV': { name: 'Ilfov' },
        'MARAMURES': { name: 'Maramureș' },
        'MEHEDINTI': { name: 'Mehedinți' },
        'MURES': { name: 'Mureș' },
        'NEAMT': { name: 'Neamț' },
        'OLT': { name: 'Olt' },
        'PRAHOVA': { name: 'Prahova' },
        'SATU-MARE': { name: 'Satu Mare' },
        'SALAJ': { name: 'Sălaj' },
        'SIBIU': { name: 'Sibiu' },
        'SUCEAVA': { name: 'Suceava' },
        'TELEORMAN': { name: 'Teleorman' },
        'TIMIS': { name: 'Timiș' },
        'TULCEA': { name: 'Tulcea' },
        'VALCEA': { name: 'Vâlcea' },
        'VASLUI': { name: 'Vaslui' },
        'VRANCEA': { name: 'Vrancea' },
        'BUCURESTI': { name: 'București' }
    };
    
    // Extract all unique county names from the data
    const uniqueCounties = new Set();
    data.items.forEach(item => {
        if (item.judet_beneficiar) {
            uniqueCounties.add(item.judet_beneficiar);
        }
    });
    
    // Check each county against our mapping
    console.log('=== County Mapping Validation ===');
    
    const unmappedCounties = [];
    const mappedCounties = [];
    
    uniqueCounties.forEach(county => {
        const normalized = normalizeCountyName(county);
        if (romanianCounties[normalized]) {
            mappedCounties.push({
                original: county,
                normalized: normalized,
                mappedName: romanianCounties[normalized].name
            });
        } else {
            unmappedCounties.push({
                original: county,
                normalized: normalized
            });
        }
    });
    
    // Output results
    console.log(`\nSuccessfully mapped counties (${mappedCounties.length}):`);
    mappedCounties.forEach(item => {
        console.log(`"${item.original}" -> "${item.normalized}" -> "${item.mappedName}"`);
    });
    
    console.log(`\nUnmapped counties (${unmappedCounties.length}):`);
    if (unmappedCounties.length > 0) {
        unmappedCounties.forEach(item => {
            console.log(`"${item.original}" -> "${item.normalized}" (not found in romanianCounties)`);
        });
        
        // Generate suggested additions
        console.log('\n=== Suggested Additions to romanianCounties ===');
        unmappedCounties.forEach(item => {
            console.log(`'${item.normalized}': { name: '${item.original}', lat: 0, lng: 0, localities: [] },`);
        });
    } else {
        console.log('All counties are successfully mapped!');
    }
    
    // Count occurrences of each county
    const countyOccurrences = {};
    data.items.forEach(item => {
        if (item.judet_beneficiar) {
            const normalized = normalizeCountyName(item.judet_beneficiar);
            countyOccurrences[normalized] = (countyOccurrences[normalized] || 0) + 1;
        }
    });
    
    console.log('\n=== County Occurrence Counts ===');
    Object.entries(countyOccurrences)
        .sort((a, b) => b[1] - a[1])
        .forEach(([county, count]) => {
            const displayName = romanianCounties[county] ? 
                romanianCounties[county].name : county;
            console.log(`${displayName}: ${count} occurrences`);
        });
    
} catch (error) {
    console.error('Error processing the data file:', error);
    process.exit(1);
}

// Function to normalize county names
function normalizeCountyName(countyName) {
    if (!countyName) return '';
    
    // Convert to uppercase for consistency
    let normalized = countyName.toUpperCase();
    
    // Handle special case for Bucharest
    if (normalized === 'MUNICIPIUL BUCUREŞTI' || normalized === 'MUNICIPIUL BUCURESTI') {
        return 'BUCURESTI';
    }
    
    // Remove 'JUDETUL ' prefix if present
    normalized = normalized.replace(/^JUDETUL\s+/i, '');
    
    // Replace Romanian special characters with their ASCII equivalents
    const replacements = {
        'Ş': 'S', 'Ţ': 'T', 'Ă': 'A', 'Â': 'A', 'Î': 'I'
    };
    
    for (const [special, ascii] of Object.entries(replacements)) {
        normalized = normalized.replace(new RegExp(special, 'g'), ascii);
    }
    
    return normalized;
}
