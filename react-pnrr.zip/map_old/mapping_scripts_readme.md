# County and Locality Mapping Scripts

This directory contains several JavaScript scripts to help analyze and map county and locality data from the PNRR API.

## Prerequisites

- Node.js installed on your system
- The `data.json` file containing the API response data

## Available Scripts

### 1. extract_counties.js

Extracts all unique county names from the data and generates a mapping object.

```bash
node extract_counties.js
```

**Output:**
- List of all unique county names
- County normalization mapping
- Generated county mapping code that can be used in the application

### 2. validate_county_mapping.js

Validates the county names against the existing `romanianCounties` object in the HTML file.

```bash
node validate_county_mapping.js
```

**Output:**
- List of successfully mapped counties
- List of unmapped counties
- Suggested additions to the `romanianCounties` object
- County occurrence counts

### 3. generate_county_mapping.js

Generates improved versions of the `parseLocalityName` and `normalizeCountyName` functions.

```bash
node generate_county_mapping.js
```

**Output:**
- Locality format analysis
- Improved `parseLocalityName` function
- Improved `normalizeCountyName` function with direct mappings

### 4. analyze_localities.js

Provides detailed analysis of locality formats and patterns.

```bash
node analyze_localities.js
```

**Output:**
- Locality statistics
- Most common localities
- Counties with most localities
- Locality pattern analysis
- Sample locality to county mapping

## How to Use

1. Make sure you have the `data.json` file in the same directory as these scripts
2. Run each script to get the specific analysis you need
3. Use the generated code to update your application

Example:

```bash
# Extract all unique county names
node extract_counties.js > county_results.txt

# Validate against existing mapping
node validate_county_mapping.js > validation_results.txt

# Generate improved mapping functions
node generate_county_mapping.js > improved_functions.txt

# Analyze locality patterns
node analyze_localities.js > locality_analysis.txt
```

## Integration

After running these scripts, you can:

1. Update the `normalizeCountyName` function in your HTML file with the improved version
2. Update the `parseLocalityName` function with the improved version
3. Add any missing counties to the `romanianCounties` object
4. Use the locality to county mapping for additional validation

These improvements will ensure that your map correctly displays all counties and localities from the PNRR data.
