// Script to generate a complete county mapping solution
const fs = require('fs');
const path = require('path');

// Read the data.json file
try {
    const dataPath = path.join(__dirname, 'data.json');
    const rawData = fs.readFileSync(dataPath, 'utf8');
    const data = JSON.parse(rawData);
    
    // Extract all unique locality formats
    const localityFormats = new Map();
    data.items.forEach(item => {
        if (item.localitate_beneficiar) {
            const locality = item.localitate_beneficiar;
            
            // Extract patterns
            let pattern = 'unknown';
            if (locality.match(/^Sec\. \d+/)) {
                pattern = 'sector';
            } else if (locality.match(/^Mun\./)) {
                pattern = 'municipiu';
            } else if (locality.match(/^Or[sş]\./)) {
                pattern = 'oras';
            } else if (locality.match(/^Com\./)) {
                pattern = 'comuna';
            } else if (locality.match(/^Sat/)) {
                pattern = 'sat';
            }
            
            if (!localityFormats.has(pattern)) {
                localityFormats.set(pattern, new Set());
            }
            localityFormats.get(pattern).add(locality);
        }
    });
    
    // Output locality format analysis
    console.log('=== Locality Format Analysis ===');
    for (const [pattern, examples] of localityFormats.entries()) {
        console.log(`\nPattern: ${pattern}`);
        console.log(`Examples (${examples.size}):`);
        
        // Show a few examples
        Array.from(examples).slice(0, 5).forEach(example => {
            console.log(`  - "${example}"`);
        });
    }
    
    // Generate improved parseLocalityName function
    console.log('\n=== Improved parseLocalityName Function ===');
    console.log(`function parseLocalityName(fullName) {
    if (!fullName) return { cleanName: '', type: 'Unknown', prefix: '' };

    // Clean up the name - remove trailing periods and extra spaces
    const name = fullName.trim().replace(/\\s*\\.\\s*$/, '');
    
    // Define patterns for locality types in the actual data
    const patterns = [
        { pattern: /^Sec\\. (\\d+)/i, type: 'Sector', extractName: (m) => \`Sector \${m[1]}\` },
        { pattern: /^Mun\\. ([\\w\\s]+)/i, type: 'Municipiu', extractName: (m) => m[1].trim() },
        { pattern: /^Or[sş]\\. ([\\w\\s]+)/i, type: 'Oraș', extractName: (m) => m[1].trim() },
        { pattern: /^Com\\. ([\\w\\s]+)/i, type: 'Comună', extractName: (m) => m[1].trim() },
        { pattern: /^Sat ([\\w\\s]+)/i, type: 'Sat', extractName: (m) => m[1].trim() }
    ];
    
    // Check for complex patterns like "Sec. 1, Mun. București"
    if (name.includes(',')) {
        const parts = name.split(',').map(p => p.trim());
        // Process the first part (usually the more specific location)
        for (const { pattern, type, extractName } of patterns) {
            const match = parts[0].match(pattern);
            if (match) {
                return {
                    cleanName: extractName(match),
                    type: type,
                    prefix: parts[0].split(' ')[0],
                    fullDetails: name // Keep the full details for reference
                };
            }
        }
    }
    
    // Check for simple patterns
    for (const { pattern, type, extractName } of patterns) {
        const match = name.match(pattern);
        if (match) {
            return {
                cleanName: extractName(match),
                type: type,
                prefix: name.split(' ')[0]
            };
        }
    }
    
    // No pattern found, assume it's a locality name
    return { cleanName: name, type: 'Localitate', prefix: '' };
}`);
    
    // Generate improved normalizeCountyName function
    console.log('\n=== Improved normalizeCountyName Function ===');
    
    // Extract all unique county names
    const countyMap = {};
    const uniqueCounties = new Set();
    
    data.items.forEach(item => {
        if (item.judet_beneficiar) {
            uniqueCounties.add(item.judet_beneficiar);
            
            // Try to normalize the county name
            const normalized = normalizeCountyName(item.judet_beneficiar);
            
            // Keep track of original to normalized mapping
            if (!countyMap[normalized]) {
                countyMap[normalized] = new Set();
            }
            countyMap[normalized].add(item.judet_beneficiar);
        }
    });
    
    console.log(`function normalizeCountyName(countyName) {
    if (!countyName) return '';
    
    // Direct mapping for known variations
    const countyMapping = {`);
    
    Object.keys(countyMap).sort().forEach((normalized, index, array) => {
        const originals = Array.from(countyMap[normalized]);
        originals.forEach((original, i) => {
            if (original !== normalized) {
                console.log(`        "${original}": "${normalized}",`);
            }
        });
    });
    
    console.log(`    };
    
    // Check if we have a direct mapping
    if (countyMapping[countyName]) {
        return countyMapping[countyName];
    }
    
    // Convert to uppercase for consistency
    let normalized = countyName.toUpperCase();
    
    // Handle special case for Bucharest
    if (normalized === 'MUNICIPIUL BUCUREŞTI' || normalized === 'MUNICIPIUL BUCURESTI') {
        return 'BUCURESTI';
    }
    
    // Remove 'JUDETUL ' prefix if present
    normalized = normalized.replace(/^JUDETUL\\s+/i, '');
    
    // Replace Romanian special characters with their ASCII equivalents
    const replacements = {
        'Ş': 'S', 'Ţ': 'T', 'Ă': 'A', 'Â': 'A', 'Î': 'I'
    };
    
    for (const [special, ascii] of Object.entries(replacements)) {
        normalized = normalized.replace(new RegExp(special, 'g'), ascii);
    }
    
    return normalized;
}`);
    
} catch (error) {
    console.error('Error processing the data file:', error);
    process.exit(1);
}

// Function to normalize county names
function normalizeCountyName(countyName) {
    if (!countyName) return '';
    
    // Convert to uppercase for consistency
    let normalized = countyName.toUpperCase();
    
    // Handle special case for Bucharest
    if (normalized === 'MUNICIPIUL BUCUREŞTI' || normalized === 'MUNICIPIUL BUCURESTI') {
        return 'BUCURESTI';
    }
    
    // Remove 'JUDETUL ' prefix if present
    normalized = normalized.replace(/^JUDETUL\s+/i, '');
    
    // Replace Romanian special characters with their ASCII equivalents
    const replacements = {
        'Ş': 'S', 'Ţ': 'T', 'Ă': 'A', 'Â': 'A', 'Î': 'I'
    };
    
    for (const [special, ascii] of Object.entries(replacements)) {
        normalized = normalized.replace(new RegExp(special, 'g'), ascii);
    }
    
    return normalized;
}
