// Script to extract unique county names from PNRR data
const fs = require('fs');
const path = require('path');

// Read the data.json file
try {
    const dataPath = path.join(__dirname, 'data.json');
    const rawData = fs.readFileSync(dataPath, 'utf8');
    const data = JSON.parse(rawData);
    
    if (!data.items || !Array.isArray(data.items)) {
        console.error('Error: Invalid data format. Expected an object with "items" array.');
        process.exit(1);
    }
    
    // Extract all unique county names
    const countyMap = {};
    const uniqueCounties = new Set();
    
    data.items.forEach(item => {
        if (item.judet_beneficiar) {
            uniqueCounties.add(item.judet_beneficiar);
            
            // Try to normalize the county name
            const normalized = normalizeCountyName(item.judet_beneficiar);
            
            // Keep track of original to normalized mapping
            if (!countyMap[normalized]) {
                countyMap[normalized] = new Set();
            }
            countyMap[normalized].add(item.judet_beneficiar);
        }
    });
    
    // Output results
    console.log('=== Unique County Names ===');
    console.log(`Found ${uniqueCounties.size} unique county names:`);
    console.log(Array.from(uniqueCounties).sort().join('\n'));
    
    console.log('\n=== County Normalization Mapping ===');
    Object.keys(countyMap).sort().forEach(normalized => {
        const originals = Array.from(countyMap[normalized]);
        console.log(`${normalized} => ${originals.join(', ')}`);
    });
    
    // Generate mapping code
    console.log('\n=== County Mapping Code ===');
    console.log('const countyMapping = {');
    Object.keys(countyMap).sort().forEach((normalized, index, array) => {
        const originals = Array.from(countyMap[normalized]);
        originals.forEach((original, i) => {
            console.log(`    "${original}": "${normalized}"${(index === array.length - 1 && i === originals.length - 1) ? '' : ','}`);
        });
    });
    console.log('};');
    
} catch (error) {
    console.error('Error processing the data file:', error);
    process.exit(1);
}

// Function to normalize county names (similar to the one in your HTML)
function normalizeCountyName(countyName) {
    if (!countyName) return '';
    
    // Convert to uppercase for consistency
    let normalized = countyName.toUpperCase();
    
    // Handle special case for Bucharest
    if (normalized === 'MUNICIPIUL BUCUREŞTI' || normalized === 'MUNICIPIUL BUCURESTI') {
        return 'BUCURESTI';
    }
    
    // Remove 'JUDETUL ' prefix if present
    normalized = normalized.replace(/^JUDETUL\s+/i, '');
    
    // Replace Romanian special characters with their ASCII equivalents
    const replacements = {
        'Ş': 'S', 'Ţ': 'T', 'Ă': 'A', 'Â': 'A', 'Î': 'I'
    };
    
    for (const [special, ascii] of Object.entries(replacements)) {
        normalized = normalized.replace(new RegExp(special, 'g'), ascii);
    }
    
    return normalized;
}
