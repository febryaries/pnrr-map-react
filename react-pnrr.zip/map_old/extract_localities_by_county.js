// Script to extract all unique localities grouped by county from PNRR data
const fs = require('fs');
const path = require('path');

// Read the data.json file
try {
    const dataPath = path.join(__dirname, 'data.json');
    const rawData = fs.readFileSync(dataPath, 'utf8');
    const data = JSON.parse(rawData);
    
    if (!data.items || !Array.isArray(data.items)) {
        console.error('Error: Invalid data format. Expected an object with "items" array.');
        process.exit(1);
    }
    
    // Group localities by county
    const countiesMap = {};
    
    data.items.forEach(item => {
        if (item.judet_beneficiar && item.localitate_beneficiar) {
            const county = item.judet_beneficiar.trim();
            const locality = item.localitate_beneficiar.trim();
            
            if (!countiesMap[county]) {
                countiesMap[county] = new Set();
            }
            
            countiesMap[county].add(locality);
        }
    });
    
    // Convert to desired output format
    const result = {};
    
    Object.keys(countiesMap).sort().forEach(county => {
        result[county] = Array.from(countiesMap[county]).sort();
    });
    
    // Output as formatted JSON
    console.log(JSON.stringify(result, null, 2));
    
    // Save to file
    fs.writeFileSync(
        path.join(__dirname, 'localities_by_county.json'), 
        JSON.stringify(result, null, 2), 
        'utf8'
    );
    
    // Output summary statistics
    const totalCounties = Object.keys(result).length;
    const totalLocalities = Object.values(result).reduce((sum, localities) => sum + localities.length, 0);
    
    console.error(`\nSummary:`);
    console.error(`- Total counties: ${totalCounties}`);
    console.error(`- Total unique localities: ${totalLocalities}`);
    console.error(`- Results saved to localities_by_county.json`);
    
    // Output counties with most localities
    console.error(`\nTop 5 counties by number of localities:`);
    Object.entries(result)
        .sort((a, b) => b[1].length - a[1].length)
        .slice(0, 5)
        .forEach(([county, localities]) => {
            console.error(`- ${county}: ${localities.length} localities`);
        });
    
} catch (error) {
    console.error('Error processing the data file:', error);
    process.exit(1);
}
