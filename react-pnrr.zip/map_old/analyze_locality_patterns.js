// Script to analyze locality patterns and create mapping helpers
const fs = require('fs');
const path = require('path');

// Read the data.json file
try {
    const dataPath = path.join(__dirname, 'data.json');
    const rawData = fs.readFileSync(dataPath, 'utf8');
    const data = JSON.parse(rawData);
    
    if (!data.items || !Array.isArray(data.items)) {
        console.error('Error: Invalid data format. Expected an object with "items" array.');
        process.exit(1);
    }
    
    // Group localities by county
    const countiesMap = {};
    const patternsByCounty = {};
    const allPatterns = {
        'sector': { regex: /^Sec\. \d+/i, count: 0, examples: [] },
        'municipiu': { regex: /^Mun\./i, count: 0, examples: [] },
        'oras': { regex: /^Or[sş]\./i, count: 0, examples: [] },
        'comuna': { regex: /^Com\./i, count: 0, examples: [] },
        'sat': { regex: /^Sat/i, count: 0, examples: [] },
        'mrj': { regex: /^MRJ\./i, count: 0, examples: [] },
        'other': { regex: /./i, count: 0, examples: [] }
    };
    
    // Process each item
    data.items.forEach(item => {
        if (item.judet_beneficiar && item.localitate_beneficiar) {
            const county = item.judet_beneficiar.trim();
            const locality = item.localitate_beneficiar.trim();
            
            // Add to counties map
            if (!countiesMap[county]) {
                countiesMap[county] = new Set();
                patternsByCounty[county] = {};
                Object.keys(allPatterns).forEach(pattern => {
                    patternsByCounty[county][pattern] = { count: 0, examples: [] };
                });
            }
            
            countiesMap[county].add(locality);
            
            // Identify pattern
            let matched = false;
            for (const [pattern, info] of Object.entries(allPatterns)) {
                if (pattern !== 'other' && locality.match(info.regex)) {
                    allPatterns[pattern].count++;
                    if (allPatterns[pattern].examples.length < 10 && !allPatterns[pattern].examples.includes(locality)) {
                        allPatterns[pattern].examples.push(locality);
                    }
                    
                    patternsByCounty[county][pattern].count++;
                    if (patternsByCounty[county][pattern].examples.length < 5 && 
                        !patternsByCounty[county][pattern].examples.includes(locality)) {
                        patternsByCounty[county][pattern].examples.push(locality);
                    }
                    
                    matched = true;
                    break;
                }
            }
            
            if (!matched) {
                allPatterns.other.count++;
                if (allPatterns.other.examples.length < 10 && !allPatterns.other.examples.includes(locality)) {
                    allPatterns.other.examples.push(locality);
                }
                
                patternsByCounty[county].other.count++;
                if (patternsByCounty[county].other.examples.length < 5 && 
                    !patternsByCounty[county].other.examples.includes(locality)) {
                    patternsByCounty[county].other.examples.push(locality);
                }
            }
        }
    });
    
    // Convert to desired output format
    const result = {
        counties: {},
        patterns: {},
        patternsByCounty: {},
        summary: {
            totalCounties: Object.keys(countiesMap).length,
            totalLocalities: Object.values(countiesMap).reduce((sum, localities) => sum + localities.size, 0),
            patternCounts: {}
        }
    };
    
    // Add counties data
    Object.keys(countiesMap).sort().forEach(county => {
        result.counties[county] = Array.from(countiesMap[county]).sort();
    });
    
    // Add patterns data
    Object.entries(allPatterns).forEach(([pattern, info]) => {
        result.patterns[pattern] = {
            count: info.count,
            examples: info.examples
        };
        result.summary.patternCounts[pattern] = info.count;
    });
    
    // Add patterns by county
    Object.entries(patternsByCounty).forEach(([county, patterns]) => {
        result.patternsByCounty[county] = {};
        Object.entries(patterns).forEach(([pattern, info]) => {
            if (info.count > 0) {
                result.patternsByCounty[county][pattern] = {
                    count: info.count,
                    examples: info.examples
                };
            }
        });
    });
    
    // Save to file
    fs.writeFileSync(
        path.join(__dirname, 'locality_patterns.json'), 
        JSON.stringify(result, null, 2), 
        'utf8'
    );
    
    // Output summary statistics
    console.error(`\nSummary:`);
    console.error(`- Total counties: ${result.summary.totalCounties}`);
    console.error(`- Total unique localities: ${result.summary.totalLocalities}`);
    console.error(`- Results saved to locality_patterns.json`);
    
    // Output pattern statistics
    console.error(`\nLocality patterns:`);
    Object.entries(result.patterns)
        .sort((a, b) => b[1].count - a[1].count)
        .forEach(([pattern, info]) => {
            console.error(`- ${pattern}: ${info.count} localities`);
            if (info.examples.length > 0) {
                console.error(`  Examples: ${info.examples.slice(0, 3).join(', ')}${info.examples.length > 3 ? '...' : ''}`);
            }
        });
    
    // Output counties with most localities
    console.error(`\nTop 5 counties by number of localities:`);
    Object.entries(result.counties)
        .sort((a, b) => b[1].length - a[1].length)
        .slice(0, 5)
        .forEach(([county, localities]) => {
            console.error(`- ${county}: ${localities.length} localities`);
        });
    
    // Generate a mapping helper for Bucharest sectors
    if (result.counties['MUNICIPIUL BUCUREŞTI']) {
        const bucharestLocalities = result.counties['MUNICIPIUL BUCUREŞTI'];
        const sectorPattern = /^Sec\. (\d+)/i;
        const sectors = {};
        
        bucharestLocalities.forEach(locality => {
            const match = locality.match(sectorPattern);
            if (match) {
                const sectorNum = match[1];
                if (!sectors[sectorNum]) {
                    sectors[sectorNum] = [];
                }
                sectors[sectorNum].push(locality);
            }
        });
        
        console.error('\nBucharest sectors mapping:');
        console.error('const bucharestSectors = {');
        Object.keys(sectors).sort().forEach(sector => {
            console.error(`  '${sector}': { lat: 0, lng: 0, localities: ${JSON.stringify(sectors[sector])} },`);
        });
        console.error('};');
    }
    
    // Output the full JSON result
    fs.writeFileSync(
        path.join(__dirname, 'locality_patterns.json'),
        JSON.stringify(result, null, 2),
        'utf8'
    );
    // console.log(JSON.stringify(result.counties, null, 2));
    
} catch (error) {
    console.error('Error processing the data file:', error);
    process.exit(1);
}
